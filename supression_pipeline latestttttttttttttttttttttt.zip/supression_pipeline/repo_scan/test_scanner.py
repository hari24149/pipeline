import unittest
import json
import sys
import tempfile
import subprocess
import shutil
import ast
import re
from pathlib import Path
from unittest.mock import patch, Mock

from scanner import export_excel, finding_rows, scan, scan_java
from manage_rules import add_rule
from python_security import scan_python, BUILTIN_RULE_IDS

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "triage_ui"))
import server


def finding(line=5, snippet="dangerous_call(user)"):
    return {
        "check_id": "python.example",
        "path": "src/app.py",
        "start": {"line": line},
        "extra": {"lines": snippet, "message": "Review this call", "severity": "ERROR"},
    }


class ScannerTests(unittest.TestCase):
    def test_builtin_rule_catalogs_cover_the_implemented_checks(self):
        root = Path(__file__).parent
        python_rules = json.loads((root / "rules" / "python-builtin.json").read_text(encoding="utf-8"))
        python_ids = {rule["id"] for rule in python_rules if rule.get("engine") == "ast"}
        tree = ast.parse((root / "python_security.py").read_text(encoding="utf-8"))
        implemented_python = {f"local-python-{node.args[1].value}" for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "finding" and len(node.args) > 1 and isinstance(node.args[1], ast.Constant)}
        self.assertTrue(python_ids <= BUILTIN_RULE_IDS)
        self.assertEqual(BUILTIN_RULE_IDS, implemented_python)
        typescript_rules = json.loads((root / "rules" / "typescript-local.json").read_text(encoding="utf-8"))
        typescript_ids = {rule["id"] for rule in typescript_rules if rule.get("engine") == "ast"}
        scanner = (root / "script_security.js").read_text(encoding="utf-8")
        implemented_typescript = set(re.findall(r'finding\(\w+, "(local-(?:javascript|angular)-[^"]+)"', scanner))
        self.assertEqual(typescript_ids, implemented_typescript)

    def test_typescript_builtin_rules_are_configured_in_json(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.ts").write_text('eval(value);\n', encoding="utf-8")
            rules = root / "rules.json"
            entry = {"id": "local-javascript-eval", "engine": "ast", "issue_type": "Code Injection", "message": "Configured message"}
            script = Path(__file__).with_name("script_security.js")
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            report = json.loads(subprocess.run(["node", str(script), str(root), str(rules)], capture_output=True, text=True, check=True).stdout)
            self.assertEqual(report["results"][0]["extra"]["message"], "Configured message")
            entry["enabled"] = False
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            report = json.loads(subprocess.run(["node", str(script), str(root), str(rules)], capture_output=True, text=True, check=True).stdout)
            self.assertEqual(report["results"], [])
            self.assertIn(entry["id"], report["disabled_or_missing_builtin_rules"])
            entry["id"] = "local-javascript-unknown"
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            self.assertNotEqual(subprocess.run(["node", str(script), str(root), str(rules)], capture_output=True, text=True).returncode, 0)

    def test_javascript_syntax_errors_are_deduplicated_and_fail_the_scan(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.js").write_text('const value = 1;\n});\n', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root)], capture_output=True, text=True, check=True)
            errors = json.loads(result.stdout)["errors"]
            self.assertEqual(len(errors), 1)
            self.assertEqual(errors[0]["path"], "app.js")
            self.assertEqual(errors[0]["line"], 2)
            with self.assertRaisesRegex(ValueError, "source could not be parsed"):
                scan(root, root / "results", "", {}, skip_accessibility=True)
            self.assertFalse((root / "results" / "security_report.json").exists())

    def test_python_builtin_rules_are_configured_in_json(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('eval(value)\n', encoding="utf-8")
            rules = root / "rules.json"
            entry = {"id": "local-python-dynamic-execution", "engine": "ast", "issue_type": "Code Injection", "message": "Configured message"}
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual(report["builtin_rules"], 1)
            self.assertEqual(report["results"][0]["extra"]["message"], "Code Injection: Configured message")
            entry["enabled"] = False
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual(report["results"], [])
            self.assertIn(entry["id"], report["disabled_or_missing_builtin_rules"])
            entry["id"] = "local-python-unknown"
            entry["enabled"] = True
            rules.write_text(json.dumps([entry]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual(report["results"], [])
            self.assertEqual(report["unsupported_ast_rules"], ["local-python-unknown"])

    def test_unimplemented_python_rule_is_reported_and_compile_rule_works(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('compile(source, "<input>", "exec")\ncompile("1 + 1", "<input>", "eval")\n', encoding="utf-8")
            rules = root / "rules.json"
            rules.write_text(json.dumps([
                {"id": "local-python-compile-execution", "engine": "ast", "issue_type": "Code Injection", "message": "Review compile"},
                {"id": "local-python-unimplemented-example", "engine": "ast", "issue_type": "Security", "message": "Review"},
            ]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual(len(report["results"]), 1)
            self.assertEqual(report["results"][0]["check_id"], "local-python-compile-execution")
            self.assertEqual(report["unsupported_ast_rules"], ["local-python-unimplemented-example"])
            self.assertEqual(report["coverage_status"], "incomplete")

    def test_python_tls_and_xml_configuration_rules(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import ssl as tls\nfrom lxml import etree as xml\ncontext.verify_mode = tls.CERT_NONE\ncontext.check_hostname = False\nxml.XMLParser(resolve_entities=True, load_dtd=True)\ncontext.verify_mode = tls.CERT_REQUIRED\ncontext.check_hostname = True\nxml.XMLParser(resolve_entities=False, load_dtd=False)\n', encoding="utf-8")
            rules = root / "rules.json"
            rule_ids = ["ssl-cert-none", "ssl-check-hostname-false", "lxml-resolve-entities", "lxml-load-dtd"]
            rules.write_text(json.dumps([{"id": f"local-python-{rule}", "engine": "ast", "issue_type": "Security", "message": "Review"} for rule in rule_ids]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual({row["check_id"] for row in report["results"]}, {f"local-python-{rule}" for rule in rule_ids})
            self.assertEqual(len(report["results"]), 4)
            self.assertEqual(report["unsupported_ast_rules"], [])

    def test_python_dynamic_import_deserialization_and_timeout_rules(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import importlib as imp\nimport runpy\nimport subprocess\nfrom sqlalchemy import text\nimport joblib\nimport numpy as np\nimport pandas as pd\nimport torch\nimport jsonpickle\nimport jwt\nimport requests\n__import__(module)\n__import__("json")\nimp.import_module(module)\nimp.import_module("json")\nrunpy.run_path(path)\nrunpy.run_path("script.py")\nsubprocess.run(args, executable=program)\nsubprocess.run(args, executable="/bin/echo")\ntext(f"SELECT {value}")\ntext("SELECT :value")\njoblib.load(path)\nnp.load(path, allow_pickle=True)\nnp.load(path, allow_pickle=False)\npd.read_pickle(path)\ntorch.load(path, weights_only=False)\ntorch.load(path, weights_only=True)\njsonpickle.decode(data)\njwt.decode(token, algorithms=["none"])\njwt.decode(token, algorithms=["HS256"])\nrequests.get(url)\nrequests.get(url, timeout=5)\n', encoding="utf-8")
            rule_ids = ["dynamic-import", "importlib-dynamic-import", "runpy-execution", "subprocess-executable-override", "sqlalchemy-text-dynamic", "joblib-load", "numpy-allow-pickle", "pandas-pickle", "torch-load", "jsonpickle-decode", "jwt-algorithm-none", "network-request-no-timeout"]
            rules = root / "rules.json"
            rules.write_text(json.dumps([{"id": f"local-python-{rule}", "engine": "ast", "issue_type": "Security", "message": "Review"} for rule in rule_ids]), encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual({row["check_id"] for row in report["results"]}, {f"local-python-{rule}" for rule in rule_ids})
            self.assertEqual(len(report["results"]), len(rule_ids))
            self.assertEqual(report["unsupported_ast_rules"], [])

    def test_python_credentials_and_sensitive_logging_are_detected_and_redacted(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import logging\nimport os\npassword = "example-secret-value"\napiKey: str = "example-api-value"\npassword_from_env = os.getenv("PASSWORD")\ndatabase_url = "postgresql://user:example-db-value@localhost/db"\ncallback = "https://example.test/?token=example-token-value"\nlogger.info("Credentials: %s", password)\nlogger.info("Client %s", clientIp)\nlogging.info("Address 192.0.2.1")\nlogger.info("Request %s", requestUrl)\nlogging.info("https://example.test/page")\nlogger.info("Finished %s", status)\n', encoding="utf-8")
            report = scan_python(root)
            ids = {row["check_id"] for row in report["results"]}
            self.assertTrue({"local-python-hardcoded-password", "local-python-hardcoded-api-key", "local-python-hardcoded-database-url", "local-python-secret-in-url", "local-python-secret-logging", "local-python-ip-logging", "local-python-url-logging"} <= ids)
            self.assertEqual(len([row for row in report["results"] if row["check_id"] == "local-python-ip-logging"]), 2)
            self.assertEqual(len([row for row in report["results"] if row["check_id"] == "local-python-url-logging"]), 2)
            self.assertTrue(all(row["extra"].get("highlights") and "Sensitive source redacted" not in row["extra"]["lines"] for row in report["results"]))
            self.assertTrue(all(len(row["extra"]["highlights"]) <= 5 for row in report["results"]))
            rendered = json.dumps(report)
            for value in ("example-secret-value", "example-api-value", "example-db-value", "example-token-value", "192.0.2.1"):
                self.assertIn(value, rendered)

    def test_python_expanded_security_rules_replace_generic_duplicates(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import os\nimport subprocess\nimport tarfile\nimport hashlib\nimport yaml\nimport jwt\nimport requests\nimport ctypes\nimport re\nimport zlib\nfrom flask import request, redirect, Flask\nfrom Crypto.Cipher import AES, DES3\napp = Flask(__name__)\nos.system("ls " + request.args["d"])\nsubprocess.run(["ls", request.args["d"]])\nquery = f"SELECT * FROM users WHERE id = {user_id}"\nredirect(request.args["next"])\nopen(request.args["path"])\nwith tarfile.open(path) as archive:\n    archive.extractall()\nhashlib.md5(password.encode())\nyaml.load(data, Loader=yaml.Loader)\njwt.decode(token, "short-secret")\nrequests.get(request.args["url"], timeout=5)\nctypes.memmove(destination, source, size)\nre.compile("(a+)+$")\nzlib.decompress(blob)\nrequest.get_data()\nAES.new(key, AES.MODE_CBC, iv=b"\\x00" * 16)\nDES3.new(key, DES3.MODE_EAX)\napp.config["SESSION_COOKIE_SECURE"] = False\napp.run(host="0.0.0.0")\nALLOWED_HOSTS = ["*"]\n', encoding="utf-8")
            (root / "safe.py").write_text('import subprocess\nimport hashlib\nimport yaml\nimport jwt\nimport requests\nimport re\nsubprocess.run(["ls", "-l"])\ncursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))\nhashlib.sha256(data)\nyaml.safe_load(data)\njwt.decode(token, key, algorithms=["HS256"])\nrequests.get("https://example.com", timeout=5)\nre.compile("^[a-z]+$")\nre.compile("(?:[a-z]+/)+[a-z]+")\nimport tempfile\ntempfile.NamedTemporaryFile(dir=target, delete=False)\n', encoding="utf-8")
            report = scan_python(root)
            self.assertEqual(report["errors"], [])
            risky = {row["check_id"].removeprefix("local-python-") for row in report["results"] if row["path"] == "app.py" and row["extra"]["category"] == "Security"}
            self.assertTrue({"os-system-call", "subprocess-dynamic-command", "sql-fstring", "unvalidated-redirect", "open-user-path", "tarfile-extractall", "md5-password-hash", "yaml-unsafe-loader", "hardcoded-jwt-secret", "jwt-weak-secret", "jwt-no-algorithm-allowlist", "requests-user-url", "ctypes-memory-operation", "catastrophic-regex", "unbounded-decompression", "unbounded-request-body", "aes-cbc-no-authentication", "zero-initialization-vector", "triple-des-cipher", "insecure-session-cookie", "bind-all-interfaces", "django-allowed-hosts-wildcard"} <= risky, risky)
            self.assertFalse({"os-command", "archive-extraction", "weak-hash", "unsafe-yaml"} & risky)
            self.assertEqual([row["check_id"] for row in report["results"] if row["path"] == "safe.py"], [])
            self.assertTrue(any("short-secret" in row["extra"]["lines"] and row["extra"].get("highlights") for row in report["results"]))
            self.assertEqual(sorted(report["unsupported_ast_rules"]), ["local-python-boto3-unencrypted-storage", "local-python-missing-authorization-check", "local-python-security-event-not-logged", "local-python-user-controlled-object-id"])

    def test_python_code_quality_rules_are_categorized(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "quality.py").write_text('from os import *\ndef handler(value, items=[], *, option=None):\n    global COUNTER\n    try:\n        run()\n    except:\n        pass\n    if value == None:\n        return 1\n        print("never")\n    other = other\n    assert (value, "message")\n    data = {"key": 1, "key": 2}\n    if value is "text":\n        return f"plain"  # TODO remove\n    return data\n', encoding="utf-8")
            report = scan_python(root)
            quality = {row["check_id"].removeprefix("local-python-") for row in report["results"] if row["extra"]["category"] == "Code Quality"}
            self.assertTrue({"quality-wildcard-import", "quality-mutable-default-argument", "quality-global-statement", "quality-bare-except", "quality-none-comparison", "quality-unreachable-code", "quality-self-assignment", "quality-assert-on-tuple", "quality-duplicate-dict-key", "quality-literal-identity-comparison", "quality-fstring-without-placeholders", "quality-todo-comment"} <= quality, quality)
            self.assertTrue(all(row["extra"]["severity"] != "WARNING" for row in report["results"] if row["extra"]["category"] == "Code Quality"))

    def test_html_template_rules_cover_security_accessibility_and_quality(self):
        from html_security import scan_html
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "page.html").write_text('<html>\n<a href="javascript:run()">Run</a>\n<a href="/x" target="_blank">Open</a>\n<a href="/y" target="_blank" rel="noopener noreferrer">Safe</a>\n<script src="https://cdn.example.com/lib.js"></script>\n<script src="https://cdn.example.com/ok.js" integrity="sha384-abc"></script>\n<iframe src="/frame"></iframe>\n<input type="password" name="pw">\n<!-- password: example-comment-secret -->\n<div [innerHTML]="content"></div>\n<div (click)="open()">Open</div>\n<font>old</font>\n<!-- TODO remove -->\n<p>Server 10.1.2.3</p>\n</html>\n', encoding="utf-8")
            (root / "view.jsp").write_text('<img src="logo.png">\n<p><%= request.getParameter("q") %></p>\n<img src="ok.png" alt="Logo">\n', encoding="utf-8")
            report = scan_html(root)
            found = {(row["path"], row["check_id"].removeprefix("local-html-"), row["extra"]["category"]) for row in report["results"]}
            for expected in [("page.html", "javascript-url", "Security"), ("page.html", "target-blank-noopener", "Security"), ("page.html", "missing-sri", "Security"), ("page.html", "iframe-no-sandbox", "Security"), ("page.html", "password-autocomplete", "Security"), ("page.html", "sensitive-comment", "Security"), ("page.html", "angular-raw-html-binding", "Security"), ("page.html", "internal-ip", "Security"), ("page.html", "a11y-html-lang", "Accessibility"), ("page.html", "a11y-click-non-interactive", "Accessibility"), ("page.html", "quality-deprecated-element", "Code Quality"), ("page.html", "quality-todo-comment", "Code Quality"), ("view.jsp", "jsp-unescaped-expression", "Security"), ("view.jsp", "a11y-image-alt", "Accessibility")]:
                self.assertIn(expected, found)
            lines = {(row["check_id"], row["start"]["line"]) for row in report["results"]}
            self.assertNotIn(("local-html-target-blank-noopener", 4), lines)
            self.assertNotIn(("local-html-missing-sri", 6), lines)
            self.assertNotIn(("local-html-a11y-image-alt", 3), lines)
            self.assertFalse(any(row["path"] == "page.html" and row["check_id"] == "local-html-a11y-image-alt" for row in report["results"]))
            rendered = json.dumps(report)
            self.assertIn("example-comment-secret", rendered)
            self.assertIn("10.1.2.3", rendered)
            secret = next(row for row in report["results"] if row["check_id"] == "local-html-sensitive-comment")
            address = next(row for row in report["results"] if row["check_id"] == "local-html-internal-ip")
            self.assertTrue(secret["extra"]["highlights"] and address["extra"]["highlights"])
            self.assertLessEqual(len(secret["extra"]["highlights"]), 5)

    def test_java_rules_support_categories_redaction_and_comment_rules(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "App.java").write_text('import java.util.*;\nclass App {\n  // TODO remove legacy path\n  String password = "example-java-secret";\n  void f(HttpServletRequest request) {\n    byte[] data = request.getInputStream().readAllBytes();\n    byte[] buf = new byte[Integer.parseInt(request.getParameter("n"))];\n    try { run(); } catch (Exception e) {}\n    if (name == "admin") {}\n  }\n}\n', encoding="utf-8")
            report = scan_java(root)
            found = {(row["check_id"].removeprefix("local-java-"), row["extra"]["category"]) for row in report["results"]}
            self.assertTrue({("unbounded-request-read", "Security"), ("user-sized-allocation", "Security"), ("hardcoded-credential", "Security"), ("quality-todo-comment", "Code Quality"), ("quality-wildcard-import", "Code Quality"), ("quality-empty-catch", "Code Quality"), ("quality-generic-catch", "Code Quality"), ("quality-string-reference-equality", "Code Quality")} <= found, found)
            credential = next(row for row in report["results"] if "hardcoded-credential" in row["check_id"])
            self.assertIn("example-java-secret", credential["extra"]["lines"])
            self.assertTrue(credential["extra"]["highlights"])
            self.assertLessEqual(len(credential["extra"]["highlights"]), 5)

    def test_skip_quality_and_user_html_quality_rule(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('def run(items=[]):\n    return eval(items)\n', encoding="utf-8")
            output = root / "with-quality"
            scan(root, output, "", {}, skip_accessibility=True, language="python")
            categories = {row["category"] for row in json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))}
            self.assertEqual(categories, {"Security", "Code Quality"})
            output = root / "without-quality"
            scan(root, output, "", {}, skip_accessibility=True, language="python", skip_quality=True)
            categories = {row["category"] for row in json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))}
            self.assertEqual(categories, {"Security"})
            self.assertEqual(json.loads((output / "security_report.json").read_text(encoding="utf-8"))["code_quality"], "skipped")
            rules = root / "html-rules.json"
            rules.write_text("[]", encoding="utf-8")
            add_rule("html-legacy-widget", "legacy-widget", "Replace the legacy widget", '<div class="legacy-widget">', '<div class="widget">', rules, issue_type="Maintainability", category="Code Quality")
            from html_security import scan_html
            (root / "page.html").write_text('<div class="legacy-widget"></div>\n', encoding="utf-8")
            report = scan_html(root, rules)
            self.assertEqual([(row["check_id"], row["extra"]["category"]) for row in report["results"]], [("html-legacy-widget", "Code Quality")])
            with self.assertRaisesRegex(ValueError, "Category must be one of"):
                add_rule("html-other", "other", "Review", "other()", "safe()", rules, category="Style")

    def test_existing_pipelines_get_quality_and_html_options(self):
        definition = {"id": "repo", "kind": "repo_scan", "params": [{"name": "language", "type": "choice", "choices": ["all", "java"], "flag": "--language"}], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"repo": definition}):
            result = server.get_pipeline("repo")
        names = {param["name"]: param for param in result["params"]}
        self.assertIn("html", names["language"]["choices"])
        self.assertEqual(names["skip_quality"]["flag"], "--skip-quality")
        rules_definition = {"id": "rules", "command": ["python", "manage_rules.py"], "params": [{"name": "language", "type": "choice", "choices": ["java"], "flag": "--language"}], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"rules": rules_definition}):
            result = server.get_pipeline("rules")
        names = {param["name"]: param for param in result["params"]}
        self.assertIn("html", names["language"]["choices"])
        self.assertEqual(names["category"]["choices"], ["Security", "Code Quality", "Accessibility"])

    def test_sensitive_python_findings_remain_redacted_in_export(self):
        from openpyxl import load_workbook
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('password = "example-export-value"\nlogger.info("Password %s", password)\n', encoding="utf-8")
            output = root / "results"
            scan(root, output, "", {}, skip_accessibility=True, language="python")
            grouped = (output / "grouped_issues_with_ai.json").read_text(encoding="utf-8")
            self.assertIn("example-export-value", grouped)
            self.assertIn("highlights", grouped)
            workbook = load_workbook(output / "results_SAST_SuppressionReport.xlsx")
            self.assertTrue(any("example-export-value" in str(row) for row in workbook.active.iter_rows(values_only=True)))

    def test_expanded_node_rules_and_safe_alternatives(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.ts").write_text('import { spawn as start } from "child_process";\nimport * as crypto from "node:crypto";\nimport * as vm from "vm";\nstart(command, [], {shell: true});\nstart(command, [], {shell: false});\ncrypto.createCipher("aes-128-cbc", key);\ncrypto.createCipheriv("aes-128-ecb", key, iv);\ncrypto.createCipheriv("aes-256-gcm", key, iv);\nvm.runInNewContext(code);\nwindow.postMessage(message, "*");\nwindow.postMessage(message, "https://example.com");\n', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            self.assertEqual({row["check_id"] for row in report["results"]}, {"local-javascript-shell-option", "local-javascript-deprecated-cipher", "local-javascript-weak-cipher", "local-javascript-vm-execution", "local-javascript-wildcard-postmessage"})
            self.assertEqual(len(report["results"]), 5)

    def test_expanded_java_rules_and_safe_alternatives(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "App.java").write_text('import org.example.NoopHostnameVerifier;\nclass App { void scan() {\nconn.prepareStatement("SELECT * FROM users WHERE id=" + user);\nconn.prepareStatement("SELECT * FROM users WHERE id=?");\nnew ObjectInputStream(input);\nMessageDigest.getInstance("MD2");\nCipher.getInstance("RC4");\nCipher.getInstance("AES/ECB/NoPadding");\nCipher.getInstance("AES/GCM/NoPadding");\nSSLContext.getInstance("TLSv1");\nSSLContext.getInstance("TLSv1.3");\nNoopHostnameVerifier.INSTANCE;\nparser.setFeature("http://xml.org/sax/features/external-general-entities", true);\nparser.setFeature("http://xml.org/sax/features/external-general-entities", false);\nparser.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false);\nhttp.csrf().disable();\n} }', encoding="utf-8")
            report = scan_java(root)
            rows, _ = finding_rows(report, {})
            ids = {row["rule_id"] for row in rows}
            self.assertEqual(ids, {"local-java-dynamic-prepared-query", "local-java-unsafe-deserialization", "local-java-weak-md2", "local-java-legacy-cipher", "local-java-ecb-cipher", "local-java-legacy-tls", "local-java-noop-hostname-verifier", "local-java-unsafe-xml-external-entities", "local-java-unsafe-xml-doctype", "local-java-disabled-csrf"})
            self.assertTrue(all(row["issue_type"] != "Security review" for row in rows))
            self.assertEqual(len(rows), 10)

    def test_expanded_python_rules_and_safe_alternatives(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import asyncio\nimport subprocess\nimport httpx\nimport aiohttp\nimport jinja2\nimport os\nimport jwt\nfrom Crypto.Cipher import AES, DES\nasyncio.create_subprocess_shell(command)\nsubprocess.getoutput(command)\nhttpx.get(url, verify=False, timeout=5)\nhttpx.get(url, verify=True, timeout=5)\naiohttp.TCPConnector(ssl=False)\njinja2.Environment(autoescape=False)\njinja2.Environment(autoescape=True)\napp.run(debug=True)\nAES.new(key, AES.MODE_ECB)\nAES.new(key, AES.MODE_GCM)\nDES.new(key)\nos.chmod(path, 0o777)\nos.chmod(path, 0o700)\njwt.decode(token, options={"verify_signature": False})\njwt.decode(token, options={"verify_signature": True})\n', encoding="utf-8")
            report = scan_python(root)
            self.assertEqual(report["errors"], [])
            ids = {row["check_id"] for row in report["results"]}
            self.assertEqual(ids, {f"local-python-{name}" for name in ("os-command", "httpx-verify-false", "aiohttp-ssl-false", "disabled-autoescape", "flask-debug-enabled", "ecb-cipher", "des-cipher", "chmod-777", "jwt-signature-disabled", "jwt-no-algorithm-allowlist")})
            self.assertEqual(len(report["results"]), 11)
            self.assertEqual([row["start"]["line"] for row in report["results"] if row["check_id"] == "local-python-jwt-no-algorithm-allowlist"], [23])
            self.assertTrue(all(row["extra"].get("issue_type") for row in report["results"]))

    def test_expanded_typescript_rules_detect_risks_and_not_safe_alternatives(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.ts").write_text('import { exec as run } from "node:child_process";\nimport * as crypto from "crypto";\nrun(command);\ndocument.write(value);\nelement.insertAdjacentHTML("beforeend", value);\nelement.outerHTML = value;\nnew Function(value);\nsetTimeout("danger()", 10);\nsetTimeout(() => safe(), 10);\ndb.query(`SELECT * FROM users WHERE id=${user}`);\ndb.query("SELECT * FROM users WHERE id=?", [user]);\ncrypto.createHash("md5");\ncrypto.createHash("sha256");\nprocess.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";\nconst options = { rejectUnauthorized: false };\n', encoding="utf-8")
            (root / "app.tsx").write_text('const view = <div dangerouslySetInnerHTML={{__html: value}} />;', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            ids = {row["check_id"] for row in report["results"]}
            self.assertEqual(ids, {"local-javascript-shell-exec", "local-javascript-html-insertion", "local-javascript-outerhtml", "local-javascript-function-constructor", "local-javascript-string-timer", "local-javascript-dynamic-query", "local-javascript-weak-hash", "local-javascript-disabled-tls", "local-javascript-insecure-tls-option", "local-javascript-dangerous-jsx-html"})
            self.assertEqual(len(report["results"]), 11)
            self.assertTrue(all(row["extra"].get("issue_type") for row in report["results"]))

    def test_python_security_finds_categorized_issues_without_comments_or_safe_sql(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import subprocess as sp\nimport pickle\nfrom django.utils.safestring import mark_safe as trust\n# eval(value)\ntext = "eval(value)"\ncursor.execute("SELECT * FROM users WHERE name = ?", (name,))\ncursor.execute(f"SELECT * FROM users WHERE name = {name}")\nsp.run(command, shell=True)\ntrust(user_input)\npickle.loads(data)\n', encoding="utf-8")
            report = scan_python(root)
            self.assertEqual(report["errors"], [])
            self.assertEqual(report["scanned_files"], 1)
            self.assertEqual({row["extra"]["issue_type"] for row in report["results"]}, {"SQL Injection", "Command Injection", "Cross-Site Scripting (XSS)", "Unsafe Deserialization"})
            self.assertEqual(len(report["results"]), 4)

    def test_custom_python_rule_is_loaded_and_ignores_comments(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            rules = root / "rules.json"
            rules.write_text("[]", encoding="utf-8")
            add_rule("python-custom", r"dangerous\(", "Review custom call", "dangerous(value)", "safe(value)", rules, issue_type="Code Injection")
            (root / "app.py").write_text('# dangerous(value)\ndangerous(value) # dangerous(other)\n', encoding="utf-8")
            report = scan_python(root, rules)
            self.assertEqual(report["custom_rules"], 1)
            self.assertEqual(len(report["results"]), 1)
            self.assertEqual(report["results"][0]["extra"]["issue_type"], "Code Injection")

    def test_custom_typescript_rules_are_literal_and_language_specific(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            rules = root / "rules.json"
            rules.write_text("[]", encoding="utf-8")
            add_rule("typescript-custom", r"dangerous\(", "Review custom call", "dangerous(value)", "safe(value)", rules, issue_type="Code Injection")
            (root / "app.ts").write_text('// dangerous(value)\ndangerous(value);\n', encoding="utf-8")
            (root / "app.js").write_text('dangerous(value);\n', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root), str(rules)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            custom = [row for row in report["results"] if row["check_id"] == "typescript-custom"]
            self.assertEqual(len(custom), 1)
            self.assertEqual(custom[0]["path"], "app.ts")
            self.assertEqual(custom[0]["extra"]["issue_type"], "Code Injection")

    def test_existing_rule_pipeline_accepts_python_and_issue_type(self):
        definition = {"id": "security-rules", "command": ["python", "-u", "manage_rules.py"], "params": [], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"security-rules": definition}):
            updated = server.get_pipeline("security-rules")
        values = server.normalize_params(updated, {"rule_id": "python-sql", "patterns": r"executeQuery\s*\(", "message": "Review", "match_example": "cursor.executeQuery(sql + name)", "nonmatch_example": "cursor.execute(sql)", "language": "python", "issue_type": "SQL Injection"})
        command = server.build_command(updated, values)
        self.assertEqual(command[command.index("--language") + 1], "python")
        self.assertEqual(command[command.index("--issue-type") + 1], "SQL Injection")
        self.assertEqual(definition["params"], [])

    def test_existing_rule_pipeline_adds_typescript_without_changing_definition(self):
        definition = {"id": "security-rules", "command": ["python", "-u", "manage_rules.py"], "params": [{"name": "language", "label": "Language", "type": "choice", "choices": ["java", "python"], "flag": "--language"}], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"security-rules": definition}):
            updated = server.get_pipeline("security-rules")
        values = server.normalize_params(updated, {"rule_id": "ts-review", "patterns": r"dangerous\(", "message": "Review", "match_example": "dangerous(value)", "nonmatch_example": "safe(value)", "language": "typescript"})
        command = server.build_command(updated, values)
        self.assertEqual(command[command.index("--language") + 1], "typescript")
        self.assertEqual(definition["params"][0]["choices"], ["java", "python"])

    def test_existing_rule_pipeline_updates_java_specific_default_labels(self):
        definition = {"id": "security-rules", "command": ["python", "-u", "manage_rules.py"], "description": "Add a tested local Java security rule", "params": [{"name": "match_text", "label": "Exact text to find in a Java line", "type": "string"}], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"security-rules": definition}):
            updated = server.get_pipeline("security-rules")
        names = [param["name"] for param in updated["params"]]
        self.assertEqual(names[:5], ["rule_id", "patterns", "message", "match_example", "nonmatch_example"])
        self.assertTrue({"language", "issue_type", "category", "severity", "redact", "include_comments"} <= set(names))
        self.assertIn("TypeScript", updated["description"])
        self.assertIn("TypeScript", server.pipeline_summary(definition)["description"])
        self.assertEqual(definition["params"][0]["label"], "Exact text to find in a Java line")

    def test_typescript_rule_pipeline_subprocess_updates_correct_rule_file(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            shutil.copyfile(Path(__file__).with_name("manage_rules.py"), root / "manage_rules.py")
            (root / "rules").mkdir()
            rules = root / "rules" / "typescript-local.json"
            rules.write_text("[]", encoding="utf-8")
            (root / "app.ts").write_text("dangerous(value);\n", encoding="utf-8")
            definition = server.validate_pipeline(server.pipeline_templates()["security_rules"])
            values = server.normalize_params(definition, {"rule_id": "custom-typescript", "patterns": r"dangerous\(", "message": "Review", "match_example": "dangerous(value)", "nonmatch_example": "safe(value)", "language": "typescript", "issue_type": "Code Injection"})
            result = subprocess.run(server.build_command(definition, values), cwd=root, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root), str(rules)], capture_output=True, text=True, check=True)
            self.assertTrue(any(row["check_id"] == "custom-typescript" for row in json.loads(result.stdout)["results"]))

    def test_full_python_scan_exports_issue_type(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('cursor.execute(f"SELECT * FROM users WHERE name = {name}")\n', encoding="utf-8")
            output = root / "results"
            with patch("scanner.subprocess.run", side_effect=AssertionError("external process used")):
                scan(root, output, "", {}, skip_accessibility=True)
            report = json.loads((output / "security_report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["python"]["scanned_files"], 1)
            rows = json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
            self.assertEqual(rows[0]["issue_type"], "SQL Injection")
            from openpyxl import load_workbook
            sheet = load_workbook(next(output.glob("*_SAST_SuppressionReport.xlsx"))).active
            self.assertEqual(sheet.cell(1, 14).value, "Issue type")
            self.assertEqual(sheet.cell(2, 14).value, "SQL Injection")

    def test_python_additional_rules_and_safe_alternatives(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('import yaml\nimport hashlib\nimport random\nimport requests\nimport ssl\nimport tempfile\nimport subprocess\nyaml.load(data, Loader=yaml.SafeLoader)\nyaml.load(data, Loader=yaml.Loader)\nhashlib.new("sha1")\nrandom.randint(1, 100)\nrequests.get(url, verify=False, timeout=5)\nssl._create_unverified_context()\ntempfile.mktemp()\narchive.extractall()\narchive.extractall(filter="data")\nsubprocess.run(args, shell=False)\n', encoding="utf-8")
            report = scan_python(root)
            self.assertEqual(report["errors"], [])
            self.assertEqual({row["check_id"] for row in report["results"]}, {"local-python-yaml-unsafe-loader", "local-python-weak-hash", "local-python-insecure-random", "local-python-requests-verify-false", "local-python-unverified-ssl-context", "local-python-tempfile-mktemp", "local-python-archive-extraction"})
            self.assertEqual(len(report["results"]), 7)

    def test_python_syntax_errors_fail_build_and_excluded_files_are_not_scanned(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "broken.py").write_text('def broken(:\n', encoding="utf-8")
            (root / "venv").mkdir()
            (root / "venv" / "ignored.py").write_text('eval(data)', encoding="utf-8")
            report = scan_python(root)
            self.assertEqual(report["scanned_files"], 0)
            self.assertEqual(report["errors"][0]["path"], "broken.py")
            self.assertEqual(report["skipped_directories"], ["venv"])
            with self.assertRaisesRegex(ValueError, "Python security scan errors"):
                scan(root, root / "results", "", {}, skip_accessibility=True)

    def test_angular_security_scanner_finds_sinks_not_comments(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.ts").write_text('const safe = "eval(input)";\n// element.innerHTML = value;\nsanitizer.bypassSecurityTrustHtml(value);\nelement.innerHTML = value;\neval(value);\n', encoding="utf-8")
            (root / "node_modules").mkdir()
            (root / "node_modules" / "ignored.ts").write_text("eval(value);", encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            self.assertEqual(report["scanned_files"], 1)
            self.assertEqual({row["check_id"] for row in report["results"]}, {"local-angular-security-bypass", "local-javascript-innerhtml", "local-javascript-eval"})
            self.assertIn("node_modules", report["skipped_directories"])

    def test_full_scan_accepts_angular_without_java(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.ts").write_text('sanitizer.bypassSecurityTrustHtml(value);', encoding="utf-8")
            (root / "app.html").write_text('<img src="test.png">', encoding="utf-8")
            output = root / "results"
            scan(root, output, "", {})
            report = json.loads((output / "security_report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["scanned_files"], 0)
            self.assertEqual(report["scripts"]["scanned_files"], 1)
            rows = json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
            self.assertEqual({row["category"] for row in rows}, {"Security", "Accessibility"})

    def test_accessibility_skips_and_reports_generated_output(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "index.html").write_text('<img src="test.png">', encoding="utf-8")
            (root / "dist").mkdir()
            (root / "dist" / "index.html").write_text('<img src="test.png">', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("accessibility.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["scanned_files"], 1)
            self.assertEqual(report["skipped_directories"], ["dist"])

    def test_angular_dynamic_accessible_names_are_reviewed_not_mislabeled(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.html").write_text('<img [alt]="description">\n<img [src]="url">\n<input [attr.aria-label]="label">', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("accessibility.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            checks = {row["check_id"]: row for row in report["results"]}
            self.assertIn("accessibility.html.angular.dynamic-alt-review", checks)
            self.assertIn("accessibility.html.angular.dynamic-label-review", checks)
            self.assertIn("accessibility.html.wcag/h37", checks)
            self.assertEqual(checks["accessibility.html.angular.dynamic-alt-review"]["extra"]["severity"], "WARNING")

    def test_rule_pipeline_produces_expected_arguments(self):
        definition = server.validate_pipeline(server.pipeline_templates()["security_rules"])
        values = server.normalize_params(definition, {"rule_id": "java-test", "patterns": r"exec\(", "message": "Review", "match_example": "exec(value)", "nonmatch_example": "safe(value)"})
        command = server.build_command(definition, values)
        self.assertIn("manage_rules.py", command)
        self.assertEqual(command[command.index("--patterns") + 1], r"exec\(")
        self.assertEqual(command[command.index("--nonmatch-example") + 1], "safe(value)")

    def test_rule_pipeline_command_updates_rules_used_by_scanner(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            shutil.copyfile(Path(__file__).with_name("manage_rules.py"), root / "manage_rules.py")
            (root / "rules").mkdir()
            rules = root / "rules" / "java-local.json"
            rules.write_text("[]", encoding="utf-8")
            (root / "App.java").write_text("class App { void f() { exec(value); } }", encoding="utf-8")
            definition = server.validate_pipeline(server.pipeline_templates()["security_rules"])
            values = server.normalize_params(definition, {"rule_id": "java-test", "patterns": r"exec\(", "message": "Review", "match_example": "exec(value)", "nonmatch_example": "safe(value)"})
            result = subprocess.run(server.build_command(definition, values), cwd=root, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(scan_java(root, rules)["results"][0]["check_id"], "java-test")

    def test_rule_manager_adds_literal_scanner_rule_and_rejects_bad_input(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            rules = root / "rules.json"
            rules.write_text("[]", encoding="utf-8")
            (root / "App.java").write_text("class App { void f() { exec(value); } }", encoding="utf-8")
            rule = add_rule("java-example", r"exec\(", "Review command", "exec(value)", "safe(value)", rules)
            self.assertEqual(scan_java(root, rules)["results"][0]["check_id"], rule["id"])
            with self.assertRaises(ValueError):
                add_rule("java-example", r"exec\(", "Review", "exec(value)", "safe(value)", rules)
            with self.assertRaises(ValueError):
                add_rule("java-other", r"exec\(", "Review", "safe(value)", "safe(value)", rules)
            with self.assertRaisesRegex(ValueError, "specific IP"):
                add_rule("java-ip", "10.1.2.3", "Review", "connect 10.1.2.3", "connect localhost", rules)
            sql = add_rule(
                "java-sql",
                "executeQuery\\s*\\([^)\\n]*\\+\nprepareStatement\\s*\\([^)\\n]*\\+",
                "Review dynamic SQL",
                'stmt.executeQuery("SELECT " + name);\nconn.prepareStatement("SELECT " + id);',
                "stmt.executeQuery(sql);",
                rules,
                issue_type="SQL Injection",
            )
            self.assertEqual(len(sql["patterns"]), 2)
            (root / "Sql.java").write_text('class Sql { void f() { stmt.executeQuery("SELECT " + name); conn.prepareStatement("SELECT " + id); } }\n', encoding="utf-8")
            sql_hits = [row for row in scan_java(root, rules)["results"] if row["check_id"] == "java-sql"]
            self.assertEqual(len(sql_hits), 1)
            self.assertEqual(sql_hits[0]["extra"]["issue_type"], "SQL Injection")
            self.assertEqual(json.loads(rules.read_text(encoding="utf-8")), [rule, sql])

    def test_folder_picker_returns_selection_or_cancellation(self):
        handler = Mock()
        with patch.object(server, "choose_directory", return_value="C:/repo"):
            server.api_browse_directory(handler)
        handler.send_json.assert_called_with({"path": "C:/repo"})
        with patch.object(server, "choose_directory", return_value=""):
            server.api_browse_directory(handler)
        handler.send_json.assert_called_with({"path": ""})
        with patch.object(server, "choose_directory", side_effect=RuntimeError("no desktop")):
            with self.assertRaises(server.ApiError):
                server.api_browse_directory(handler)

    def test_local_java_rules_detect_patterns_without_network(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "Example.java").write_text('class Example {\n  void f(String input) {\n    Runtime.getRuntime().exec("cmd " + input);\n    MessageDigest.getInstance("MD5");\n    // new Random();\n    new java.util.Random();\n  }\n}', encoding="utf-8")
            with patch("socket.socket.connect", side_effect=AssertionError("network used")), patch("subprocess.run", side_effect=AssertionError("external process used")):
                report = scan_java(root)
            self.assertEqual(report["scanned_files"], 1)
            self.assertEqual({row["check_id"] for row in report["results"]}, {"local-java-runtime-command-concatenation", "local-java-weak-digest", "local-java-insecure-random"})

    def test_suppression_survives_line_changes_but_not_code_changes(self):
        rows, _ = finding_rows({"results": [finding()]}, {})
        fingerprint = rows[0]["fingerprint"]
        decision = {"status": "False Positive", "justification": "Reviewed", "solution": "Not Applicable"}
        rows, suppressed = finding_rows({"results": [finding(line=20)]}, {fingerprint: decision})
        self.assertEqual(rows, [])
        self.assertEqual(suppressed[0]["justification"], "Reviewed")
        rows, _ = finding_rows({"results": [finding(snippet="dangerous_call(other)")]}, {fingerprint: decision})
        self.assertEqual(len(rows), 1)

    def test_duplicate_findings_have_distinct_ids(self):
        rows, _ = finding_rows({"results": [finding(), finding(line=9)]}, {})
        self.assertNotEqual(rows[0]["fingerprint"], rows[1]["fingerprint"])
        remaining, _ = finding_rows({"results": [finding(line=9)]}, {rows[0]["fingerprint"]: {"status": "False Positive"}})
        self.assertEqual(len(remaining), 1)

    def test_scan_errors_are_not_clean_results(self):
        with self.assertRaises(ValueError):
            finding_rows({"results": [], "errors": [{"message": "parse error"}]}, {})

    def test_scan_writes_results_and_excel(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            output = root / "results"
            (root / "app.java").write_text('class App { void f() { new java.util.Random(); } }', encoding="utf-8")
            with patch("scanner.subprocess.run", side_effect=AssertionError("external process used")):
                scan(root, output, "", {}, skip_accessibility=True)
            self.assertEqual(len(json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))), 1)
            from openpyxl import load_workbook
            workbook = load_workbook(next(output.glob("*_SAST_SuppressionReport.xlsx")))
            self.assertEqual(workbook.active.cell(2, 9).value, "app.java")
            self.assertIn("java.util.Random", workbook.active.cell(2, 12).value)

    def test_html_and_jsx_accessibility_findings_are_reported(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "index.html").write_text('<html><body><img src="test.png"></body></html>', encoding="utf-8")
            (root / "app.jsx").write_text('const App = () => <img src="test.png" />;', encoding="utf-8")
            script = Path(__file__).with_name("accessibility.js")
            result = subprocess.run(["node", str(script), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            self.assertEqual({row["path"] for row in report["results"]}, {"index.html", "app.jsx"})
            rows, _ = finding_rows(report, {})
            self.assertTrue(all(row["category"] == "Accessibility" for row in rows))

    def test_accessibility_detects_refresh_and_reports_unchecked_templates(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "index.html").write_text('<html><head><title>Home</title><meta http-equiv="refresh" content="10"></head><body><img src="ok.png" alt="Logo"></body></html>', encoding="utf-8")
            (root / "page.jsp").write_text('<img src="missing.png">', encoding="utf-8")
            result = subprocess.run(["node", str(Path(__file__).with_name("accessibility.js")), str(root)], capture_output=True, text=True, check=True)
            report = json.loads(result.stdout)
            self.assertEqual(report["errors"], [])
            self.assertEqual(report["unsupported_templates"], ["page.jsp"])
            self.assertTrue(any(row["check_id"].endswith(".meta-refresh") for row in report["results"]))
            self.assertFalse(any(row["check_id"].endswith(".wcag/h37") for row in report["results"]))

    def test_scan_combines_security_and_accessibility_results(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "index.html").write_text('<html><body><img src="test.png"></body></html>', encoding="utf-8")
            (root / "app.java").write_text('class App { void f() { new java.util.Random(); } }', encoding="utf-8")
            scan(root, root / "output", "", {})
            rows = json.loads((root / "output" / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
            self.assertEqual({row["category"] for row in rows}, {"Security", "Accessibility"})
            self.assertEqual([row["sr_no"] for row in rows], list(range(1, len(rows) + 1)))

    def test_accessibility_only_allows_no_java_and_records_skipped_security(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "index.html").write_text('<html><body><img src="test.png"></body></html>', encoding="utf-8")
            output = root / "results"
            scan(root, output, "", {}, accessibility_only=True)
            self.assertEqual(json.loads((output / "security_report.json").read_text(encoding="utf-8"))["skipped"], "accessibility-only")
            rows = json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
            self.assertTrue(any(row["category"] == "Accessibility" for row in rows))
            with self.assertRaisesRegex(ValueError, "cannot be combined"):
                scan(root, output, "", {}, skip_accessibility=True, accessibility_only=True)

    def test_backend_only_skips_accessibility_without_starting_node(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.java").write_text('class App { void f() { new java.util.Random(); } }', encoding="utf-8")
            with patch("scanner.subprocess.run", side_effect=AssertionError("external process used")) as run:
                scan(root, root / "output", "", {}, skip_accessibility=True)
            run.assert_not_called()
            report = json.loads((root / "output" / "accessibility.json").read_text(encoding="utf-8"))
            self.assertEqual(report["skipped"], "backend-only")
            rows = json.loads((root / "output" / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
            self.assertEqual(rows[0]["category"], "Security")

    def test_selected_security_language_excludes_other_languages(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('eval(value)\n', encoding="utf-8")
            (root / "app.java").write_text('class App { void f() { new java.util.Random(); } }', encoding="utf-8")
            (root / "app.js").write_text('eval(value);\n', encoding="utf-8")
            with patch("scanner.subprocess.run", side_effect=AssertionError("script scanner should not run")):
                scan(root, root / "output", "", {}, skip_accessibility=True, language="python")
            report = json.loads((root / "output" / "security_report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["selected_language"], "python")
            self.assertEqual(report["java_skipped"], "language selection")
            self.assertEqual(report["scripts"]["skipped"], "language selection")
            self.assertEqual({row["check_id"] for row in report["results"]}, {"local-python-dynamic-execution"})

    def test_java_and_script_language_selection_and_missing_source(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "app.py").write_text('eval(value)\n', encoding="utf-8")
            (root / "app.java").write_text('class App { void f() { new java.util.Random(); } }', encoding="utf-8")
            (root / "app.js").write_text('eval(value);\n', encoding="utf-8")
            for language, expected in (("java", "local-java-insecure-random"), ("javascript-typescript", "local-javascript-eval")):
                output = root / language
                with patch("scanner.scan_python", side_effect=AssertionError("Python scanner should not run")):
                    scan(root, output, "", {}, skip_accessibility=True, language=language)
                report = json.loads((output / "security_report.json").read_text(encoding="utf-8"))
                self.assertEqual(report["python"]["skipped"], "language selection")
                self.assertIn(expected, {row["check_id"] for row in report["results"]})
            (root / "app.java").unlink()
            with self.assertRaisesRegex(ValueError, "selected security language: java"):
                scan(root, root / "missing", "", {}, skip_accessibility=True, language="java")

    def test_existing_repository_pipeline_gets_backend_option(self):
        definition = {"id": "repo", "kind": "repo_scan", "params": [{"name": "config", "type": "string", "default": "auto"}], "jobs": []}
        with patch.object(server, "load_pipelines", return_value={"repo": definition}):
            result = server.get_pipeline("repo")
        self.assertEqual(result["params"][0]["flag"], "--skip-accessibility")
        language = next(param for param in result["params"] if param["name"] == "language")
        self.assertEqual(language["choices"], ["all", "java", "python", "javascript-typescript", "html"])
        self.assertEqual(language["default"], "all")
        self.assertEqual(definition["params"][0]["default"], "auto")

    def test_build_exposes_python_coverage_gaps(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "security_report.json").write_text(json.dumps({"python": {"scanned_files": 2, "unsupported_ast_rules": ["one", "two"]}}), encoding="utf-8")
            build = server.Build("repo", 1, {"kind": "repo_scan", "status": "success", "output_dir": str(root)})
            self.assertEqual(build.public()["python_unsupported_rules"], 2)
            (root / "security_report.json").write_text("invalid", encoding="utf-8")
            self.assertNotIn("python_unsupported_rules", build.public())

    def test_unsupported_repository_is_not_reported_clean(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(ValueError, "No Java source"):
                scan_java(Path(temporary))

    def test_excel_treats_source_text_as_text(self):
        from openpyxl import load_workbook
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            rows, _ = finding_rows({"results": [finding(snippet='=HYPERLINK("https://example.com")')]}, {})
            (output / "grouped_issues_with_ai.json").write_text(json.dumps(rows), encoding="utf-8")
            workbook = load_workbook(export_excel(output))
            self.assertEqual(workbook.active.cell(2, 12).value, '\'=HYPERLINK("https://example.com")')
            self.assertEqual(workbook.active.cell(2, 12).data_type, "s")

    def test_added_python_rules_detect_risks_and_skip_safe_calls(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "risky.py").write_text(
                'import marshal, tempfile, telnetlib, ftplib, hashlib, ssl\n'
                'from xml.etree import ElementTree\n'
                'marshal.loads(blob)\n'
                'dill.loads(blob)\n'
                'shelve.open(path)\n'
                'tempfile.mktemp()\n'
                'os.popen(command)\n'
                'telnetlib.Telnet(host)\n'
                'ftplib.FTP(host)\n'
                'ElementTree.parse(path)\n'
                'key = "AKIAIOSFODNN7EXAMPLE"\n'
                'pem = "-----BEGIN PRIVATE KEY-----"\n'
                '__import__(name)\n'
                'DEBUG = True\n'
                'SECRET_KEY = "example-secret"\n'
                'host = "0.0.0.0"\n'
                'hashlib.md5(data)\n'
                'ssl._create_unverified_context()\n'
                'exec(input())\n',
                encoding="utf-8",
            )
            (root / "safe.py").write_text(
                'import hashlib, tempfile\n'
                'hashlib.sha256(data)\n'
                'tempfile.NamedTemporaryFile()\n'
                'DEBUG = False\n'
                'host = "127.0.0.1"\n',
                encoding="utf-8",
            )
            report = scan_python(root)
            self.assertEqual(report["errors"], [])
            found = {row["check_id"] for row in report["results"] if row["path"] == "risky.py"}
            self.assertTrue({
                "local-python-marshal-loads",
                "local-python-dill-loads",
                "local-python-shelve-open",
                "local-python-tempfile-mktemp",
                "local-python-os-popen",
                "local-python-telnet",
                "local-python-ftp-cleartext",
                "local-python-xml-parse",
                "local-python-aws-access-key",
                "local-python-private-key-block",
                "local-python-dynamic-import-call",
                "local-python-debug-toolbar",
                "local-python-flask-secret-literal",
                "local-python-bind-all-string",
                "local-python-weak-hash-call",
                "local-python-ssl-unverified-context",
                "local-python-input-exec",
            } <= found, found)
            self.assertFalse(any(row["path"] == "safe.py" and row["check_id"].startswith("local-python-") and row["check_id"] in {
                "local-python-tempfile-mktemp", "local-python-debug-toolbar", "local-python-bind-all-string", "local-python-weak-hash-call",
            } for row in report["results"]))

    def test_deleting_a_pipeline_removes_its_local_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            pid = "repo-scan"
            source = root / "source"
            source.mkdir()
            builds = root / "data" / "builds" / pid / "3"
            builds.mkdir(parents=True)
            (builds / "build.json").write_text("{}", encoding="utf-8")
            (root / "data" / "suppressions" / pid).mkdir(parents=True)
            (root / "data" / "suppressions" / pid / "note.json").write_text("{}", encoding="utf-8")
            upload = root / "data" / "uploads" / "abcd1234"
            upload.mkdir(parents=True)
            (upload / "archive.zip").write_text("zip", encoding="utf-8")
            other = root / "data" / "uploads" / "kept"
            other.mkdir()
            pipelines = root / "pipelines.json"
            pipelines.write_text(json.dumps([{"id": pid}]), encoding="utf-8")
            build = server.Build(pid, 3, {"params": {"archive": str(upload / "archive.zip")}})
            kept = server.Build("other", 1, {"params": {"archive": str(other / "file.bin")}})
            with patch.object(server, "DATA_DIR", root / "data"), patch.object(server, "BUILDS_DIR", root / "data" / "builds"), \
                    patch.object(server, "UPLOADS_DIR", root / "data" / "uploads"), patch.object(server, "PIPELINES_FILE", pipelines), \
                    patch.dict(server.BUILDS, {(pid, 3): build, ("other", 1): kept}, clear=True):
                server.api_delete_pipeline(Mock(send_json=Mock()), pid)
            self.assertFalse((root / "data" / "builds" / pid).exists())
            self.assertFalse((root / "data" / "suppressions" / pid).exists())
            self.assertFalse(upload.exists())
            self.assertTrue(other.exists())
            self.assertEqual(json.loads(pipelines.read_text(encoding="utf-8")), [])
            self.assertNotIn((pid, 3), server.BUILDS)

    def test_fixed_source_is_not_carried_into_later_builds(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            old_dir, new_dir = root / "old", root / "new"
            old_dir.mkdir()
            new_dir.mkdir()
            rows, _ = finding_rows({"results": [finding()]}, {})
            rows[0]["justification"] = "Needs a fix"
            (old_dir / "results.json").write_text(json.dumps(rows), encoding="utf-8")
            (new_dir / "results.json").write_text("[]", encoding="utf-8")
            (new_dir / "suppressed_findings.json").write_text("[]", encoding="utf-8")
            meta = {"kind": "repo_scan", "params": {"source_dir": str(source)}, "results_file": "results.json"}
            earlier = server.Build("repo", 1, {**meta, "output_dir": str(old_dir), "status": "success"})
            current = server.Build("repo", 2, {**meta, "output_dir": str(new_dir)})
            current.pdef = {"export_command": []}
            with patch.dict(server.BUILDS, {("repo", 1): earlier}, clear=True), patch.object(server, "DATA_DIR", root / "data"):
                server.reconcile_repository_findings(current)
            carried = json.loads((new_dir / "results.json").read_text(encoding="utf-8"))
            self.assertEqual(carried, [])

    def test_build_review_persists_and_scopes_suppression(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            output = root / "build1"
            output.mkdir()
            rows, _ = finding_rows({"results": [finding()]}, {})
            (output / "grouped_issues_with_ai.json").write_text(json.dumps(rows), encoding="utf-8")
            build = server.Build("repo-one", 1, {
                "kind": "repo_scan", "params": {"source_dir": str(source)},
                "output_dir": str(output), "results_file": "grouped_issues_with_ai.json",
            })
            decision = {"status": "False Positive", "justification": "Reviewed source", "solution": "Not Applicable"}
            with patch.object(server, "DATA_DIR", root / "data"), patch.object(server, "get_pipeline", return_value={"export_command": []}):
                server.apply_decision(build, 1, decision, "manual")
                ledger = server.suppression_file(build)
                suppressions = json.loads(ledger.read_text(encoding="utf-8"))
                current, suppressed = finding_rows({"results": [finding(line=30)]}, suppressions)
                self.assertEqual(current, [])
                self.assertEqual(suppressed[0]["justification"], "Reviewed source")
                other_build = server.Build("repo-two", 1, build.meta)
                self.assertNotEqual(server.suppression_file(other_build), ledger)
                server.apply_decision(build, 1, {**decision, "status": "Open"}, "manual")
                self.assertEqual(json.loads(ledger.read_text(encoding="utf-8")), {})

    def test_restore_suppression_from_current_build(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            build = server.Build("repo", 2, {"kind": "repo_scan", "params": {"source_dir": str(source)}})
            fingerprint = "a" * 64
            handler = Mock()
            with patch.object(server, "DATA_DIR", root / "data"), patch.object(server, "results_context", return_value=({}, build, root)):
                server.write_json_atomic(server.suppression_file(build), {fingerprint: {"status": "False Positive"}})
                server.api_remove_suppression(handler, "repo", "2", fingerprint)
                self.assertEqual(json.loads(server.suppression_file(build).read_text(encoding="utf-8")), {})
                handler.send_json.assert_called_once_with({"removed": fingerprint})

    def test_unreviewed_findings_cannot_be_suppressed(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            rows, _ = finding_rows({"results": [finding()]}, {})
            (output / "results.json").write_text(json.dumps(rows), encoding="utf-8")
            build = server.Build("repo-one", 1, {"kind": "repo_scan", "output_dir": str(output), "results_file": "results.json"})
            with patch.object(server, "get_pipeline", return_value={"export_command": []}):
                with self.assertRaises(ValueError):
                    server.apply_decision(build, 1, {"status": "False Positive", "justification": "Awaiting review.", "solution": "Not Applicable"}, "manual")


if __name__ == "__main__":
    unittest.main()