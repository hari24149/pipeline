"use strict";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function highlightSource(text, spans) {
  const value = String(text ?? "");
  const ranges = (Array.isArray(spans) ? spans : []).slice(0, 5)
    .map((item) => [Number(item[0]), Number(item[1])])
    .filter((item) => Number.isFinite(item[0]) && Number.isFinite(item[1]) && item[1] > item[0] && item[0] >= 0 && item[0] < value.length)
    .sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const kept = [];
  let cursor = 0;
  for (const [start, end] of ranges) {
    const from = Math.max(start, cursor);
    const to = Math.min(end, value.length);
    if (to > from) kept.push([from, to]);
    cursor = Math.max(cursor, to);
    if (kept.length === 5) break;
  }
  if (!kept.length) return esc(value);
  let html = "";
  let pos = 0;
  kept.forEach(([start, end], index) => {
    html += esc(value.slice(pos, start));
    html += `<mark class="hit hit-${index + 1}">${esc(value.slice(start, end))}</mark>`;
    pos = end;
  });
  return html + esc(value.slice(pos));
}
const view = $("#view");

// ------------------------------------------------------------------ preferences (stored in this browser)
const PREF_DEFAULTS = {
  theme: "light", accent: "#3b5bdb", density: "comfortable", fontSize: 14, animations: true,
  refreshMs: 1500, stageBuilds: 5, timeFormat: "24h", defaultTab: "stages",
  consoleFollow: true, consoleWrap: true, consoleFont: 12.5, confirmDelete: true, toastSec: 4,
};
let PREFS = { ...PREF_DEFAULTS };
try { PREFS = { ...PREF_DEFAULTS, ...JSON.parse(localStorage.getItem("triage-prefs") || "{}") }; } catch { /* use defaults */ }

function applyPrefs() {
  const root = document.documentElement;
  const dark = PREFS.theme === "dark" || (PREFS.theme === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
  root.dataset.theme = dark ? "dark" : "light";
  root.dataset.density = PREFS.density;
  root.dataset.anim = PREFS.animations ? "on" : "off";
  root.style.setProperty("--accent", PREFS.accent);
  root.style.setProperty("--fs", `${PREFS.fontSize}px`);
  root.style.setProperty("--cfs", `${PREFS.consoleFont}px`);
}

function savePrefs(patch) {
  PREFS = { ...PREFS, ...patch };
  localStorage.setItem("triage-prefs", JSON.stringify(PREFS));
  applyPrefs();
}

const clockOptions = () => ({ hour: "2-digit", minute: "2-digit", hour12: PREFS.timeFormat === "system" ? undefined : PREFS.timeFormat === "12h" });

// Patch the live DOM in place so unchanged nodes keep their state and never re-animate.
function morph(parent, html) {
  const template = document.createElement("template");
  template.innerHTML = html;
  patchChildren(parent, template.content);
}

function patchChildren(current, next) {
  const oldNodes = [...current.childNodes];
  const newNodes = [...next.childNodes];
  for (let i = 0; i < Math.max(oldNodes.length, newNodes.length); i += 1) {
    const o = oldNodes[i], n = newNodes[i];
    if (!n) { o.remove(); continue; }
    if (!o) { current.append(n); continue; }
    if (o.nodeType !== n.nodeType || o.nodeName !== n.nodeName) { o.replaceWith(n); continue; }
    if (o.nodeType !== 1) { if (o.nodeValue !== n.nodeValue) o.nodeValue = n.nodeValue; continue; }
    const liveTimer = o.hasAttribute("data-start") && o.getAttribute("data-start") === n.getAttribute("data-start");
    for (const { name, value } of [...n.attributes]) if (o.getAttribute(name) !== value) o.setAttribute(name, value);
    for (const { name } of [...o.attributes]) if (!n.hasAttribute(name)) o.removeAttribute(name);
    if (o.tagName === "INPUT" || o.tagName === "TEXTAREA" || liveTimer) continue;
    patchChildren(o, n);
  }
}

let SESSION = "";
let routeId = 0;
let disposers = [];

async function api(method, path, body, retried = false) {
  const options = { method, headers: { "X-Triage-Token": SESSION } };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const response = await fetch("/api" + path, options);
  let data = {};
  try { data = await response.json(); } catch { /* non-JSON body */ }
  // The session token changes whenever the server restarts; fetch the new one and retry once.
  if (response.status === 403 && !retried && /session token/i.test(data.error || "")) {
    SESSION = (await (await fetch("/api/session")).json()).token;
    return api(method, path, body, true);
  }
  if (!response.ok) throw new Error(data.error || response.statusText);
  return data;
}

function toast(message, kind = "") {
  const el = document.createElement("div");
  el.className = "toast " + kind;
  el.textContent = message;
  $("#toasts").append(el);
  setTimeout(() => { el.style.transition = "opacity .3s"; el.style.opacity = "0"; setTimeout(() => el.remove(), 300); }, (kind === "error" ? PREFS.toastSec * 1.5 : PREFS.toastSec) * 1000);
}

function fmtDur(seconds) {
  if (seconds == null || isNaN(seconds)) return "-";
  seconds = Math.max(0, Math.round(seconds));
  const m = Math.floor(seconds / 60), s = seconds % 60;
  return m ? `${m}m ${String(s).padStart(2, "0")}s` : `${s}s`;
}
function fmtDurStarted(seconds) {
  if (seconds == null || isNaN(seconds)) return "-";
  return fmtDur(Math.max(1, seconds));
}
const fmtTime = (ts) => (ts ? new Date(ts * 1000).toLocaleString([], { hour12: PREFS.timeFormat === "system" ? undefined : PREFS.timeFormat === "12h" }) : "-");
const nowSec = () => Date.now() / 1000;
const isLive = (status) => status === "running" || status === "queued";
const ball = (status, extra = "") => `<span class="ball ${esc(status)} ${extra}"></span>`;

function setCrumbs(items) {
  $("#crumbs").innerHTML = items.map(([label, href]) => `<span class="sep"></span>${href ? `<a href="${href}">${esc(label)}</a>` : `<span>${esc(label)}</span>`}`).join("");
}

function poll(fn, ms = PREFS.refreshMs) {
  const id = setInterval(() => { if (!document.hidden) fn().catch(() => {}); }, ms);
  disposers.push(() => clearInterval(id));
}

// ------------------------------------------------------------------ modals
function openModal(html, { wide = false } = {}) {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="modal ${wide ? "wide" : ""}" role="dialog">${html}</div>`;
  const close = () => overlay.remove();
  overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) close(); });
  overlay.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  $("#modal-root").append(overlay);
  return { overlay, modal: $(".modal", overlay), close };
}

function confirmBox(message, okLabel = "Confirm") {
  return new Promise((resolve) => {
    const { modal, close } = openModal(`<h2>${esc(message)}</h2><div class="actions"><button class="btn" data-x="no">Cancel</button><button class="btn danger" data-x="yes">${esc(okLabel)}</button></div>`);
    modal.addEventListener("click", (e) => {
      const x = e.target.dataset.x;
      if (x) { close(); resolve(x === "yes"); }
    });
  });
}

// ------------------------------------------------------------------ router
function goPipeline(pid) {
  if (location.hash === `#/p/${pid}`) route();
  else location.hash = `#/p/${pid}`;
}
function cleanup() {
  disposers.forEach((fn) => { try { fn(); } catch { /* ignore */ } });
  disposers = [];
}

function route() {
  cleanup();
  routeId += 1;
  const parts = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  const guard = routeId;
  let task;
  if (!parts.length) task = renderDashboard(guard);
  else if (parts[0] === "p" && parts[1] && (!parts[2] || parts[2] === "stages")) task = renderPipeline(guard, parts[1], parts[2] === "stages");
  else if (parts[0] === "p" && /^\d+$/.test(parts[2] || "")) task = renderBuild(guard, parts[1], Number(parts[2]), parts[3] || PREFS.defaultTab);
  else { location.hash = "#/"; return; }
  task.catch((error) => {
    if (guard !== routeId) return;
    view.innerHTML = `<div class="card fade empty"><div class="big">&#9888;</div><h2>${esc(error.message)}</h2><a class="btn" href="#/">Back to dashboard</a></div>`;
  });
}

// ------------------------------------------------------------------ dashboard
async function renderDashboard(guard) {
  setCrumbs([]);
  let first = true;
  const draw = async () => {
    const pipelines = await api("GET", "/pipelines");
    if (guard !== routeId) return;
    const html = `<div class="${first ? "fade" : ""}">
      <div class="page-head"><h1>Pipelines</h1><div class="spacer"></div>
        <button class="btn primary" data-act="new-pipeline">+ New pipeline</button></div>
      ${pipelines.length ? pipelineTable(pipelines) : emptyState()}</div>`;
    if (first) view.innerHTML = html; else morph(view, html);
    first = false;
  };
  await draw();
  poll(draw);
}

function ago(ts) {
  if (!ts) return "N/A";
  const s = Math.max(0, nowSec() - ts);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} hr ${Math.floor((s % 3600) / 60)} min ago`;
  return `${Math.floor(s / 86400)} day(s) ago`;
}

function weather(recent) {
  const done = recent.filter((b) => b.status === "success" || b.status === "failed");
  if (!done.length) return { icon: "&#9729;", tip: "No completed builds yet" };
  const pct = Math.round((100 * done.filter((b) => b.status === "success").length) / done.length);
  const icon = pct >= 80 ? "&#9728;" : pct >= 60 ? "&#9925;" : pct >= 40 ? "&#9729;" : pct >= 20 ? "&#9748;" : "&#9928;";
  return { icon, tip: `Build stability: ${pct}% of the last ${done.length} builds succeeded` };
}

function pipelineTable(pipelines) {
  const link = (b, pid) => (b ? `<a href="#/p/${esc(pid)}/${b.id}">${ago(b.ended)} &middot; #${b.id}</a>` : `<span class="muted">N/A</span>`);
  return `<div class="jtable-wrap"><table class="jtable"><thead><tr><th>S</th><th>W</th><th>Name</th><th>Last Success</th><th>Last Failure</th><th>Last Duration</th><th></th></tr></thead><tbody>
    ${pipelines.map((p, i) => {
      const last = p.last;
      const w = weather(p.recent);
      const duration = last && last.started && last.ended ? fmtDur(last.ended - last.started) : "N/A";
      return `<tr style="animation-delay:${i * 50}ms"><td>${ball(last ? last.status : "queued", "big")}</td><td class="wx" title="${esc(w.tip)}">${w.icon}</td>
        <td><a class="pname" href="#/p/${esc(p.id)}">${esc(p.name)}</a><div class="muted small">${esc(p.description)}</div></td>
        <td>${link(p.last_success, p.id)}</td><td>${link(p.last_failure, p.id)}</td><td>${duration}</td>
        <td><button class="btn sm primary" data-act="build" data-pid="${esc(p.id)}" title="Build with Parameters">&#9654; Build</button></td></tr>`;
    }).join("")}</tbody></table></div>`;
}

function emptyState() {
  return `<div class="card empty"><div class="big">&#128640;</div><h2>No pipelines yet</h2>
    <p class="muted">Add your SAST and DAST pipelines. Start from a preset or define your own command.</p>
    <div class="row" style="justify-content:center"><button class="btn primary" data-act="new-pipeline" data-template="dast">+ DAST pipeline</button>
      <button class="btn primary" data-act="new-pipeline" data-template="sast">+ SAST pipeline</button>
      <button class="btn primary" data-act="new-pipeline" data-template="repo_scan">+ Repository scan</button>
      <button class="btn" data-act="new-pipeline" data-template="blank">Custom</button></div></div>`;
}

// ------------------------------------------------------------------ pipeline page
async function renderPipeline(guard, pid, full = false) {
  let first = true;
  let filter = "";
  let builds = [];
  let watching = null;
  let busy = false;
  let again = false;

  view.innerHTML = `<div class="split fade"><aside><div class="card"><div class="muted">Loading pipeline...</div></div></aside><section><div class="card"><div class="muted">Loading stage view...</div></div></section></div>`;

  const drawBuildList = () => {
    const q = filter.trim().toLowerCase();
    const today = new Date().toDateString();
    let group = "";
    const items = builds.filter((b) => !q || `#${b.id} ${b.status}`.includes(q)).map((b) => {
      const d = new Date((b.queued || 0) * 1000);
      const label = d.toDateString() === today ? "Today" : d.toLocaleDateString();
      const head = label !== group ? `<div class="bgroup">${esc(label)}</div>` : "";
      group = label;
      return `${head}<a class="bitem" href="#/p/${esc(pid)}/${b.id}">${ball(b.status)}<b>#${b.id}</b><span class="muted">${d.toLocaleTimeString([], clockOptions())}</span></a>`;
    });
    morph($("#blist"), items.join("") || `<div class="muted small" style="padding:8px 12px">No builds</div>`);
  };

  // Follow the running build's event stream so every stage change shows immediately.
  const watchLive = () => {
    const live = builds.find((b) => isLive(b.status));
    if (watching && (!live || watching.id !== live.id)) { watching.es.close(); watching = null; }
    if (!live || watching) return;
    const es = new EventSource(`/api/pipelines/${pid}/builds/${live.id}/events?from=999999999`);
    let timer = 0;
    const refresh = () => { clearTimeout(timer); timer = setTimeout(() => safeDraw().catch(() => {}), 100); };
    es.addEventListener("state", refresh);
    es.addEventListener("end", () => { refresh(); es.close(); });
    es.onerror = () => { es.close(); watching = null; };
    watching = { id: live.id, es };
  };
  disposers.push(() => { if (watching) watching.es.close(); });

  const draw = async () => {
    const data = await api("GET", `/pipelines/${pid}`);
    if (guard !== routeId) return;
    const { pipeline: p, permalinks: pl } = data;
    builds = data.builds;
    setCrumbs([["Dashboard", "#/"], [p.name]]);
    const shown = Math.max(1, PREFS.stageBuilds);
    const link = (label, n) => (n ? `<a href="#/p/${pid}/${n}">${label} (#${n})</a>` : `<span class="muted">${label}: -</span>`);
    const html = `<div class="${first ? "fade " : ""}split">
      <aside>
        <nav class="jnav">
          <a class="${full ? "" : "active"}" href="#/p/${esc(pid)}"><span class="ni">&#9636;</span>Status</a>
          <button data-act="build" data-pid="${esc(pid)}"><span class="ni">&#9655;</span>Build with Parameters</button>
          <a class="${full ? "active" : ""}" href="#/p/${esc(pid)}/stages"><span class="ni">&#128269;</span>Full Stage View</a>
          <button data-act="edit-pipeline" data-pid="${esc(pid)}"><span class="ni">&#9881;</span>Configure</button>
          <button data-act="delete-pipeline" data-pid="${esc(pid)}"><span class="ni">&#128465;</span>Delete Pipeline</button>
        </nav>
        <div class="bpanel"><div class="bhead">Builds</div>
          <input type="text" id="bfilter" placeholder="Filter" value="${esc(filter)}"><div id="blist"></div></div>
      </aside>
      <section>
        <div class="ptitle">${bigIcon(builds[0] ? builds[0].status : "none")}<h1>${esc(p.name)}</h1></div>
        <div class="muted" style="margin:-6px 0 14px 50px">${esc(p.description)}</div>
        <div class="perma">${link("Last build", pl.last_build)}${link("Last successful", pl.last_successful)}${link("Last failed", pl.last_failed)}${link("Last completed", pl.last_completed)}</div>
        <h2 class="sv-title">${full ? "Full Stage View" : "Stage View"}</h2>${stageView(p, full ? builds : builds.slice(0, shown))}
        ${!full && builds.length > shown ? `<a href="#/p/${esc(pid)}/stages" class="small">Show all ${builds.length} builds</a>` : ""}
      </section></div>`;
    if (first) {
      view.innerHTML = html;
      $("#bfilter").addEventListener("input", (e) => { filter = e.target.value; drawBuildList(); });
      first = false;
    } else morph(view, html);
    drawBuildList();
    watchLive();
  };
  const safeDraw = async () => {
    if (busy) { again = true; return; }
    busy = true;
    try { await draw(); } finally { busy = false; }
    if (again) { again = false; await safeDraw(); }
  };
  await draw();
  poll(safeDraw);
  const tick = setInterval(() => {
    $$("[data-start]").forEach((el) => { el.textContent = fmtDurStarted(nowSec() - Number(el.dataset.start)); });
  }, 1000);
  disposers.push(() => clearInterval(tick));
}

function bigIcon(status) {
  const symbol = { success: "&#10003;", failed: "&#10005;", aborted: "&#9632;", queued: "&hellip;" }[status] || "";
  return `<span class="bigicon ${esc(status)}">${symbol}</span>`;
}

function stageView(pipeline, builds) {
  if (!pipeline.stages.length) return `<div class="muted">No stages defined. Add stages in Configure to see per-stage timing.</div>`;
  if (!builds.length) return `<div class="muted">Nothing built yet. Use Build with Parameters.</div>`;
  const durOf = (s) => (s.start ? (s.end || nowSec()) - s.start : null);
  const stats = pipeline.stages.map((_, i) => {
    const values = builds.map((b) => b.stages[i]).filter((s) => s && s.status === "success" && s.end).map(durOf);
    if (!values.length) return null;
    return { avg: values.reduce((a, b) => a + b, 0) / values.length, min: Math.min(...values), max: Math.max(...values) };
  });
  const fileParam = pipeline.params.find((p) => p.type === "file");
  const mini = (st) => (st ? `<div class="mini"><i style="left:${(st.min / st.max) * 100}%;width:${Math.max(4, ((st.avg - st.min) / st.max) * 100)}%"></i></div>` : "");
  const cell = (s, b) => {
    const dur = s && s.start ? fmtDurStarted(durOf(s)) : fmtDur(durOf(s));
    if (s.status === "success") return `<div class="cell success">${dur}</div>`;
    if (s.status === "failed") return `<div class="cell failed"><b>${dur}</b><em>failed</em></div>`;
    if (s.status === "running") {
      const p = b.progress && b.progress.total ? b.progress : null;
      return `<div class="cell running"><span data-start="${s.start}">${dur}</span>${p ? `<small>${p.done}/${p.total}</small>` : ""}<div class="bar ${p ? "" : "indeterminate"}"><i style="width:${p ? Math.round((p.done / p.total) * 100) : 0}%"></i></div></div>`;
    }
    if (s.status === "aborted") return `<div class="cell failed"><em>aborted</em></div>`;
    return `<div class="cell none"></div>`;
  };
  return `<div class="jsv-wrap"><table class="jsv"><thead><tr><th class="corner"></th>${pipeline.stages.map((s) => `<th>${esc(s.name)}</th>`).join("")}</tr></thead><tbody>
    <tr class="avg"><td class="bcol">Average stage times:</td>${stats.map((st) => `<td><div class="cell avgc">${st ? fmtDurStarted(st.avg) : "-"}${mini(st)}</div></td>`).join("")}</tr>
    ${builds.map((b) => {
      const d = new Date((b.queued || 0) * 1000);
      const target = fileParam && b.params[fileParam.name] ? String(b.params[fileParam.name]).split(/[\\/]/).pop() : "No Changes";
      return `<tr class="${esc(b.status)}"><td class="bcol"><a class="binfo" href="#/p/${esc(pipeline.id)}/${b.id}"><span class="bnum ${esc(b.status)}">#${b.id}</span>
        <span class="bdate">${d.toLocaleDateString([], { month: "short", day: "numeric" })}<br>${d.toLocaleTimeString([], clockOptions())}</span><span class="bchg" title="${esc(target)}">${esc(target)}</span></a></td>
        ${pipeline.stages.map((_, i) => `<td>${cell(b.stages[i] || { status: "pending" }, b)}</td>`).join("")}</tr>`;
    }).join("")}
  </tbody></table></div>`;
}

// ------------------------------------------------------------------ build page
async function renderBuild(guard, pid, number, initialTab) {
  const [pdata, initial] = await Promise.all([api("GET", `/pipelines/${pid}`), api("GET", `/pipelines/${pid}/builds/${number}`)]);
  if (guard !== routeId) return;
  const pipeline = pdata.pipeline;
  let build = initial;
  let tab = initialTab;
  let lineCount = 0;
  let follow = PREFS.consoleFollow;
  let es = null;
  let resultsLoaded = false;
  let pending = [];
  let raf = 0;

  setCrumbs([["Dashboard", "#/"], [pipeline.name, `#/p/${pid}`], [`#${number}`]]);
  view.innerHTML = `<div class="fade split">
    <aside><nav class="jnav">
      <a href="#/p/${esc(pid)}"><span class="ni">&larr;</span>Back to Pipeline</a>
      <button class="navtab" data-tab="stages"><span class="ni">&#9636;</span>Status</button>
      <button class="navtab" data-tab="console"><span class="ni">&#9000;</span>Console Output</button>
      <button class="navtab" data-tab="results"><span class="ni">&#128202;</span>Results &amp; Excel</button>
      <hr><div id="bactions"></div></nav></aside>
    <section>
    <div class="ptitle" id="head"></div>
    <div id="banner"></div>
    <section data-pane="stages"><div class="card"><div id="stages"></div><div id="meta" class="muted small" style="margin-top:8px"></div></div></section>
    <section data-pane="console" hidden>
      <div class="row" style="margin-bottom:10px"><label class="switch"><input type="checkbox" id="follow" checked> Follow</label>
        <label class="switch"><input type="checkbox" id="errs"> Errors only</label><div class="spacer"></div>
        <a class="btn sm" href="/api/pipelines/${esc(pid)}/builds/${number}/console">Download</a></div>
      <div class="console" id="console"></div></section>
    <section data-pane="results" hidden><div id="results"></div></section></section></div>`;

  const consoleEl = $("#console");
  $("#follow").checked = follow;
  consoleEl.classList.toggle("nowrap", !PREFS.consoleWrap);

  function drawHead() {
    const live = isLive(build.status);
    const jobInfo = build.job && build.job.name ? ` &middot; job ${esc(build.job.name)}` : "";
    morph($("#head"), `${bigIcon(build.status === "running" ? "none" : build.status)}<div><h1>Build #${number}</h1><div class="muted small">${esc(pipeline.name)}${jobInfo} &middot; started ${fmtTime(build.started || build.queued)}${build.rebuild_of ? ` &middot; rebuild of #${build.rebuild_of}` : ""}</div></div>`);
    morph($("#bactions"), `${live ? `<button data-act="stop"><span class="ni">&#9632;</span>Stop build</button>` : `<button data-act="rebuild"><span class="ni">&#8635;</span>Rebuild</button><button data-act="rebuild-params"><span class="ni">&#9655;</span>Rebuild with changes</button>`}
      ${build.excel ? `<a href="/api/pipelines/${esc(pid)}/builds/${number}/excel"><span class="ni">&#8681;</span>Download Excel</a>` : ""}
      ${live ? "" : `<button data-act="delete-build"><span class="ni">&#128465;</span>Delete build</button>`}`);
    const banner = document.createElement("div");
    const total = build.ended && build.started ? fmtDur(build.ended - build.started) : "";
    if (build.status === "failed") banner.innerHTML = `<div class="banner failed"><b>Build failed</b><span class="muted">${esc(failureHint())}</span><div class="spacer"></div><button class="btn sm" data-tab="console">View console</button></div>`;
    else if (build.status === "success") banner.innerHTML = `<div class="banner success"><svg class="check" viewBox="0 0 26 26"><path d="M5 13l5 5 11-11"/></svg><b>Build succeeded</b><span class="muted">in ${total}</span><div class="spacer"></div>${build.has_results ? `<button class="btn sm" data-tab="results">Review results</button>` : ""}</div>`;
    else if (build.status === "aborted") banner.innerHTML = `<div class="banner aborted"><b>Build aborted</b></div>`;
    else if (build.status === "queued") banner.innerHTML = `<div class="banner queued"><b>Queued</b><span class="muted">waiting for the previous build of this pipeline</span></div>`;
    else banner.innerHTML = `<div class="banner running">${ball("running")}<b>Running</b><span class="muted" data-start="${build.started}"></span></div>`;
    if (build.kind === "repo_scan" && build.status === "success") {
      const coverage = build.python_unsupported_rules ? ` ${Number(build.python_unsupported_rules)} Python rules were not checked.` : "";
      banner.innerHTML += `<div class="banner queued"><b>Security review required</b><span>Zero findings do not establish production readiness.${esc(coverage)}</span><button class="btn sm" data-tab="console">View scan details</button></div>`;
    }
    morph($("#banner"), banner.innerHTML);
  }

  function failureHint() {
    const failed = build.stages.find((s) => s.status === "failed");
    return failed ? `Failed in stage "${failed.name}"` : "See the console output for details";
  }

  function drawStages() {
    const p = build.progress;
    morph($("#stages"), build.stages.length
      ? `<div class="stages">${build.stages.map((s, i) => {
          const dur = s.start ? (s.end || nowSec()) - s.start : null;
          const running = s.status === "running";
          const pct = running && p && p.total ? Math.round((p.done / p.total) * 100) : 0;
          const eta = running && p && p.done && dur ? fmtDurStarted((dur * (p.total - p.done)) / p.done) : "";
          const icon = { success: "&#10003;", failed: "&#10005;", skipped: "&ndash;", aborted: "&#9632;", pending: "", running: "" }[s.status] ?? "";
          return `<div class="stage ${esc(s.status)}" style="animation-delay:${i * 40}ms"><div class="top"><span class="ico">${icon}</span>${esc(s.name)}</div>
            <div class="dur" ${running ? `data-start="${s.start}"` : ""}>${s.status === "pending" ? "waiting" : s.status === "skipped" ? "skipped" : s.start ? fmtDurStarted(dur) : fmtDur(dur)}</div>
            ${running ? `<div class="bar ${p && p.total ? "" : "indeterminate"}"><i style="width:${pct}%"></i></div>${p && p.total ? `<div class="dur">${p.done}/${p.total} &middot; ${pct}%${eta ? ` &middot; ~${eta} left` : ""}</div>` : ""}` : ""}</div>`;
        }).join("")}</div>`
      : `<div class="muted">This pipeline defines no stages; open Console Output to follow the run.</div>`);
    morph($("#meta"), `Status: <span class="tag ${esc(build.status)}">${esc(build.status)}</span> &middot; Output: <span class="mono">${esc(build.output_dir || "-")}</span>`);
  }

  function flushLines() {
    raf = 0;
    const frag = document.createDocumentFragment();
    for (const [index, entry] of pending) {
      const div = document.createElement("div");
      div.className = `ln ${entry.l}`;
      div.innerHTML = `<span class="no">${index}</span><span class="tx">${esc(entry.t)}</span>`;
      frag.append(div);
    }
    pending = [];
    $(".cursor", consoleEl)?.remove();
    consoleEl.append(frag);
    if (isLive(build.status)) consoleEl.insertAdjacentHTML("beforeend", `<span class="cursor"></span>`);
    if (follow) consoleEl.scrollTop = consoleEl.scrollHeight;
  }

  function connect() {
    es = new EventSource(`/api/pipelines/${pid}/builds/${number}/events?from=${lineCount}`);
    es.addEventListener("log", (e) => {
      lineCount += 1;
      pending.push([lineCount, JSON.parse(e.data)]);
      if (!raf) raf = requestAnimationFrame(flushLines);
    });
    es.addEventListener("state", (e) => {
      const wasLive = isLive(build.status);
      build = JSON.parse(e.data);
      consoleEl.dataset.status = build.status;
      drawHead(); drawStages();
      if (wasLive && !isLive(build.status)) { resultsLoaded = false; if (tab === "results") loadResults(); }
    });
    es.addEventListener("end", () => { es.close(); $(".cursor", consoleEl)?.remove(); });
    es.onerror = () => {
      es.close();
      if (isLive(build.status)) setTimeout(() => { if (guard === routeId) connect(); }, 1500);
    };
  }

  function showTab(name, remember = true) {
    tab = name;
    $$(".navtab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
    $$("[data-pane]").forEach((pane) => { pane.hidden = pane.dataset.pane !== name; });
    if (remember) history.replaceState(null, "", `#/p/${pid}/${number}/${name}`);
    if (name === "console" && follow) consoleEl.scrollTop = consoleEl.scrollHeight;
    if (name === "results") loadResults();
  }

  async function loadResults() {
    if (resultsLoaded) return;
    resultsLoaded = true;
    await mountResults($("#results"), pid, number, build, guard, () => routeId);
  }

  view.firstElementChild.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab]");
    if (t) showTab(t.dataset.tab);
  });
  $("#follow").addEventListener("change", (e) => { follow = e.target.checked; });
  $("#errs").addEventListener("change", (e) => consoleEl.classList.toggle("errors-only", e.target.checked));
  consoleEl.addEventListener("wheel", () => { if (follow) { follow = false; $("#follow").checked = false; } }, { passive: true });

  view._buildActions = {
    stop: async () => { await api("POST", `/pipelines/${pid}/builds/${number}/stop`); toast("Stopping build..."); },
    rebuild: async () => { const b = await api("POST", `/pipelines/${pid}/build`, { rebuild_of: number }); toast(`Rebuild queued as #${b.id}`, "ok"); goPipeline(pid); },
    "rebuild-params": () => openBuildModal(pipeline, build.params, number, build.job?.id),
    "delete-build": async () => {
      if (!PREFS.confirmDelete || await confirmBox(`Delete build #${number}? Its console log is removed; output files are kept.`, "Delete")) {
        await api("DELETE", `/pipelines/${pid}/builds/${number}`); location.hash = `#/p/${pid}`;
      }
    },
  };
  disposers.push(() => { delete view._buildActions; es && es.close(); if (raf) cancelAnimationFrame(raf); });

  const tick = setInterval(() => {
    $$("[data-start]").forEach((el) => {
      const start = Number(el.dataset.start);
      if (start) el.textContent = el.classList.contains("muted") ? `elapsed ${fmtDurStarted(nowSec() - start)}` : fmtDurStarted(nowSec() - start);
    });
  }, 1000);
  disposers.push(() => clearInterval(tick));

  consoleEl.dataset.status = build.status;
  drawHead(); drawStages(); connect();
  showTab(["stages", "console", "results"].includes(tab) ? tab : "stages", false);
}

// ------------------------------------------------------------------ results / live excel editor
async function mountResults(container, pid, number, build, guard, currentRoute) {
  if (!build.has_results) {
    container.innerHTML = `<div class="card empty"><div class="big">&#128202;</div><h2>${isLive(build.status) ? "Results appear when the AI and merge stages finish" : "No results for this build"}</h2></div>`;
    return;
  }
  let data;
  try { data = await api("GET", `/pipelines/${pid}/builds/${number}/results`); }
  catch (error) { container.innerHTML = `<div class="card empty"><h2>${esc(error.message)}</h2></div>`; return; }
  if (guard !== currentRoute()) return;

  const { rows, columns, statuses } = data;
  if (data.repository_scan && !columns.some((column) => column.key === "issue_type")) {
    const category = columns.findIndex((column) => column.key === "category");
    columns.splice(category < 0 ? 0 : category + 1, 0, { key: "issue_type", label: "Issue type" });
  }
  const statusClass = (s) => (s === "Open" ? "open" : s === "Fixed" ? "fixed" : "fp");
  const severities = [...new Set(rows.map((r) => r.severity).filter(Boolean))];
  const issueTypes = [...new Set(rows.map((r) => r.issue_type).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b)));
  let statusFilter = "";
  const base = `/pipelines/${pid}/builds/${number}`;
  const badge = (source) => (source === "manual" ? `<span class="badge">edited</span>` : source === "reevaluated" ? `<span class="badge ai2">re-evaluated</span>` : "");

  container.innerHTML = `<div class="card fade">
    <div class="row" style="margin-bottom:12px">
      <input type="text" id="q" placeholder="Search findings or remarks..." style="max-width:300px">
      <select id="sev" style="width:150px"><option value="">All severities</option>${severities.map((s) => `<option>${esc(s)}</option>`).join("")}</select>
      <select id="itype" style="width:220px"><option value="">All issue types</option>${issueTypes.map((s) => `<option>${esc(s)}</option>`).join("")}</select>
      <div class="chips" id="chips"></div><div class="spacer"></div>
      <span class="sync" id="sync">All changes saved</span>
      ${data.can_reevaluate ? '<button class="btn sm" id="bulk" disabled>Review selected with AI</button>' : ""}
      ${data.excel ? `<a class="btn sm primary" id="dl" href="/api${base}/excel">Download Excel</a>` : ""}</div>
    <div class="sheet-wrap"><table class="sheet"><thead><tr><th style="width:30px"><input type="checkbox" id="all"></th>
      ${columns.map((c) => `<th>${esc(c.label)}</th>`).join("")}<th>Status</th><th style="min-width:340px">Application Team Remarks</th><th style="min-width:240px">Solution Applied</th><th></th></tr></thead>
      <tbody id="rows">${rows.map(rowHtml).join("")}</tbody></table></div>
    <div class="muted small" style="margin-top:8px">${data.repository_scan ? "Matched places are colored, up to five per finding. Use Review with AI on one issue. Limited checks do not prove code is safe. False positives with a review reason are suppressed in future scans of this repository." : "Edit any cell: changes save automatically and the Excel report is regenerated. Use Review with AI to evaluate one finding again."}</div>
    ${data.repository_scan ? `<details style="margin-top:12px"><summary id="suppression-count"></summary><div id="suppressions"></div></details>` : ""}</div>`;

  function drawSuppressions(items) {
    $("#suppression-count", container).textContent = `Suppressed findings (${items.length})`;
    $("#suppressions", container).innerHTML = items.map((item) => `<div class="row" data-suppression="${esc(item.fingerprint)}"><span>${esc(item.issue_name || item.rule_id || item.fingerprint)} ${item.file_path ? `&middot; ${esc(item.file_path)}` : ""} &middot; ${esc(item.justification)}</span><div class="spacer"></div><button class="btn sm" data-restore="${esc(item.fingerprint)}">Restore</button></div>`).join("");
  }

  if (data.repository_scan) drawSuppressions(data.suppressions);
  if (data.repository_scan) $("#suppressions", container).addEventListener("click", async (event) => {
    const fingerprint = event.target.dataset.restore;
    if (!fingerprint) return;
    try {
      await api("DELETE", `${base}/suppressions/${fingerprint}`);
      const current = await api("GET", `${base}/results`);
      drawSuppressions(current.suppressions);
      toast("Suppression removed for future scans", "ok");
    } catch (error) { toast(error.message, "error"); }
  });

  function rowHtml(r) {
    const cells = columns.map((c) => `<td>${c.key === "severity" ? `<span class="sev ${esc(String(r.severity).toLowerCase())}">${esc(r.severity)}</span>` : c.key === "source_code" ? `<code class="src-line">${highlightSource(r.source_code, r.highlights)}</code>` : esc(r[c.key])}</td>`).join("");
    return `<tr data-sr="${r.sr_no}"><td><input type="checkbox" class="pick"></td>${cells}
      <td><select class="st ${statusClass(r.status)}" data-f="status">${statuses.map((s) => `<option ${s === r.status ? "selected" : ""}>${s}</option>`).join("")}</select></td>
      <td><textarea data-f="justification">${esc(r.justification)}</textarea></td><td><textarea data-f="solution">${esc(r.solution)}</textarea></td>
      <td><button class="btn sm" data-review>Review with AI</button><div class="src">${badge(r.source)}</div></td></tr>`;
  }
  const tbody = $("#rows", container);
  const sync = $("#sync", container);
  const rowOf = (sr) => $(`tr[data-sr="${sr}"]`, tbody);
  const grow = (ta) => { ta.style.height = "auto"; ta.style.height = Math.max(52, ta.scrollHeight) + "px"; };
  $$("textarea", tbody).forEach(grow);

  function drawChips() {
    const counts = Object.fromEntries(statuses.map((s) => [s, 0]));
    rows.forEach((r) => { counts[r.status] = (counts[r.status] || 0) + 1; });
    $("#chips", container).innerHTML = `<span class="chip ${statusFilter ? "" : "on"}" data-s="">All ${rows.length}</span>` +
      statuses.map((s) => `<span class="chip ${statusFilter === s ? "on" : ""}" data-s="${esc(s)}">${esc(s)} ${counts[s]}</span>`).join("");
  }

  function applyFilter() {
    const q = $("#q", container).value.toLowerCase();
    const sev = $("#sev", container).value;
    const issueType = $("#itype", container).value;
    rows.forEach((r) => {
      const tr = rowOf(r.sr_no);
      const text = `${r.issue_name} ${r.issue_type || ""} ${r.rule_id || ""} ${r.file_path || ""} ${r.justification} ${r.solution}`.toLowerCase();
      tr.hidden = !((!q || text.includes(q)) && (!sev || r.severity === sev) && (!issueType || r.issue_type === issueType) && (!statusFilter || r.status === statusFilter));
    });
  }

  function setSync(state, text) { sync.className = `sync ${state}`; sync.textContent = text; }

  function updateRow(tr, row) {
    const index = rows.findIndex((r) => r.sr_no === row.sr_no);
    rows[index] = { ...rows[index], ...row };
    const select = $("select", tr);
    select.value = row.status; select.className = `st ${statusClass(row.status)}`;
    $$("textarea", tr).forEach((ta) => { ta.value = row[ta.dataset.f]; grow(ta); });
    $(".src", tr).innerHTML = badge(row.source);
    tr.classList.remove("err"); tr.classList.add("flash");
    setTimeout(() => tr.classList.remove("flash"), 1300);
    drawChips();
  }

  function saveRow(tr) {
    tr._chain = (tr._chain || Promise.resolve()).then(async () => {
      const body = {};
      $$("[data-f]", tr).forEach((el) => { body[el.dataset.f] = el.value; });
      setSync("saving", "Saving...");
      try {
        const result = await api("PUT", `${base}/results/${tr.dataset.sr}`, body);
        updateRow(tr, result.row);
        if (data.repository_scan) {
          const current = await api("GET", `${base}/results`);
          drawSuppressions(current.suppressions);
        }
        if (result.export_error) setSync("err", "Saved, but Excel export failed"), toast(result.export_error, "error");
        else setSync("ok", `Saved & Excel synced ${new Date().toLocaleTimeString()}`);
      } catch (error) {
        tr.classList.add("err");
        setSync("err", "Not saved"); toast(error.message, "error");
      }
    });
  }

  tbody.addEventListener("input", (e) => {
    const tr = e.target.closest("tr");
    if (e.target.tagName === "TEXTAREA") { grow(e.target); setSync("saving", "Editing..."); clearTimeout(tr._t); tr._t = setTimeout(() => saveRow(tr), 900); }
  });
  tbody.addEventListener("change", (e) => {
    const tr = e.target.closest("tr");
    if (e.target.dataset.f === "status") { e.target.className = `st ${statusClass(e.target.value)}`; saveRow(tr); }
    if (e.target.classList.contains("pick") && $("#bulk", container)) $("#bulk", container).disabled = !$$(".pick:checked", tbody).length;
  });
  tbody.addEventListener("focusout", (e) => { const tr = e.target.closest("tr"); if (tr && tr._t) { clearTimeout(tr._t); tr._t = 0; saveRow(tr); } });
  tbody.addEventListener("click", (e) => { if (e.target.hasAttribute("data-review")) review([Number(e.target.closest("tr").dataset.sr)]); });
  $("#all", container).addEventListener("change", (e) => {
    $$("tr:not([hidden]) .pick", tbody).forEach((c) => { c.checked = e.target.checked; });
    if ($("#bulk", container)) $("#bulk", container).disabled = !$$(".pick:checked", tbody).length;
  });
  if ($("#bulk", container)) $("#bulk", container).addEventListener("click", () => review($$(".pick:checked", tbody).map((c) => Number(c.closest("tr").dataset.sr))));
  $("#q", container).addEventListener("input", applyFilter);
  $("#sev", container).addEventListener("change", applyFilter);
  $("#itype", container).addEventListener("change", applyFilter);
  $("#chips", container).addEventListener("click", (e) => { const c = e.target.closest(".chip"); if (c) { statusFilter = c.dataset.s; drawChips(); applyFilter(); } });

  function review(list) {
    const single = list.length === 1 ? rows.find((r) => r.sr_no === list[0]) : null;
    const { modal, close } = openModal(`<h2>${single ? `Review: ${esc(single.issue_name)}` : `Re-evaluate ${list.length} findings`}</h2>
      ${single ? `<div class="muted small" style="margin-bottom:10px">Currently <b>${esc(single.status)}</b> &middot; ${esc(single.severity)} &middot; ${esc(single.issue_type || "No issue type")} &middot; ${esc(single.occurrences)} occurrence(s)</div><div id="evidence" class="field"><div class="muted">Loading evidence...</div></div>` : ""}
      <div class="field"><label>Note for the AI (optional)</label><textarea id="note" rows="3" placeholder="e.g. This endpoint requires authentication, so it is not exposed externally."></textarea></div>
      ${data.can_reevaluate ? "" : `<div class="err-text">Set the bridge token in Settings to enable AI re-evaluation.</div>`}
      <div class="actions"><button class="btn" data-x="close">Close</button><button class="btn primary" data-x="go" ${data.can_reevaluate ? "" : "disabled"}>Review with AI</button></div>`, { wide: !!single });
    if (single) {
      api("GET", `${base}/results/${single.sr_no}/evidence`).then(({ files, highlights }) => {
        const names = Object.keys(files);
        const show = (name) => name === "source.txt" ? highlightSource(files[name], highlights) : esc(files[name]);
        $("#evidence", modal).innerHTML = names.length
          ? `<div class="chips" style="margin-bottom:8px">${names.map((n, i) => `<span class="chip ${i ? "" : "on"}" data-f="${esc(n)}">${esc(n)}</span>`).join("")}</div><pre class="ev" id="evbody">${show(names[0])}</pre>`
          : `<div class="muted">No evidence files found for this finding.</div>`;
        $("#evidence", modal).addEventListener("click", (e) => {
          const chip = e.target.closest(".chip"); if (!chip) return;
          $$("#evidence .chip", modal).forEach((c) => c.classList.toggle("on", c === chip));
          $("#evbody", modal).innerHTML = show(chip.dataset.f);
        });
      }).catch(() => {});
    }
    modal.addEventListener("click", async (e) => {
      const x = e.target.dataset.x;
      if (x === "close") close();
      if (x !== "go") return;
      const note = $("#note", modal).value;
      close();
      let done = 0;
      for (const sr of list) {
        const tr = rowOf(sr);
        tr.classList.add("busy");
        setSync("saving", `Re-evaluating ${done + 1}/${list.length}...`);
        try {
          const before = rows.find((r) => r.sr_no === sr).status;
          const result = await api("POST", `${base}/results/${sr}/reevaluate`, { note });
          updateRow(tr, result.row);
          toast(`#${sr}: ${before} \u2192 ${result.row.status}`, "ok");
          if (result.export_error) toast(result.export_error, "error");
        } catch (error) { toast(`#${sr}: ${error.message}`, "error"); }
        tr.classList.remove("busy");
        done += 1;
      }
      setSync("ok", `Re-evaluated ${done} finding(s) & Excel synced`);
      applyFilter();
    });
  }
  drawChips();
}

// ------------------------------------------------------------------ build with parameters
async function openBuildModal(pipelineOrId, prefill = {}, rebuildOf = null, prefillJob = "") {
  const pipeline = typeof pipelineOrId === "string" ? (await api("GET", `/pipelines/${pipelineOrId}`)).pipeline : pipelineOrId;
  const jobs = Array.isArray(pipeline.jobs) ? pipeline.jobs : [];
  const hasJobs = jobs.length > 0;
  const preferredJob = String(prefillJob || (jobs.find((j) => j.id === "full")?.id || jobs[0]?.id || ""));
  const jobField = hasJobs
    ? `<div class="field"><label>Job</label><select name="__job">${jobs.map((j) => `<option value="${esc(j.id)}" ${j.id === preferredJob ? "selected" : ""}>${esc(j.name || j.id)}</option>`).join("")}</select><div class="muted small">Run one Jenkins-style sub-job from this pipeline.</div></div>`
    : "";
  const isRuleForm = (pipeline.command || []).includes("manage_rules.py") || pipeline.params.some((p) => p.name === "patterns");
  const fields = pipeline.params.map((p) => {
    const value = prefill[p.name] ?? p.default ?? "";
    const label = `<label>${esc(p.label)}${p.required ? ' <span style="color:var(--red)">*</span>' : ""}</label>`;
    const help = p.help ? `<div class="muted small">${esc(p.help)}</div>` : "";
    if (p.type === "bool") return `<div class="field"><label class="switch"><input type="checkbox" name="${esc(p.name)}" ${value === true || value === "true" ? "checked" : ""}> ${esc(p.label)}</label>${help}</div>`;
    if (p.type === "choice") return `<div class="field">${label}<select name="${esc(p.name)}">${p.choices.map((c) => `<option ${c === value ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>${help}</div>`;
    if (p.type === "dir") return `<div class="field">${label}<div class="directory-picker"><input type="text" name="${esc(p.name)}" value="${esc(value)}"><button type="button" class="btn" data-browse="${esc(p.name)}">Browse...</button></div>${help}</div>`;
    if (p.type === "file") return `<div class="field">${label}<input type="text" name="${esc(p.name)}" value="${esc(value)}" placeholder="C:\\path\\to\\report or upload below">
      <div class="drop" data-drop="${esc(p.name)}" data-accept="${esc(p.accept || "")}">Drop a file here or click to upload</div>${help}</div>`;
    if (p.multiline) return `<div class="field">${label}<textarea name="${esc(p.name)}" rows="${p.name === "patterns" ? 7 : 4}" placeholder="${esc(p.placeholder || "")}">${esc(value)}</textarea>${help}</div>`;
    return `<div class="field">${label}<input type="text" name="${esc(p.name)}" value="${esc(value)}" placeholder="${esc(p.placeholder || "")}">${help}</div>`;
  }).join("");
  const ruleNote = isRuleForm ? `<div class="note">One rule is one issue type. Put every regex for that issue type in Patterns, one per line. Do not enter a specific IP, password, or SQL statement.</div>` : "";
  const { modal, close } = openModal(`<h2>${isRuleForm ? "Add Security Rule" : "Build with Parameters"}</h2><div class="muted small" style="margin-bottom:14px">${esc(pipeline.description || pipeline.name)}</div>${ruleNote}
    <form id="bform">${jobField}${fields || '<div class="muted">This pipeline has no parameters.</div>'}<div class="err-text" id="berr"></div>
    <div class="actions"><button type="button" class="btn" data-x="cancel">Cancel</button><button class="btn primary" type="submit">&#9654; Build</button></div></form>`, { wide: isRuleForm });

  $$('[data-browse]', modal).forEach((button) => {
    button.addEventListener('click', () => browseDirectory(button, $(`[name="${button.dataset.browse}"]`, modal), $('#berr', modal)));
  });
  $$("[data-drop]", modal).forEach((zone) => {
    const input = $(`[name="${zone.dataset.drop}"]`, modal);
    const picker = Object.assign(document.createElement("input"), { type: "file", accept: zone.dataset.accept });
    const upload = async (file) => {
      zone.textContent = `Uploading ${file.name}...`;
      try {
        const send = () => fetch(`/api/upload?name=${encodeURIComponent(file.name)}`, { method: "POST", headers: { "X-Triage-Token": SESSION }, body: file });
        let response = await send();
        if (response.status === 403) {
          SESSION = (await (await fetch("/api/session")).json()).token;
          response = await send();
        }
        const result = await response.json();
        if (!response.ok) throw new Error(result.error);
        input.value = result.path;
        zone.textContent = `Uploaded ${result.name} (${Math.round(result.size / 1024)} KB)`;
      } catch (error) { zone.textContent = "Upload failed: " + error.message; }
    };
    zone.addEventListener("click", () => picker.click());
    picker.addEventListener("change", () => picker.files[0] && upload(picker.files[0]));
    zone.addEventListener("dragover", (e) => { e.preventDefault(); zone.classList.add("over"); });
    zone.addEventListener("dragleave", () => zone.classList.remove("over"));
    zone.addEventListener("drop", (e) => { e.preventDefault(); zone.classList.remove("over"); if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]); });
  });
  modal.addEventListener("click", (e) => { if (e.target.dataset.x === "cancel") close(); });
  $("#bform", modal).addEventListener("submit", async (e) => {
    e.preventDefault();
    const params = {};
    pipeline.params.forEach((p) => {
      const el = $(`[name="${p.name}"]`, modal);
      params[p.name] = p.type === "bool" ? el.checked : el.value;
    });
    const selectedJob = hasJobs ? ($("[name='__job']", modal)?.value || "") : "";
    try {
      const body = { params, rebuild_of: rebuildOf };
      if (selectedJob) body.job = selectedJob;
      const build = await api("POST", `/pipelines/${pipeline.id}/build`, body);
      close(); toast(`Build #${build.id} queued`, "ok");
      goPipeline(pipeline.id);
    } catch (error) { $("#berr", modal).textContent = error.message; }
  });
}

// ------------------------------------------------------------------ pipeline editor / settings
async function browseDirectory(button, input, errorField) {
  button.disabled = true;
  errorField.textContent = "";
  try {
    const result = await api("POST", "/browse-directory", {});
    if (result.path) input.value = result.path;
  } catch (error) {
    errorField.textContent = error.message;
  } finally {
    button.disabled = false;
  }
}

async function openPipelineEditor(existingId, template) {
  const templates = await api("GET", "/templates");
  const blank = { id: "my-pipeline", name: "My Pipeline", description: "", cwd: "", command: ["python", "-u", "main.py"], params: [], stages: [], progress_regex: "", output_dir: "", results_json: "grouped_issues_with_ai.json", excel_glob: "*.xlsx", export_command: [], columns: [] };
  let start = blank;
  if (existingId) start = (await api("GET", `/pipelines/${existingId}`)).pipeline;
  else if (template && templates[template]) start = templates[template];
  const { modal, close } = openModal(`<h2>${existingId ? "Configure pipeline" : "New pipeline"}</h2>
    ${existingId ? "" : `<div class="row" style="margin-bottom:12px"><span class="muted small">Start from:</span><button class="btn sm" data-t="dast">DAST preset</button><button class="btn sm" data-t="sast">SAST preset</button><button class="btn sm" data-t="repo_scan">Repository scan</button><button class="btn sm" data-t="security_rules">Add security rule</button><button class="btn sm" data-t="blank">Blank</button></div>`}
    ${existingId ? "" : `<div id="repo-fields" ${start.kind === "repo_scan" ? "" : "hidden"}>
      <div class="field"><label>Pipeline ID</label><input id="repo-id" value="repository-scan"></div>
      <div class="field"><label>Pipeline name</label><input id="repo-name" value="Repository Scan"></div>
      <div class="field"><label>Repository folder</label><div class="directory-picker"><input id="repo-path" placeholder="C:\\path\\to\\repository"><button type="button" class="btn" data-x="browse-repo">Browse...</button></div></div>
      </div>`}
    <div class="muted small" style="margin-bottom:8px">Definition (JSON): working folder, command, parameters, stage regexes, output folder and Excel export.</div>
    <textarea id="def" class="json-edit" spellcheck="false">${esc(JSON.stringify(start, null, 2))}</textarea><div class="err-text" id="derr"></div>
    <div class="actions"><button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="save">Save pipeline</button></div>`, { wide: true });
  modal.addEventListener("click", async (e) => {
    const { t, x } = e.target.dataset;
    if (x === "browse-repo") await browseDirectory(e.target, $("#repo-path", modal), $("#derr", modal));
    if (t) {
      $("#def", modal).value = JSON.stringify(t === "blank" ? blank : templates[t], null, 2);
      $("#repo-fields", modal).hidden = t !== "repo_scan";
    }
    if (x === "cancel") close();
    if (x === "save") {
      try {
        const definition = JSON.parse($("#def", modal).value);
        if (!existingId && definition.kind === "repo_scan") {
          const path = $("#repo-path", modal).value.trim();
          if (!path) throw new Error("Repository folder is required");
          definition.id = $("#repo-id", modal).value.trim();
          definition.name = $("#repo-name", modal).value.trim();
          const source = definition.params.find((p) => p.name === "source_dir");
          if (!source) throw new Error("Repository scan needs a source_dir parameter");
          source.default = path;
        }
        if (existingId) await api("PUT", `/pipelines/${existingId}`, definition);
        else await api("POST", "/pipelines", definition);
        close(); toast("Pipeline saved", "ok");
        route();
      } catch (error) { $("#derr", modal).textContent = error.message; }
    }
  });
}

async function openSettings() {
  const state = await api("GET", "/settings");
  const sel = (key, options) => `<select data-pref="${key}">${options.map(([v, l]) => `<option value="${v}" ${String(PREFS[key]) === String(v) ? "selected" : ""}>${l}</option>`).join("")}</select>`;
  const toggle = (key, label) => `<label class="switch"><input type="checkbox" data-pref="${key}" ${PREFS[key] ? "checked" : ""}> ${label}</label>`;
  const num = (key, min, max, step) => `<input type="number" data-pref="${key}" min="${min}" max="${max}" step="${step}" value="${PREFS[key]}">`;
  const field = (label, control, hint = "") => `<div class="field"><label>${label}</label>${control}${hint ? `<div class="muted small" style="margin-top:4px">${hint}</div>` : ""}</div>`;

  const { modal, close } = openModal(`<h2>Settings</h2>
    <div class="tabs"><button class="tab active" data-sec="look">Appearance</button><button class="tab" data-sec="behave">Behavior</button><button class="tab" data-sec="conn">Connection</button></div>
    <section data-pane-sec="look"><div class="form-grid">
      ${field("Theme", sel("theme", [["light", "White"], ["dark", "Dark"], ["system", "Follow system"]]))}
      ${field("Accent colour", `<input type="color" data-pref="accent" value="${esc(PREFS.accent)}">`)}
      ${field("Density", sel("density", [["comfortable", "Comfortable"], ["compact", "Compact"]]))}
      ${field("Text size (px)", num("fontSize", 12, 18, 1))}
      ${field("Console text size (px)", num("consoleFont", 10, 18, 0.5))}
      ${field("Time format", sel("timeFormat", [["24h", "24-hour"], ["12h", "12-hour"], ["system", "System"]]))}
    </div>${toggle("animations", "Animations and transitions")}</section>
    <section data-pane-sec="behave" hidden><div class="form-grid">
      ${field("Live refresh (ms)", num("refreshMs", 500, 10000, 100), "How often lists and stage views refresh.")}
      ${field("Builds in Stage View", num("stageBuilds", 1, 50, 1))}
      ${field("Build page opens on", sel("defaultTab", [["stages", "Status"], ["console", "Console Output"], ["results", "Results & Excel"]]))}
      ${field("Notification time (s)", num("toastSec", 1, 15, 1))}
    </div>
      <div class="stack">${toggle("consoleFollow", "Console follows new output")}${toggle("consoleWrap", "Wrap long console lines")}${toggle("confirmDelete", "Ask before deleting")}</div></section>
    <section data-pane-sec="conn" hidden>
      ${field("Copilot bridge token", `<input type="password" id="tok" placeholder="${state.token_set ? "Token is set (enter a new one to replace)" : "Paste COPILOT_BRIDGE_TOKEN"}" autocomplete="off">`, "Kept in server memory only; never written to disk.")}
      ${field("Bridge URL", `<input type="text" id="burl" value="${esc(state.bridge_url)}">`, `Status: <b style="color:var(--${state.bridge === "up" ? "green" : "red"})">${state.bridge}</b> &middot; must be on 127.0.0.1 or localhost`)}
      ${field("Re-evaluation timeout (s)", `<input type="number" id="btimeout" min="10" max="600" value="${state.reeval_timeout}">`)}
      <div class="err-text" id="serr"></div>
      <div class="actions" style="margin-top:6px"><button class="btn" data-x="clear">Clear token</button><button class="btn primary" data-x="save">Save connection</button></div></section>
    <div class="actions"><button class="btn" data-x="reset">Reset appearance &amp; behavior</button><button class="btn primary" data-x="done">Done</button></div>`, { wide: true });

  let timer = 0;
  const rerender = () => { clearTimeout(timer); timer = setTimeout(route, 250); };
  modal.addEventListener("input", (e) => {
    const key = e.target.dataset.pref;
    if (!key) return;
    const value = e.target.type === "checkbox" ? e.target.checked : e.target.type === "number" ? Number(e.target.value) : e.target.value;
    if (e.target.type === "number" && (e.target.value === "" || Number.isNaN(value))) return;
    savePrefs({ [key]: value });
    if (!["theme", "accent", "density", "fontSize", "consoleFont", "animations"].includes(key)) rerender();
  });
  modal.addEventListener("click", async (e) => {
    const { sec, x } = e.target.dataset;
    if (sec) {
      $$("[data-sec]", modal).forEach((t) => t.classList.toggle("active", t.dataset.sec === sec));
      $$("[data-pane-sec]", modal).forEach((p) => { p.hidden = p.dataset.paneSec !== sec; });
    }
    if (x === "done") close();
    if (x === "reset") { savePrefs({ ...PREF_DEFAULTS }); close(); route(); toast("Appearance and behavior reset", "ok"); }
    if (x === "clear" || x === "save") {
      try {
        const token = x === "clear" ? "" : $("#tok", modal).value;
        if (x === "clear" || token) await api("POST", "/settings/token", { token });
        if (x === "save") await api("POST", "/settings", { bridge_url: $("#burl", modal).value, reeval_timeout: Number($("#btimeout", modal).value) });
        toast(x === "clear" ? "Token cleared" : "Connection saved", "ok");
        refreshBridge();
        if (x === "save") close();
      } catch (error) { $("#serr", modal).textContent = error.message; }
    }
  });
}

async function refreshBridge() {
  try {
    const s = await api("GET", "/settings");
    const el = $("#bridge");
    el.className = `pill ${s.bridge}`;
    el.textContent = `bridge ${s.bridge}${s.token_set ? "" : " \u00b7 no token"}`;
  } catch { /* server stopped */ }
}

// ------------------------------------------------------------------ global actions
document.addEventListener("click", async (e) => {
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const act = el.dataset.act;
  try {
    if (act === "theme") {
      savePrefs({ theme: document.documentElement.dataset.theme === "dark" ? "light" : "dark" });
    } else if (act === "settings") await openSettings();
    else if (act === "new-pipeline") await openPipelineEditor(null, el.dataset.template);
    else if (act === "edit-pipeline") await openPipelineEditor(el.dataset.pid);
    else if (act === "build") await openBuildModal(el.dataset.pid);
    else if (act === "delete-pipeline") {
      if (!PREFS.confirmDelete || await confirmBox("Delete this pipeline and its local builds, reports, and suppressions?", "Delete")) {
        await api("DELETE", `/pipelines/${el.dataset.pid}`); location.hash = "#/";
      }
    } else if (view._buildActions && view._buildActions[act]) await view._buildActions[act]();
  } catch (error) { toast(error.message, "error"); }
});

(async function boot() {
  applyPrefs();
  matchMedia("(prefers-color-scheme: dark)").addEventListener("change", applyPrefs);
  SESSION = (await (await fetch("/api/session")).json()).token;
  refreshBridge();
  setInterval(refreshBridge, 15000);
  window.addEventListener("hashchange", route);
  route();
})();
