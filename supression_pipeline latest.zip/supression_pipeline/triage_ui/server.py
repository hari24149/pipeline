"""Triage Console: one local website that runs user-defined SAST/DAST pipelines.

Pipelines are plain command definitions (pipelines.json, edited in the UI).
Each build runs the command as a subprocess so the terminal tools and the UI
share the exact same code path.
"""
from __future__ import annotations

import argparse
import codecs
import hashlib
import json
import mimetypes
import os
import queue
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
DATA_DIR = ROOT / "data"
BUILDS_DIR = DATA_DIR / "builds"
UPLOADS_DIR = DATA_DIR / "uploads"
PIPELINES_FILE = ROOT / "pipelines.json"

BRIDGE_BASE = os.getenv("COPILOT_BRIDGE_BASE", "http://127.0.0.1:3210")
TOKEN_ENV = "COPILOT_BRIDGE_TOKEN"
MAX_UPLOAD_BYTES = 200 * 1024 * 1024
STATUSES = ("Open", "False Positive", "Fixed")
EDITABLE_FIELDS = ("status", "justification", "solution")
EVIDENCE_FILES = ("evidence.txt", "category_context.txt", "known_context.txt", "ai_prompt.txt")
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
PARAM_TYPES = ("file", "dir", "string", "choice", "bool")
JOB_ID_RE = re.compile(r"[a-z0-9][a-z0-9_-]{0,39}")

SESSION_TOKEN = secrets.token_urlsafe(24)
SETTINGS_FILE = ROOT / "settings.json"
BRIDGE_HINTS = {
    401: " (unauthorized: check the bridge token)",
    403: " (no access: run Authorize Copilot Access in the bridge Control Center)",
    429: " (rate limit of 60/min exceeded: wait and retry)",
    503: " (model unavailable: check Copilot sign-in)",
}
SETTINGS = {"token": "", "bridge_url": BRIDGE_BASE, "reeval_timeout": 180}
LOCK = threading.RLock()
BUILDS: dict[tuple[str, int], "Build"] = {}
QUEUES: dict[str, queue.Queue] = {}
RESULT_LOCKS: dict[str, threading.Lock] = {}


def now() -> float:
    return time.time()


def write_json_atomic(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def get_token() -> str:
    return SETTINGS["token"] or os.getenv(TOKEN_ENV, "").strip()


def load_settings() -> None:
    if not SETTINGS_FILE.exists():
        return
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        update_settings(saved, persist=False)
    except (json.JSONDecodeError, ValueError):
        pass


def update_settings(data: dict, persist: bool = True) -> None:
    """Validate and apply server settings; the bridge token is never saved to disk."""
    if "bridge_url" in data:
        url = str(data["bridge_url"]).strip().rstrip("/")
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or parsed.hostname not in ("127.0.0.1", "localhost"):
            raise ValueError("Bridge URL must be http(s) on 127.0.0.1 or localhost")
        SETTINGS["bridge_url"] = url
    if "reeval_timeout" in data:
        timeout = int(data["reeval_timeout"])
        if not 10 <= timeout <= 600:
            raise ValueError("Re-evaluation timeout must be 10-600 seconds")
        SETTINGS["reeval_timeout"] = timeout
    if persist:
        write_json_atomic(SETTINGS_FILE, {k: v for k, v in SETTINGS.items() if k != "token"})


# --------------------------------------------------------------------------
# Pipeline definitions
# --------------------------------------------------------------------------

def load_pipelines() -> dict[str, dict]:
    if not PIPELINES_FILE.exists():
        return {}
    try:
        items = json.loads(PIPELINES_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return {item["id"]: item for item in items if isinstance(item, dict) and "id" in item}


def save_pipelines(pipelines: dict[str, dict]) -> None:
    write_json_atomic(PIPELINES_FILE, list(pipelines.values()))


def _string_list(value, field: str, required: bool = False) -> list[str]:
    if value is None:
        value = []
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise ValueError(f"'{field}' must be a list of non-empty strings")
    if required and not value:
        raise ValueError(f"'{field}' must not be empty")
    return value


def validate_pipeline(raw) -> dict:
    if not isinstance(raw, dict):
        raise ValueError("Pipeline definition must be a JSON object")
    pid = str(raw.get("id", "")).strip().lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,39}", pid):
        raise ValueError("'id' must be 1-40 chars: lowercase letters, digits, '-' or '_'")
    cwd = Path(str(raw.get("cwd", "")).strip()).expanduser()
    if not cwd.is_dir():
        raise ValueError(f"Working directory not found: {cwd}")

    params = []
    seen = set()
    for p in raw.get("params") or []:
        name = str(p.get("name", ""))
        if not re.fullmatch(r"[A-Za-z_]\w*", name) or name in seen:
            raise ValueError(f"Invalid or duplicate parameter name: '{name}'")
        seen.add(name)
        ptype = p.get("type", "string")
        if ptype not in PARAM_TYPES:
            raise ValueError(f"Parameter '{name}': type must be one of {PARAM_TYPES}")
        item = {
            "name": name,
            "label": str(p.get("label") or name),
            "type": ptype,
            "required": bool(p.get("required", False)),
        }
        for key in ("flag", "accept", "help", "placeholder"):
            if p.get(key):
                item[key] = str(p[key])
        if p.get("multiline"):
            item["multiline"] = True
        if p.get("max_length"):
            item["max_length"] = int(p["max_length"])
        if ptype == "choice":
            item["choices"] = _string_list(p.get("choices"), f"{name}.choices", required=True)
        if "default" in p:
            item["default"] = p["default"]
        params.append(item)

    if raw.get("kind") == "repo_scan":
        source = next((p for p in params if p["name"] == "source_dir" and p["type"] == "dir"), None)
        if not source or not str(source.get("default", "")).strip() or not Path(str(source["default"])).is_dir():
            raise ValueError("Repository scan requires an existing default source directory")

    stages = []
    for s in raw.get("stages") or []:
        name = str(s.get("name", "")).strip()
        match = str(s.get("match") or re.escape(name))
        if not name:
            raise ValueError("Every stage needs a 'name'")
        try:
            re.compile(match)
        except re.error as exc:
            raise ValueError(f"Stage '{name}': invalid regex ({exc})")
        stages.append({"name": name, "match": match})

    jobs = []
    for j in raw.get("jobs") or []:
        jid = str(j.get("id", "")).strip().lower()
        if not JOB_ID_RE.fullmatch(jid):
            raise ValueError("Every job needs an 'id' (1-40 chars: lowercase letters, digits, '-' or '_')")
        if any(existing["id"] == jid for existing in jobs):
            raise ValueError(f"Duplicate job id: '{jid}'")
        args = _string_list(j.get("args"), f"job '{jid}'.args")
        item = {
            "id": jid,
            "name": str(j.get("name") or jid),
            "description": str(j.get("description") or ""),
            "args": args,
        }
        if "start_stage" in j or "end_stage" in j:
            if not stages:
                raise ValueError(f"Job '{jid}' uses start/end stage but the pipeline has no stages")
            start_stage = int(j.get("start_stage", 1))
            end_stage = int(j.get("end_stage", len(stages)))
            if start_stage < 1 or end_stage < 1 or start_stage > end_stage:
                raise ValueError(f"Job '{jid}' has an invalid stage range")
            if end_stage > len(stages):
                raise ValueError(f"Job '{jid}' end_stage exceeds stage count ({len(stages)})")
            item["start_stage"] = start_stage
            item["end_stage"] = end_stage
        jobs.append(item)

    progress = str(raw.get("progress_regex") or "")
    if progress:
        try:
            if re.compile(progress).groups < 2:
                raise ValueError("'progress_regex' needs two groups: (done) and (total)")
        except re.error as exc:
            raise ValueError(f"'progress_regex' is invalid ({exc})")

    results_json = str(raw.get("results_json") or "grouped_issues_with_ai.json")
    if "/" in results_json or "\\" in results_json:
        raise ValueError("'results_json' must be a file name inside the output folder")

    columns = []
    for c in raw.get("columns") or []:
        columns.append({"key": str(c["key"]), "label": str(c.get("label") or c["key"])})

    return {
        "id": pid,
        "kind": "repo_scan" if raw.get("kind") == "repo_scan" else "",
        "name": str(raw.get("name") or pid).strip(),
        "description": str(raw.get("description") or ""),
        "cwd": str(cwd),
        "command": _string_list(raw.get("command"), "command", required=True),
        "params": params,
        "stages": stages,
        "jobs": jobs,
        "progress_regex": progress,
        "output_dir": str(raw.get("output_dir") or ""),
        "results_json": results_json,
        "excel_glob": str(raw.get("excel_glob") or "*.xlsx"),
        "export_command": _string_list(raw.get("export_command"), "export_command"),
        "columns": columns,
    }


def pipeline_templates() -> dict[str, dict]:
    workspace = ROOT.parent
    dast_dir = next((p for p in workspace.glob("dast_triage*") if (p / "main.py").exists()), workspace / "dast_triage v1")
    sast_dir = workspace / "sast_triage"
    style = {
        "name": "style", "label": "Justification style", "type": "choice",
        "choices": ["short", "default"], "default": "short", "flag": "--justification-style",
    }
    progress = r"AI decisions \((\d+)/(\d+)\)"
    return {
        "security_rules": {
            "id": "security-rules", "name": "Add Security Rule",
            "description": "Add one issue type as regex patterns, not a specific IP, query, or secret, for Java, Python, TypeScript, or HTML",
            "cwd": str(workspace / "repo_scan"),
            "command": ["python", "-u", "manage_rules.py"],
            "params": [
                {"name": "rule_id", "label": "Rule ID (lowercase, unique)", "type": "string", "flag": "--id", "required": True},
                {
                    "name": "patterns", "label": "Patterns for this issue type (one regex per line)", "type": "string",
                    "flag": "--patterns", "required": True, "multiline": True, "max_length": 8000,
                    "placeholder": "\\b(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\b\nexecuteQuery\\s*\\([^)\\n]*\\+\nprepareStatement\\s*\\([^)\\n]*\\+",
                    "help": "Do not enter a specific value. For an IP finding, enter an IP pattern. For SQL Injection, enter every query pattern that belongs to that issue type, one per line.",
                },
                {"name": "message", "label": "Finding message", "type": "string", "flag": "--message", "required": True},
                {"name": "match_example", "label": "Matching source example (one line per pattern)", "type": "string", "flag": "--match-example", "required": True, "multiline": True, "help": "Each pattern must match at least one of these lines."},
                {"name": "nonmatch_example", "label": "Non-matching source example", "type": "string", "flag": "--nonmatch-example", "required": True, "multiline": True, "help": "None of the patterns may match these lines."},
                {"name": "language", "label": "Language", "type": "choice", "choices": ["java", "python", "typescript", "html"], "default": "java", "flag": "--language"},
                {"name": "issue_type", "label": "Issue type (for example SQL Injection or Hardcoded IP)", "type": "string", "default": "Security review", "flag": "--issue-type", "required": True, "help": "Shared name for every pattern in this rule."},
                {"name": "category", "label": "Category", "type": "choice", "choices": ["Security", "Code Quality", "Accessibility"], "default": "Security", "flag": "--category", "required": True},
                {"name": "severity", "label": "Severity", "type": "choice", "choices": ["CRITICAL", "MAJOR", "MINOR", "WARNING", "INFO"], "default": "WARNING", "flag": "--severity", "required": True},
                {"name": "redact", "label": "Redact matched source (passwords, secrets, IP addresses)", "type": "bool", "flag": "--redact"},
                {"name": "include_comments", "label": "Also match comment lines", "type": "bool", "flag": "--include-comments"},
            ],
            "stages": [{"name": "Validate examples", "match": r"^\[STEP 1\]"}, {"name": "Update rules", "match": r"^\[STEP 2\]"}],
            "jobs": [], "progress_regex": "", "output_dir": "", "results_json": "grouped_issues_with_ai.json",
            "excel_glob": "*.xlsx", "export_command": [], "columns": [],
        },
        "repo_scan": {
            "id": "repository-scan", "kind": "repo_scan", "name": "Repository Scan",
            "description": "Scan a local repository for security and accessibility findings",
            "cwd": str(workspace / "repo_scan"),
            "command": ["python", "-u", "scanner.py"],
            "params": [
                {"name": "source_dir", "label": "Source repository folder", "type": "dir", "flag": "--source-dir", "required": True},
                {"name": "skip_accessibility", "label": "Backend only (skip accessibility)", "type": "bool", "flag": "--skip-accessibility"},
                {"name": "accessibility_only", "label": "Accessibility only (skip security)", "type": "bool", "flag": "--accessibility-only"},
                {"name": "language", "label": "Security language", "type": "choice", "choices": ["all", "java", "python", "javascript-typescript", "html"], "default": "all", "flag": "--language"},
                {"name": "skip_quality", "label": "Skip code quality checks", "type": "bool", "flag": "--skip-quality"},
            ],
            "stages": [
                {"name": name, "match": rf"^\[STEP {i}\]"}
                for i, name in enumerate(["Scan security", "Scan accessibility", "Prepare findings", "Export Excel report"], start=1)
            ],
            "jobs": [{"id": "full", "name": "Full scan", "args": []}],
            "progress_regex": "", "output_dir": "", "results_json": "grouped_issues_with_ai.json",
            "excel_glob": "*_SAST_SuppressionReport.xlsx",
            "export_command": [
                "python", "-c",
                "import sys; from pathlib import Path; from scanner import export_excel; export_excel(Path(sys.argv[1]))",
                "{output_dir}",
            ],
            "columns": [
                {"key": "sr_no", "label": "Sr."}, {"key": "category", "label": "Category"}, {"key": "issue_name", "label": "Finding"},
                {"key": "rule_id", "label": "Rule ID"}, {"key": "severity", "label": "Severity"},
                {"key": "file_path", "label": "File"}, {"key": "line", "label": "Line"},
                {"key": "detection", "label": "Current scan"},
                {"key": "source_code", "label": "Source"},
            ],
        },
        "dast": {
            "id": "dast", "name": "DAST Triage",
            "description": "Fortify WebInspect PDF to Excel suppression report",
            "cwd": str(dast_dir),
            "command": ["python", "-u", "main.py"],
            "params": [
                {"name": "pdf", "label": "DAST report (PDF)", "type": "file", "flag": "--pdf", "required": True, "accept": ".pdf"},
                style,
            ],
            "stages": [
                {"name": name, "match": rf"^\[STEP {i}\]"}
                for i, name in enumerate([
                    "Extract PDF text", "Clean text", "Split report sections", "Group findings",
                    "Build evidence packets", "Generate AI prompts", "AI triage decisions",
                    "Merge decisions", "Export Excel report",
                ], start=1)
            ],
            "jobs": [
                {"id": "full", "name": "Full pipeline", "description": "Run all stages", "args": []},
                {"id": "full_no_ai", "name": "Full pipeline (skip AI)", "description": "Run all stages but skip AI bridge calls", "args": ["--skip-ai"]},
                {"id": "extract", "name": "Extract PDF text only", "args": ["--start-stage", "1", "--end-stage", "1"], "start_stage": 1, "end_stage": 1},
                {"id": "clean", "name": "Clean text only", "args": ["--start-stage", "2", "--end-stage", "2"], "start_stage": 2, "end_stage": 2},
                {"id": "sections", "name": "Split report sections only", "args": ["--start-stage", "3", "--end-stage", "3"], "start_stage": 3, "end_stage": 3},
                {"id": "group", "name": "Group findings only", "args": ["--start-stage", "4", "--end-stage", "4"], "start_stage": 4, "end_stage": 4},
                {"id": "evidence", "name": "Build evidence packets only", "args": ["--start-stage", "5", "--end-stage", "5"], "start_stage": 5, "end_stage": 5},
                {"id": "prompts", "name": "Generate AI prompts only", "args": ["--start-stage", "6", "--end-stage", "6"], "start_stage": 6, "end_stage": 6},
                {"id": "ai_only", "name": "AI triage decisions only", "args": ["--start-stage", "7", "--end-stage", "7"], "start_stage": 7, "end_stage": 7},
                {"id": "merge", "name": "Merge decisions only", "args": ["--start-stage", "8", "--end-stage", "8"], "start_stage": 8, "end_stage": 8},
                {"id": "excel", "name": "Export Excel only", "args": ["--start-stage", "9", "--end-stage", "9"], "start_stage": 9, "end_stage": 9},
            ],
            "progress_regex": progress,
            "output_dir": "output/dast/{pdf:stem}",
            "results_json": "grouped_issues_with_ai.json",
            "excel_glob": "*_DAST_SuppressionReport.xlsx",
            "export_command": [
                "python", "-c",
                "import sys; from Dast.excel_export import export_dast_excel as e; e(sys.argv[1])",
                "{output_dir}",
            ],
            "columns": [
                {"key": "sr_no", "label": "Sr."}, {"key": "issue_name", "label": "Vulnerability"},
                {"key": "severity", "label": "Severity"}, {"key": "occurrences", "label": "Occurrences"},
            ],
        },
        "sast": {
            "id": "sast", "name": "SAST Triage",
            "description": "Fortify SCA / SARIF report plus source tree to Excel suppression report",
            "cwd": str(sast_dir),
            "command": ["python", "-u", "main.py"],
            "params": [
                {"name": "report", "label": "SAST report (PDF/SARIF/JSON/XML)", "type": "file", "flag": "--report", "required": True, "accept": ".pdf,.sarif,.json,.xml"},
                {"name": "source_dir", "label": "Source repository folder", "type": "dir", "flag": "--source-dir", "required": True},
                style,
                {"name": "skip_ai", "label": "Skip AI (prepare packets only)", "type": "bool", "flag": "--skip-ai"},
            ],
            "stages": [
                {"name": name, "match": rf"^\[STEP {i}\]"}
                for i, name in enumerate([
                    "Parse report", "Collect source evidence", "Generate AI prompts",
                    "AI triage decisions", "Merge decisions", "Export Excel report",
                ], start=1)
            ],
            "jobs": [
                {"id": "full", "name": "Full pipeline", "description": "Run all stages", "args": []},
                {"id": "full_no_ai", "name": "Full pipeline (skip AI)", "description": "Run all stages but skip AI bridge calls", "args": ["--skip-ai"]},
                {"id": "parse", "name": "Parse report only", "args": ["--start-stage", "1", "--end-stage", "1"], "start_stage": 1, "end_stage": 1},
                {"id": "evidence", "name": "Collect source evidence only", "args": ["--start-stage", "2", "--end-stage", "2"], "start_stage": 2, "end_stage": 2},
                {"id": "prompts", "name": "Generate AI prompts only", "args": ["--start-stage", "3", "--end-stage", "3"], "start_stage": 3, "end_stage": 3},
                {"id": "ai_only", "name": "AI triage decisions only", "args": ["--start-stage", "4", "--end-stage", "4", "--resume-ai"], "start_stage": 4, "end_stage": 4},
                {"id": "merge", "name": "Merge decisions only", "args": ["--start-stage", "5", "--end-stage", "5"], "start_stage": 5, "end_stage": 5},
                {"id": "excel", "name": "Export Excel only", "args": ["--start-stage", "6", "--end-stage", "6"], "start_stage": 6, "end_stage": 6},
                {"id": "packets_only", "name": "Prepare packets only", "description": "Parse + evidence + prompts (no AI)", "args": ["--start-stage", "1", "--end-stage", "3"]},
            ],
            "progress_regex": progress,
            "output_dir": "output/sast/{report:stem}",
            "results_json": "grouped_issues_with_ai.json",
            "excel_glob": "*_SAST_SuppressionReport.xlsx",
            "export_command": [
                "python", "-c",
                "import sys; from pathlib import Path; from Sast.excel_export import export_sast_excel as e; e(Path(sys.argv[1]))",
                "{output_dir}",
            ],
            "columns": [
                {"key": "sr_no", "label": "Sr."}, {"key": "issue_name", "label": "Vulnerability"},
                {"key": "rule_id", "label": "Rule ID"}, {"key": "severity", "label": "Severity"},
                {"key": "occurrences", "label": "Occurrences"},
            ],
        },
    }


# --------------------------------------------------------------------------
# Builds
# --------------------------------------------------------------------------

class Build:
    def __init__(self, pipeline_id: str, number: int, meta: dict | None = None):
        self.pipeline_id = pipeline_id
        self.number = number
        self.dir = BUILDS_DIR / pipeline_id / str(number)
        self.cond = threading.Condition()
        self.lines: list[dict] = []
        self.lines_loaded = meta is None
        self.version = 0
        self.proc: subprocess.Popen | None = None
        self.abort_requested = False
        self.log_handle = None
        self.meta = meta or {}

    @property
    def finished(self) -> bool:
        return self.meta.get("status") in ("success", "failed", "aborted")

    def persist(self) -> None:
        write_json_atomic(self.dir / "build.json", self.meta)

    def touch(self) -> None:
        with self.cond:
            self.version += 1
            self.cond.notify_all()

    def add_line(self, level: str, text: str) -> None:
        entry = {"l": level, "t": text}
        with self.cond:
            self.lines.append(entry)
            if self.log_handle:
                self.log_handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
                self.log_handle.flush()
            self.version += 1
            self.cond.notify_all()

    def load_lines(self) -> None:
        with self.cond:
            if self.lines_loaded:
                return
            log = self.dir / "console.log"
            if log.exists():
                for raw in log.read_text(encoding="utf-8", errors="replace").splitlines():
                    try:
                        self.lines.append(json.loads(raw))
                    except json.JSONDecodeError:
                        continue
            self.lines_loaded = True

    def public(self) -> dict:
        with self.cond:
            meta = dict(self.meta)
            meta["stages"] = [dict(s) for s in meta.get("stages", [])]
        meta["id"] = self.number
        meta["pipeline"] = self.pipeline_id
        out = meta.get("output_dir")
        meta["has_results"] = bool(self.finished and out and meta.get("results_file") and (Path(out) / meta["results_file"]).exists())
        if self.finished and meta.get("kind") == "repo_scan" and out:
            try:
                report = json.loads((Path(out) / "security_report.json").read_text(encoding="utf-8"))
                python = report.get("python", {})
                if python.get("scanned_files") and isinstance(python.get("unsupported_ast_rules"), list):
                    meta["python_unsupported_rules"] = len(python["unsupported_ast_rules"])
            except (OSError, ValueError, AttributeError):
                pass
        return meta

    # stage tracking -------------------------------------------------------
    def advance_stage(self, index: int) -> None:
        with self.cond:
            stages = self.meta["stages"]
            for i, stage in enumerate(stages):
                if i < index and stage["status"] == "running":
                    stage["status"], stage["end"] = "success", now()
                elif i < index and stage["status"] == "pending":
                    stage["status"] = "skipped"
            target = stages[index]
            if target["status"] == "pending":
                target["status"], target["start"] = "running", now()
            self.meta["progress"] = None
            self.version += 1
            self.cond.notify_all()

    def close_stages(self, status: str) -> None:
        with self.cond:
            for stage in self.meta.get("stages", []):
                if stage["status"] == "running":
                    stage["status"] = "success" if status == "success" else status
                    stage["end"] = now()
                elif stage["status"] == "pending" and status == "success":
                    stage["status"] = "skipped"
            self.version += 1
            self.cond.notify_all()


def next_build_number(pipeline_id: str) -> int:
    numbers = [n for (pid, n) in BUILDS if pid == pipeline_id]
    return max(numbers, default=0) + 1


def load_existing_builds() -> None:
    if not BUILDS_DIR.exists():
        return
    for pdir in BUILDS_DIR.iterdir():
        if not pdir.is_dir():
            continue
        for bdir in pdir.iterdir():
            meta_file = bdir / "build.json"
            if not (bdir.name.isdigit() and meta_file.exists()):
                continue
            try:
                meta = json.loads(meta_file.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                continue
            build = Build(pdir.name, int(bdir.name), meta)
            if meta.get("status") in ("queued", "running"):
                meta["status"] = "failed"
                meta["ended"] = meta.get("ended") or now()
                for stage in meta.get("stages", []):
                    if stage["status"] == "running":
                        stage["status"] = "failed"
                build.persist()
            BUILDS[(pdir.name, int(bdir.name))] = build


def resolve_output_dir(pdef: dict, values: dict) -> Path | None:
    template = pdef.get("output_dir")
    if not template:
        return None

    def substitute(match: re.Match) -> str:
        value = str(values.get(match.group(1), ""))
        mode = match.group(2)
        if mode == "stem":
            return Path(value).stem
        if mode == "name":
            return Path(value).name
        return value

    path = Path(re.sub(r"\{(\w+)(?::(stem|name))?\}", substitute, template))
    return (path if path.is_absolute() else Path(pdef["cwd"]) / path).resolve()


def normalize_params(pdef: dict, supplied: dict) -> dict:
    values: dict = {}
    for p in pdef["params"]:
        name, ptype = p["name"], p["type"]
        value = supplied.get(name, p.get("default"))
        if ptype == "bool":
            values[name] = value in (True, "true", "on", 1)
            continue
        value = "" if value is None else str(value).strip()
        if not value:
            if p.get("required"):
                raise ValueError(f"'{p['label']}' is required")
            continue
        if len(value) > int(p.get("max_length") or 2000):
            raise ValueError(f"'{p['label']}' is too long")
        if ptype == "choice" and value not in p["choices"]:
            raise ValueError(f"'{p['label']}' must be one of {p['choices']}")
        if ptype == "file" and not Path(value).is_file():
            raise ValueError(f"File not found: {value}")
        if ptype == "dir" and not Path(value).is_dir():
            raise ValueError(f"Folder not found: {value}")
        values[name] = value
    return values


def resolve_job(pdef: dict, requested: str | None) -> dict:
    jobs = pdef.get("jobs") or []
    if not jobs:
        return {"id": "full", "name": "Full pipeline", "args": []}
    by_id = {j["id"]: j for j in jobs}
    if requested is None:
        requested = "full" if "full" in by_id else jobs[0]["id"]
    job = by_id.get(str(requested).strip().lower())
    if not job:
        raise ValueError(f"Unknown job '{requested}'. Available jobs: {', '.join(sorted(by_id))}")
    return job


def build_command(pdef: dict, values: dict, job: dict | None = None) -> list[str]:
    command = list(pdef["command"])
    if command[0].lower() in ("python", "python3", "py"):
        command[0] = sys.executable
    for p in pdef["params"]:
        value = values.get(p["name"])
        flag = p.get("flag")
        if p["type"] == "bool":
            if value and flag:
                command.append(flag)
        elif value not in (None, ""):
            if flag:
                command.append(flag)
            command.append(str(value))
    if job:
        command.extend(job.get("args") or [])
    return command


def enqueue_build(pdef: dict, supplied: dict, rebuild_of: int | None, job_id: str | None) -> Build:
    values = normalize_params(pdef, supplied)
    job = resolve_job(pdef, job_id)
    output_dir = resolve_output_dir(pdef, values)
    start_stage = int(job.get("start_stage", 1))
    end_stage = int(job.get("end_stage", len(pdef["stages"]) or 1))

    def stage_meta(index: int, stage_name: str) -> dict:
        enabled = not pdef["stages"] or start_stage <= index <= end_stage
        return {"name": stage_name, "status": "pending" if enabled else "skipped", "start": None, "end": None}

    with LOCK:
        number = next_build_number(pdef["id"])
        build = Build(pdef["id"], number)
        if pdef.get("kind") == "repo_scan":
            if not values.get("source_dir"):
                raise ValueError("Repository scan requires a source_dir parameter")
            output_dir = build.dir / "results"
        build.meta = {
            "number": number,
            "status": "queued",
            "params": values,
            "job": {"id": job["id"], "name": job.get("name") or job["id"]},
            "rebuild_of": rebuild_of,
            "queued": now(),
            "started": None,
            "ended": None,
            "output_dir": str(output_dir) if output_dir else None,
            "kind": pdef.get("kind", ""),
            "results_file": pdef["results_json"],
            "excel": None,
            "progress": None,
            "stages": [
                stage_meta(i, s["name"])
                for i, s in enumerate(pdef["stages"], start=1)
            ],
        }
        BUILDS[(pdef["id"], number)] = build
        build.dir.mkdir(parents=True, exist_ok=True)
        build.log_handle = open(build.dir / "console.log", "a", encoding="utf-8")
        build.persist()
        build.pdef = pdef  # type: ignore[attr-defined]
        build.values = values  # type: ignore[attr-defined]
        build.job = job  # type: ignore[attr-defined]
        if pdef["id"] not in QUEUES:
            q: queue.Queue = queue.Queue()
            QUEUES[pdef["id"]] = q
            threading.Thread(target=worker, args=(q,), daemon=True).start()
        QUEUES[pdef["id"]].put(build)
    build.add_line("info", f"Started by user (build #{number}" + (f", rebuild of #{rebuild_of})" if rebuild_of else ")"))
    build.add_line("info", f"Selected job: {job.get('name') or job['id']} ({job['id']})")
    return build


def worker(q: queue.Queue) -> None:
    while True:
        build = q.get()
        try:
            execute_build(build)
        except Exception as exc:  # keep the worker alive for later builds
            build.add_line("error", f"ERROR: {exc}")
            finish_build(build, "failed")


def kill_tree(proc: subprocess.Popen) -> None:
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
    else:
        proc.kill()


def finish_build(build: Build, status: str) -> None:
    out = build.meta.get("output_dir")
    if out and Path(out).is_dir():
        pdef = build.pdef  # type: ignore[attr-defined]
        started = build.meta.get("started") or 0
        # Files older than this build belong to an earlier run of the same report.
        matches = sorted(
            (p for p in Path(out).glob(pdef["excel_glob"]) if p.stat().st_mtime >= started - 1),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        build.meta["excel"] = matches[0].name if matches else None
        results = Path(out) / build.meta["results_file"]
        if not results.exists() or results.stat().st_mtime < started - 1:
            build.meta["results_file"] = None
    build.close_stages("failed" if status == "failed" else "aborted" if status == "aborted" else "success")
    with build.cond:
        build.meta["status"] = status
        build.meta["ended"] = now()
    build.add_line("end", f"Finished: {status.upper()}")
    build.persist()
    if build.log_handle:
        build.log_handle.close()
        build.log_handle = None
    build.touch()


def execute_build(build: Build) -> None:
    pdef = build.pdef  # type: ignore[attr-defined]
    values = build.values  # type: ignore[attr-defined]
    if build.abort_requested:
        finish_build(build, "aborted")
        return

    job = getattr(build, "job", None)
    command = build_command(pdef, values, job)
    if build.meta.get("kind") == "repo_scan":
        command.extend(["--output-dir", build.meta["output_dir"], "--suppressions", str(suppression_file(build))])
    stage_res = [re.compile(s["match"]) for s in pdef["stages"]]
    progress_re = re.compile(pdef["progress_regex"]) if pdef["progress_regex"] else None
    env = os.environ.copy()
    env.update({"PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8", "NO_COLOR": "1"})
    token = get_token()
    if token:
        env[TOKEN_ENV] = token

    with build.cond:
        build.meta["status"] = "running"
        build.meta["started"] = now()
    build.persist()
    build.touch()
    build.add_line("info", f"Running in {pdef['cwd']}")
    build.add_line("info", "$ " + subprocess.list2cmdline(command))

    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    build.proc = subprocess.Popen(
        command, cwd=pdef["cwd"], env=env, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=flags,
    )
    in_error = False  # a traceback keeps coloring its following lines red

    def handle(text: str) -> None:
        nonlocal in_error
        text = ANSI_RE.sub("", text).rstrip()
        if progress_re:
            m = progress_re.search(text)
            if m:
                with build.cond:
                    build.meta["progress"] = {"done": int(m.group(1)), "total": int(m.group(2))}
                    build.version += 1
                    build.cond.notify_all()
                return
        if text.startswith(("[ERROR]", "Traceback", "ERROR:")):
            in_error = True
        elif not text or text.startswith("["):
            in_error = False
        level = "info"
        if in_error:
            level = "error"
        elif text.startswith(("[DONE]", "[COMPLETE]")):
            level = "ok"
        elif text.startswith("[STEP"):
            level = "step"
        elif text.startswith(("[WARN", "[SKIPPED]")):
            level = "warn"
        for index, regex in enumerate(stage_res):
            if regex.search(text):
                build.advance_stage(index)
                break
        build.add_line(level, text)

    def pump(stream) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        buffer = ""
        while True:
            chunk = stream.read1(4096)
            if not chunk:
                break
            buffer += decoder.decode(chunk)
            held = buffer.endswith("\r")
            if held:
                buffer = buffer[:-1]
            parts = buffer.replace("\r\n", "\n").split("\n")
            buffer = parts.pop() + ("\r" if held else "")
            for line in parts:
                for segment in (line.split("\r") if line else [""]):
                    handle(segment)
        buffer = buffer.rstrip("\r")
        if buffer:
            handle(buffer)

    reader = threading.Thread(target=pump, args=(build.proc.stdout,), daemon=True)
    reader.start()
    code = build.proc.wait()
    reader.join(timeout=5)

    if build.abort_requested:
        build.add_line("warn", "Build aborted by user")
        finish_build(build, "aborted")
    elif code == 0:
        if build.meta.get("kind") == "repo_scan":
            reconcile_repository_findings(build)
        finish_build(build, "success")
    else:
        build.add_line("error", f"ERROR: process exited with code {code}")
        finish_build(build, "failed")


# --------------------------------------------------------------------------
# Results (live Excel editor)
# --------------------------------------------------------------------------

def result_lock(output_dir: Path) -> threading.Lock:
    with LOCK:
        return RESULT_LOCKS.setdefault(str(output_dir), threading.Lock())


def suppression_file(build: Build) -> Path:
    source = os.path.normcase(str(Path(build.meta["params"]["source_dir"]).resolve()))
    digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    return DATA_DIR / "suppressions" / build.pipeline_id / f"{digest}.json"


def reconcile_repository_findings(build: Build) -> None:
    with LOCK:
        previous = sorted(
            (candidate for (pid, number), candidate in BUILDS.items()
             if pid == build.pipeline_id and number < build.number
             and candidate.meta.get("kind") == "repo_scan"
             and candidate.meta.get("status") == "success"
             and suppression_file(candidate) == suppression_file(build)),
            key=lambda candidate: candidate.number, reverse=True,
        )
    if not previous:
        return
    earlier = previous[0]
    previous_dir = Path(earlier.meta["output_dir"])
    output_dir = Path(build.meta["output_dir"])
    with result_lock(previous_dir):
        old_rows = read_rows(previous_dir, earlier.meta["results_file"])
    with result_lock(output_dir):
        rows = read_rows(output_dir, build.meta["results_file"])
        suppressed = json.loads((output_dir / "suppressed_findings.json").read_text(encoding="utf-8"))
        hidden = {row["fingerprint"] for row in suppressed}
        current = {row["fingerprint"]: row for row in rows}
        for old in old_rows:
            fingerprint = old["fingerprint"]
            if old.get("status") != "Open" or fingerprint in hidden:
                continue
            if fingerprint in current:
                current[fingerprint].update({key: old[key] for key in ("justification", "solution") if key in old})
            else:
                row = {**old, "detection": "Not detected", "sr_no": len(rows) + 1}
                rows.append(row)
        write_json_atomic(output_dir / build.meta["results_file"], rows)
        ok, message = run_export(build.pdef, output_dir)
        if not ok:
            raise RuntimeError(f"Excel export failed: {message}")


def find_issue_dir(output_dir: Path, sr_no: int) -> Path | None:
    issues = output_dir / "issues"
    if not issues.is_dir():
        return None
    prefix = f"issue_{sr_no:04d}_"
    return next((p for p in sorted(issues.iterdir()) if p.is_dir() and p.name.startswith(prefix)), None)


def read_rows(output_dir: Path, results_file: str) -> list[dict]:
    path = output_dir / results_file
    if not path.exists():
        raise FileNotFoundError("Results are not available for this build yet")
    return json.loads(path.read_text(encoding="utf-8"))


def run_export(pdef: dict, output_dir: Path) -> tuple[bool, str]:
    if not pdef["export_command"]:
        return True, ""
    command = [a.replace("{output_dir}", str(output_dir)) for a in pdef["export_command"]]
    if command[0].lower() in ("python", "python3", "py"):
        command[0] = sys.executable
    try:
        result = subprocess.run(command, cwd=pdef["cwd"], capture_output=True, text=True, timeout=120, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return False, "Excel export timed out"
    if result.returncode != 0:
        return False, (result.stderr or result.stdout).strip()[-600:]
    return True, ""


def clean_decision(data: dict) -> dict:
    status = str(data.get("status", "")).strip()
    lookup = {s.lower(): s for s in STATUSES}
    lookup.update({"false-positive": "False Positive", "fp": "False Positive"})
    status = lookup.get(status.lower(), "")
    if not status:
        raise ValueError(f"Status must be one of {list(STATUSES)}")
    justification = str(data.get("justification", "")).strip()
    if not justification:
        raise ValueError("Remarks must not be empty")
    solution = str(data.get("solution", "")).strip() or "Not Applicable"
    if len(justification) > 20000 or len(solution) > 20000:
        raise ValueError("Text is too long")
    return {"status": status, "justification": justification, "solution": solution}


def apply_decision(build: Build, sr_no: int, decision: dict, source: str) -> tuple[dict, str]:
    """Persist a decision to results JSON + issue folder, then re-export the Excel."""
    pdef = get_pipeline(build.pipeline_id)
    output_dir = Path(build.meta["output_dir"])
    with result_lock(output_dir):
        rows = read_rows(output_dir, build.meta["results_file"])
        row = next((r for r in rows if int(r.get("sr_no", -1)) == sr_no), None)
        if row is None:
            raise KeyError(f"Row {sr_no} not found")
        if build.meta.get("kind") == "repo_scan":
            if source not in ("manual", "reevaluated"):
                raise ValueError("Repository scan suppressions require a review")
            if decision["status"] == "False Positive" and decision["justification"] == "Awaiting review.":
                raise ValueError("Enter a reason before marking a finding false positive")
            ledger = suppression_file(build)
            with result_lock(ledger):
                suppressions = json.loads(ledger.read_text(encoding="utf-8")) if ledger.exists() else {}
                if decision["status"] == "False Positive":
                    suppressions[row["fingerprint"]] = {
                        **decision, **{key: row.get(key, "") for key in ("issue_name", "file_path", "rule_id", "category")},
                    }
                else:
                    suppressions.pop(row["fingerprint"], None)
                write_json_atomic(ledger, suppressions)
        row.update(decision)
        write_json_atomic(output_dir / build.meta["results_file"], rows)
        issue_dir = find_issue_dir(output_dir, sr_no)
        if issue_dir:
            write_json_atomic(issue_dir / "ai_decision.json", {**decision, "source": source})
        ok, message = run_export(pdef, output_dir)
    return {**row, "source": source}, ("" if ok else message)


def call_bridge(prompt: str) -> str:
    token = get_token()
    if not token:
        raise ValueError("Missing bridge token. Set it from Settings in the top bar.")
    request = urllib.request.Request(
        SETTINGS["bridge_url"] + "/ai/chat",
        data=json.dumps({"prompt": prompt}).encode("utf-8"),
        headers={"Content-Type": "application/json", "x-bridge-token": token},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=SETTINGS["reeval_timeout"]) as response:
            payload = json.loads(response.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Bridge API failed. HTTP {exc.code}" + BRIDGE_HINTS.get(exc.code, ""))
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(f"Bridge unreachable: {exc}")
    return str(payload.get("content", ""))


def parse_decision(content: str) -> dict:
    cleaned = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.IGNORECASE).strip()
    match = re.search(r"\{[\s\S]*\}", cleaned)
    if not match:
        raise ValueError("AI response did not contain JSON")
    return clean_decision(json.loads(match.group(0)))


def finding_prompt(row: dict, note: str) -> str:
    source = str(row.get("source_code", ""))[:4000]
    matched = []
    for item in (row.get("highlights") or [])[:5]:
        if isinstance(item, (list, tuple)) and len(item) == 2:
            start, end = int(item[0]), int(item[1])
            if 0 <= start < end <= len(source):
                matched.append(source[start:end])
    return f'''You are a security triage assistant reviewing one scanner finding.

Return ONLY valid JSON in this exact shape:
{{
  "status": "Open",
  "justification": "Professional evidence-based remarks",
  "solution": "Specific remediation or Not Applicable"
}}

The status must be exactly one of: Open, False Positive, Fixed.
Use only the source line shown. Do not invent unseen code, configuration, or runtime behavior.
Choose False Positive only when this line shows the pattern is not a real issue.
Choose Fixed only when this line shows a completed remediation.
Otherwise choose Open.
The justification must be exactly 2 concise professional lines, separated by \\n.
Do not include markdown, code fences, or text outside JSON.

Issue: {row.get("issue_name", "")}
Rule ID: {row.get("rule_id", "")}
Issue type: {row.get("issue_type", "")}
Severity: {row.get("severity", "")}
File: {row.get("file_path", "")}:{row.get("line", "")}
Matched text (up to five places): {json.dumps(matched)}
Source line:
{source}

Previous status: {row.get("status", "")}
Previous remarks: {row.get("justification", "")}
Reviewer note: {note or "Review this finding and confirm or correct the decision."}
'''


def reevaluate(build: Build, sr_no: int, note: str) -> tuple[dict, str]:
    output_dir = Path(build.meta["output_dir"])
    rows = read_rows(output_dir, build.meta["results_file"])
    current = next((r for r in rows if int(r.get("sr_no", -1)) == sr_no), None)
    if current is None:
        raise KeyError(f"Row {sr_no} not found")
    issue_dir = find_issue_dir(output_dir, sr_no)
    prompt_file = issue_dir / "ai_prompt.txt" if issue_dir else None
    if prompt_file and prompt_file.exists():
        prompt = prompt_file.read_text(encoding="utf-8", errors="replace")
        prompt += (
            "\n\nReviewer feedback (re-evaluation request):\n"
            f"Previous status: {current.get('status', '')}\n"
            f"Previous remarks: {current.get('justification', '')}\n"
            f"Reviewer note: {note or 'Re-check the evidence and confirm or correct the decision.'}\n"
            "Take the reviewer note into account, but the scanner evidence still decides the status.\n"
            "Return ONLY valid JSON in the same format as before."
        )
    else:
        prompt = finding_prompt(current, note)
    decision = parse_decision(call_bridge(prompt))
    return apply_decision(build, sr_no, decision, "reevaluated")


def get_pipeline(pipeline_id: str) -> dict:
    pdef = load_pipelines().get(pipeline_id)
    if not pdef:
        raise KeyError(f"Pipeline not found: {pipeline_id}")
    if pdef.get("kind") == "repo_scan":
        pdef = dict(pdef)
        params = [dict(param) for param in pdef.get("params", []) if param.get("name") != "config"]
        if not any(param.get("name") == "skip_accessibility" for param in params):
            params.append({"name": "skip_accessibility", "label": "Backend only (skip accessibility)", "type": "bool", "flag": "--skip-accessibility", "required": False})
        if not any(param.get("name") == "accessibility_only" for param in params):
            params.append({"name": "accessibility_only", "label": "Accessibility only (skip security)", "type": "bool", "flag": "--accessibility-only", "required": False})
        if not any(param.get("name") == "language" for param in params):
            params.append(next(dict(param) for param in pipeline_templates()["repo_scan"]["params"] if param["name"] == "language"))
        for param in params:
            if param.get("name") == "language" and param.get("type") == "choice":
                param["choices"] = list(dict.fromkeys([*(param.get("choices") or []), "html"]))
        if not any(param.get("name") == "skip_quality" for param in params):
            params.append({"name": "skip_quality", "label": "Skip code quality checks", "type": "bool", "flag": "--skip-quality", "required": False})
        pdef["params"] = params
    elif "manage_rules.py" in pdef.get("command", []):
        pdef = dict(pdef)
        params = [dict(param) for param in pipeline_templates()["security_rules"]["params"]]
        old_descriptions = {
            "Add a tested local Java security rule",
            "Add a tested local Java, Python or TypeScript security rule",
        }
        if pdef.get("description") in old_descriptions or pdef.get("id") == "security-rules":
            pdef["description"] = pipeline_templates()["security_rules"]["description"]
        existing_names = {param.get("name") for param in params}
        for param in pipeline_templates()["security_rules"]["params"]:
            if param["name"] in ("language", "issue_type", "category") and param["name"] not in existing_names:
                params.append(dict(param))
        for param in params:
            if param.get("name") == "language" and param.get("type") == "choice":
                param["choices"] = list(dict.fromkeys([*(param.get("choices") or []), "java", "python", "typescript", "html"]))
        pdef["params"] = params
    default = pipeline_templates().get(pipeline_id, {})
    default_jobs = default.get("jobs") or []
    current_jobs = pdef.get("jobs") or []
    if default_jobs:
        current_ids = {str(job.get("id", "")).strip().lower() for job in current_jobs if isinstance(job, dict)}
        default_ids = {str(job.get("id", "")).strip().lower() for job in default_jobs if isinstance(job, dict)}
        missing_core = bool(default_ids - current_ids)
        if not current_jobs or missing_core:
            pdef = dict(pdef)
            pdef["jobs"] = default_jobs
    return pdef


def get_build(pipeline_id: str, number: int) -> Build:
    build = BUILDS.get((pipeline_id, number))
    if not build:
        raise KeyError(f"Build #{number} not found")
    return build


# --------------------------------------------------------------------------
# HTTP layer
# --------------------------------------------------------------------------

ROUTES: list[tuple[str, re.Pattern, callable]] = []


def route(method: str, pattern: str):
    def decorator(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn))
        return fn
    return decorator


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class Handler(BaseHTTPRequestHandler):
    server_version = "TriageConsole"

    def log_message(self, fmt, *args) -> None:  # keep the terminal quiet
        pass

    # helpers
    def send_json(self, data, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self, limit: int = 2_000_000) -> bytes:
        length = int(self.headers.get("Content-Length") or 0)
        if length > limit:
            raise ApiError(413, "Request body too large")
        return self.rfile.read(length) if length else b""

    def read_json(self) -> dict:
        try:
            data = json.loads(self.read_body() or b"{}")
        except json.JSONDecodeError:
            raise ApiError(400, "Invalid JSON body")
        if not isinstance(data, dict):
            raise ApiError(400, "JSON object expected")
        return data

    def guard(self, method: str) -> None:
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if host not in ("127.0.0.1", "localhost"):
            raise ApiError(403, "Forbidden host")
        if method != "GET":
            origin = self.headers.get("Origin")
            if origin and urlparse(origin).hostname not in ("127.0.0.1", "localhost"):
                raise ApiError(403, "Forbidden origin")
            if self.headers.get("X-Triage-Token") != SESSION_TOKEN:
                raise ApiError(403, "Missing or invalid session token")

    def dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        self.query = parse_qs(parsed.query)
        try:
            self.guard(method)
            path = parsed.path
            for route_method, pattern, fn in ROUTES:
                match = pattern.match(path)
                if route_method == method and match:
                    fn(self, **{k: unquote(v) for k, v in match.groupdict().items()})
                    return
            if method == "GET" and not path.startswith("/api/"):
                self.serve_static(path)
                return
            raise ApiError(404, "Not found")
        except ApiError as exc:
            self.send_json({"error": str(exc)}, exc.status)
        except KeyError as exc:
            self.send_json({"error": str(exc.args[0]) if exc.args else "Not found"}, 404)
        except (ValueError, FileNotFoundError) as exc:
            self.send_json({"error": str(exc)}, 400)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as exc:
            try:
                self.send_json({"error": f"Server error: {exc}"}, 500)
            except OSError:
                pass

    def do_GET(self): self.dispatch("GET")
    def do_POST(self): self.dispatch("POST")
    def do_PUT(self): self.dispatch("PUT")
    def do_DELETE(self): self.dispatch("DELETE")

    def serve_static(self, path: str) -> None:
        name = "index.html" if path in ("/", "") else path.lstrip("/")
        target = (STATIC_DIR / name).resolve()
        if STATIC_DIR.resolve() not in target.parents or not target.is_file():
            raise ApiError(404, "Not found")
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path: Path, download_name: str) -> None:
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(download_name)[0] or "application/octet-stream")
        self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def pipeline_summary(pdef: dict) -> dict:
    if "manage_rules.py" in pdef.get("command", []) and pdef.get("description") in {
        "Add a tested local Java security rule",
        "Add a tested local Java, Python or TypeScript security rule",
    }:
        pdef = {**pdef, "description": "Add one issue type as regex patterns, not a specific IP, query, or secret, for Java, Python, TypeScript, or HTML"}
    builds = sorted((b for (pid, _), b in BUILDS.items() if pid == pdef["id"]), key=lambda b: b.number, reverse=True)

    def latest(status: str):
        match = next((b for b in builds if b.meta.get("status") == status), None)
        return {"id": match.number, "ended": match.meta.get("ended")} if match else None

    return {
        **pdef,
        "recent": [{"id": b.number, "status": b.meta.get("status")} for b in builds[:10]],
        "last": builds[0].public() if builds else None,
        "last_success": latest("success"),
        "last_failure": latest("failed"),
    }


def permalinks(builds: list[Build]) -> dict:
    def last(predicate):
        match = next((b for b in builds if predicate(b.meta.get("status"))), None)
        return match.number if match else None

    return {
        "last_build": builds[0].number if builds else None,
        "last_successful": last(lambda s: s == "success"),
        "last_failed": last(lambda s: s == "failed"),
        "last_completed": last(lambda s: s in ("success", "failed", "aborted")),
    }


@route("GET", r"/api/session")
def api_session(h: Handler) -> None:
    h.send_json({"token": SESSION_TOKEN})


def choose_directory() -> str:
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    try:
        root.withdraw()
        root.attributes("-topmost", True)
        return filedialog.askdirectory(parent=root, title="Select source repository")
    finally:
        root.destroy()


@route("POST", r"/api/browse-directory")
def api_browse_directory(h: Handler) -> None:
    try:
        path = choose_directory()
    except Exception as exc:
        raise ApiError(503, f"Folder picker unavailable; enter the path manually: {exc}")
    h.send_json({"path": path})


@route("GET", r"/api/settings")
def api_settings(h: Handler) -> None:
    bridge = "down"
    try:
        with urllib.request.urlopen(SETTINGS["bridge_url"] + "/health", timeout=2) as response:
            bridge = "up" if response.status == 200 else "down"
    except (urllib.error.URLError, OSError):
        pass
    h.send_json({
        "token_set": bool(get_token()),
        "bridge": bridge,
        "bridge_url": SETTINGS["bridge_url"],
        "reeval_timeout": SETTINGS["reeval_timeout"],
    })


@route("POST", r"/api/settings")
def api_update_settings(h: Handler) -> None:
    body = h.read_json()
    update_settings({k: body[k] for k in ("bridge_url", "reeval_timeout") if k in body})
    h.send_json({"bridge_url": SETTINGS["bridge_url"], "reeval_timeout": SETTINGS["reeval_timeout"]})


@route("POST", r"/api/settings/token")
def api_set_token(h: Handler) -> None:
    SETTINGS["token"] = str(h.read_json().get("token", "")).strip()
    h.send_json({"token_set": bool(get_token())})


@route("GET", r"/api/templates")
def api_templates(h: Handler) -> None:
    h.send_json(pipeline_templates())


@route("GET", r"/api/pipelines")
def api_pipelines(h: Handler) -> None:
    h.send_json([pipeline_summary(p) for p in load_pipelines().values()])


@route("POST", r"/api/pipelines")
def api_create_pipeline(h: Handler) -> None:
    pdef = validate_pipeline(h.read_json())
    with LOCK:
        pipelines = load_pipelines()
        if pdef["id"] in pipelines:
            raise ApiError(409, f"Pipeline '{pdef['id']}' already exists")
        pipelines[pdef["id"]] = pdef
        save_pipelines(pipelines)
    h.send_json(pdef, 201)


@route("PUT", r"/api/pipelines/(?P<pid>[^/]+)")
def api_update_pipeline(h: Handler, pid: str) -> None:
    body = h.read_json()
    body["id"] = pid
    pdef = validate_pipeline(body)
    with LOCK:
        pipelines = load_pipelines()
        if pid not in pipelines:
            raise ApiError(404, "Pipeline not found")
        pipelines[pid] = pdef
        save_pipelines(pipelines)
    h.send_json(pdef)


@route("DELETE", r"/api/pipelines/(?P<pid>[^/]+)")
def api_delete_pipeline(h: Handler, pid: str) -> None:
    with LOCK:
        pipelines = load_pipelines()
        if pipelines.pop(pid, None) is None:
            raise ApiError(404, "Pipeline not found")
        save_pipelines(pipelines)
    h.send_json({"deleted": pid})


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)")
def api_pipeline(h: Handler, pid: str) -> None:
    pdef = get_pipeline(pid)
    builds = sorted((b for (p, _), b in BUILDS.items() if p == pid), key=lambda b: b.number, reverse=True)
    h.send_json({"pipeline": pdef, "builds": [b.public() for b in builds[:50]], "permalinks": permalinks(builds)})


@route("POST", r"/api/pipelines/(?P<pid>[^/]+)/build")
def api_build(h: Handler, pid: str) -> None:
    pdef = get_pipeline(pid)
    body = h.read_json()
    rebuild_of = body.get("rebuild_of")
    params = body.get("params")
    job = body.get("job")
    if rebuild_of is not None:
        source = get_build(pid, int(rebuild_of))
        params = params if isinstance(params, dict) else source.meta.get("params", {})
        if job is None:
            source_job = source.meta.get("job") if isinstance(source.meta.get("job"), dict) else {}
            job = source_job.get("id")
        rebuild_of = int(rebuild_of)
    build = enqueue_build(pdef, params if isinstance(params, dict) else {}, rebuild_of, job if isinstance(job, str) else None)
    h.send_json(build.public(), 201)


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)")
def api_build_detail(h: Handler, pid: str, n: str) -> None:
    h.send_json(get_build(pid, int(n)).public())


@route("POST", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/stop")
def api_stop(h: Handler, pid: str, n: str) -> None:
    build = get_build(pid, int(n))
    if build.finished:
        raise ApiError(409, "Build already finished")
    build.abort_requested = True
    if build.proc and build.proc.poll() is None:
        kill_tree(build.proc)
    h.send_json({"stopping": True})


@route("DELETE", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)")
def api_delete_build(h: Handler, pid: str, n: str) -> None:
    build = get_build(pid, int(n))
    if not build.finished:
        raise ApiError(409, "Stop the build before deleting it")
    with LOCK:
        BUILDS.pop((pid, int(n)), None)
    shutil.rmtree(build.dir, ignore_errors=True)
    h.send_json({"deleted": int(n)})


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/console")
def api_console(h: Handler, pid: str, n: str) -> None:
    build = get_build(pid, int(n))
    build.load_lines()
    with build.cond:
        text = "\n".join(line["t"] for line in build.lines).encode("utf-8")
    h.send_response(200)
    h.send_header("Content-Type", "text/plain; charset=utf-8")
    h.send_header("Content-Disposition", f'attachment; filename="{pid}-build-{n}-console.txt"')
    h.send_header("Content-Length", str(len(text)))
    h.end_headers()
    h.wfile.write(text)


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/events")
def api_events(h: Handler, pid: str, n: str) -> None:
    build = get_build(pid, int(n))
    build.load_lines()
    sent = max(0, int(h.query.get("from", ["0"])[0] or 0))
    h.send_response(200)
    h.send_header("Content-Type", "text/event-stream; charset=utf-8")
    h.send_header("Cache-Control", "no-store")
    h.send_header("X-Accel-Buffering", "no")
    h.end_headers()

    def emit(event: str, data, event_id: int | None = None) -> None:
        head = f"id: {event_id}\n" if event_id is not None else ""
        h.wfile.write(f"{head}event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n".encode("utf-8"))
        h.wfile.flush()

    last_version = -1
    try:
        while True:
            with build.cond:
                if sent >= len(build.lines) and last_version == build.version and not build.finished:
                    if not build.cond.wait(timeout=15):
                        h.wfile.write(b": keep-alive\n\n")
                        h.wfile.flush()
                        continue
                new_lines = build.lines[sent:]
                version = build.version
                done = build.finished
            for entry in new_lines:
                sent += 1
                emit("log", entry, sent)
            if version != last_version:
                last_version = version
                emit("state", build.public())
            if done and sent >= len(build.lines):
                emit("end", {"status": build.meta.get("status")})
                return
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
        return


def results_context(pid: str, n: str) -> tuple[dict, Build, Path]:
    pdef = get_pipeline(pid)
    build = get_build(pid, int(n))
    if not build.meta.get("output_dir") or not build.meta.get("results_file"):
        raise ValueError("This build produced no results")
    return pdef, build, Path(build.meta["output_dir"])


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/results")
def api_results(h: Handler, pid: str, n: str) -> None:
    pdef, build, output_dir = results_context(pid, n)
    rows = read_rows(output_dir, build.meta["results_file"])
    for row in rows:
        issue_dir = find_issue_dir(output_dir, int(row.get("sr_no", 0)))
        decision = issue_dir / "ai_decision.json" if issue_dir else None
        if decision and decision.exists():
            try:
                row["source"] = json.loads(decision.read_text(encoding="utf-8")).get("source", "ai")
            except json.JSONDecodeError:
                row["source"] = "ai"
    columns = pdef["columns"] or [
        {"key": k, "label": k.replace("_", " ").title()}
        for k in (rows[0].keys() if rows else [])
        if k not in EDITABLE_FIELDS and k != "source"
    ]
    excel = output_dir / build.meta["excel"] if build.meta.get("excel") else None
    suppressions = {}
    if build.meta.get("kind") == "repo_scan":
        ledger = suppression_file(build)
        with result_lock(ledger):
            suppressions = json.loads(ledger.read_text(encoding="utf-8")) if ledger.exists() else {}
    h.send_json({
        "rows": rows,
        "columns": columns,
        "statuses": list(STATUSES),
        "excel": build.meta.get("excel"),
        "excel_mtime": excel.stat().st_mtime if excel and excel.exists() else None,
        "can_reevaluate": bool(get_token()),
        "repository_scan": build.meta.get("kind") == "repo_scan",
        "suppressions": [{"fingerprint": fingerprint, **decision} for fingerprint, decision in suppressions.items()],
    })


@route("DELETE", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/suppressions/(?P<fingerprint>[a-f0-9]{64})")
def api_remove_suppression(h: Handler, pid: str, n: str, fingerprint: str) -> None:
    _, build, _ = results_context(pid, n)
    if build.meta.get("kind") != "repo_scan":
        raise ValueError("Suppressions are only available for repository scans")
    ledger = suppression_file(build)
    with result_lock(ledger):
        suppressions = json.loads(ledger.read_text(encoding="utf-8")) if ledger.exists() else {}
        if fingerprint not in suppressions:
            raise ApiError(404, "Suppression not found")
        del suppressions[fingerprint]
        write_json_atomic(ledger, suppressions)
    h.send_json({"removed": fingerprint})


@route("PUT", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/results/(?P<sr>\d+)")
def api_edit_row(h: Handler, pid: str, n: str, sr: str) -> None:
    _, build, _ = results_context(pid, n)
    body = h.read_json()
    decision = clean_decision(body)
    row, export_error = apply_decision(build, int(sr), decision, "manual")
    h.send_json({"row": row, "export_error": export_error})


@route("POST", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/results/(?P<sr>\d+)/reevaluate")
def api_reevaluate(h: Handler, pid: str, n: str, sr: str) -> None:
    _, build, _ = results_context(pid, n)
    note = str(h.read_json().get("note", ""))[:2000]
    try:
        row, export_error = reevaluate(build, int(sr), note)
    except (RuntimeError, json.JSONDecodeError) as exc:
        raise ApiError(502, str(exc))
    h.send_json({"row": row, "export_error": export_error})


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/results/(?P<sr>\d+)/evidence")
def api_evidence(h: Handler, pid: str, n: str, sr: str) -> None:
    _, build, output_dir = results_context(pid, n)
    issue_dir = find_issue_dir(output_dir, int(sr))
    files = {}
    highlights = []
    if issue_dir:
        for name in EVIDENCE_FILES:
            path = issue_dir / name
            if path.exists():
                files[name] = path.read_text(encoding="utf-8", errors="replace")[:20000]
    if not files:
        rows = read_rows(output_dir, build.meta["results_file"])
        row = next((item for item in rows if int(item.get("sr_no", -1)) == int(sr)), None)
        if row:
            files["source.txt"] = str(row.get("source_code", ""))[:20000]
            files["finding.json"] = json.dumps({
                key: row.get(key, "")
                for key in ("issue_name", "rule_id", "issue_type", "category", "severity", "file_path", "line", "status")
            }, indent=2)
            highlights = row.get("highlights") or []
    h.send_json({"files": files, "highlights": highlights})


@route("GET", r"/api/pipelines/(?P<pid>[^/]+)/builds/(?P<n>\d+)/excel")
def api_excel(h: Handler, pid: str, n: str) -> None:
    _, build, output_dir = results_context(pid, n)
    name = build.meta.get("excel")
    path = output_dir / name if name else None
    if not path or not path.exists():
        raise ApiError(404, "No Excel report for this build")
    h.send_file(path, name)


@route("POST", r"/api/upload")
def api_upload(h: Handler) -> None:
    name = Path(h.query.get("name", ["upload.bin"])[0]).name or "upload.bin"
    name = re.sub(r"[^\w.\- ]", "_", name)
    body = h.read_body(MAX_UPLOAD_BYTES)
    if not body:
        raise ApiError(400, "Empty upload")
    target = UPLOADS_DIR / secrets.token_hex(4) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    h.send_json({"path": str(target), "name": name, "size": len(body)})


def serve(port: int, open_browser: bool = True) -> None:
    load_settings()
    load_existing_builds()
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    print(f"[UI] Triage Console running at {url}  (Ctrl+C to stop)")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[UI] Stopped")
    finally:
        server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Triage Console web UI for SAST and DAST pipelines")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    serve(args.port, open_browser=not args.no_browser)
