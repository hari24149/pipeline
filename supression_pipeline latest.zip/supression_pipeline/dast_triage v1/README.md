# DAST Triage Automation

## Purpose

DAST Triage Automation processes Fortify WebInspect DAST PDF reports, groups scanner findings, prepares evidence packets, requests triage decisions from the local Copilot bridge, and exports an Excel suppression report.

## Requirements

- Windows PowerShell and Python 3.
- A Fortify WebInspect DAST PDF report.
- A running local Copilot bridge at `http://127.0.0.1:3210`.
- A `COPILOT_BRIDGE_TOKEN` set in the active PowerShell session.

Install dependencies from this folder:

```powershell
python -m pip install -r requirements.txt
```

## Quick Start

Set the bridge token without placing it in a file, chat, or source control:

```powershell
$env:COPILOT_BRIDGE_TOKEN="YOUR_TOKEN_HERE"
```

Run the report:

```powershell
python main.py --pdf "C:\Users\2785364\Downloads\A0897.pdf"
```

Verify that the bridge is running:

```powershell
Invoke-WebRequest http://127.0.0.1:3210/health
```

## Commands

| Command | Use |
| --- | --- |
| `python main.py --pdf <file>` | Run the DAST triage pipeline with two-line Excel-ready remarks. |
| `python main.py --pdf <file> --justification-style default` | Generate detailed 4-6 line AI remarks. |
| `python main.py --help` | Show the concise argument reference. |
| `python main.py --help-guide` or `python main.py --guide` | Show the detailed PowerShell usage guide. |

The default `short` justification style requests exactly two concise professional lines for the Application Team Remarks column.

## How It Works

1. Extracts raw text from the Fortify WebInspect PDF.
2. Cleans the extracted text.
3. Splits the report into Security Issues Summary, Security Issues Details, and Category Descriptions.
4. Groups issues by category, severity, and occurrence count.
5. Builds an evidence packet containing scanner evidence, category context, and known notes.
6. Creates an AI prompt for each grouped issue.
7. Sends prompts to the local Copilot bridge and validates the returned decision JSON.
8. Merges the decisions into the grouped findings.
9. Creates the Excel suppression report.

The bridge decision must use one of these statuses:

- `Open`: scanner evidence supports a real remediation need.
- `False Positive`: evidence does not demonstrate an exploitable condition or proves expected behavior.
- `Fixed`: evidence proves remediation is already in place.

## Known Notes

Use [knowledge/dast_known_notes.txt](knowledge/dast_known_notes.txt) to provide trusted, finding-specific application context. A report-specific `known_notes.txt` placed in the output folder takes priority.

```text
### Often Misused: HTTP Method Override
status: False Positive
remarks:
The application processes the request only as POST and does not honor method overrides.
solution:
Not Applicable
```

Known notes are matched by finding name, ignoring case and punctuation. The bridge retains the technical meaning but rewrites it into professional output when the scanner evidence does not conflict.

## Outputs

For `A0897.pdf`, output is created under:

```text
output\dast\A0897\
```

| Artifact | Description |
| --- | --- |
| `raw_text.txt` | Text extracted from the PDF. |
| `clean_text.txt` | Normalized report text. |
| `security_issues_summary.txt` | Severity-grouped finding summary. |
| `security_issues_details.txt` | Scanner request/response evidence. |
| `category_descriptions.txt` | Fortify category descriptions and remediation context. |
| `grouped_issues.json` | Grouped findings before AI decisions. |
| `issues\issue_*\issue_packet.json` | Evidence, category context, and known notes for one issue. |
| `issues\issue_*\ai_prompt.txt` | Prompt sent to the bridge. |
| `issues\issue_*\ai_response_raw.json` | Raw bridge response. |
| `issues\issue_*\ai_decision.json` | Validated triage decision. |
| `grouped_issues_with_ai.json` | Findings with merged decisions. |
| `<application>_DAST_SuppressionReport.xlsx` | Final Excel report. |

The example report produces `A0897_DAST_SuppressionReport.xlsx`.

## Terminal Progress

Each DAST phase displays a PowerShell progress line after it completes. While the bridge processes issue prompts, the current step shows a spinner, decision count, elapsed time, and estimated remaining time.

## Troubleshooting

| Message | Resolution |
| --- | --- |
| `PDF file not found` | Use the actual full path to an existing Fortify WebInspect PDF. |
| `Input file must be a PDF` | Provide a file ending in `.pdf`. |
| `Missing bridge token` | Set `$env:COPILOT_BRIDGE_TOKEN` in the same PowerShell session. |
| Bridge API error | Verify the bridge with `Invoke-WebRequest http://127.0.0.1:3210/health` and confirm the token. |
| No issue packets or prompts | Inspect the extracted summary and details files to confirm the report follows the expected Fortify WebInspect format. |