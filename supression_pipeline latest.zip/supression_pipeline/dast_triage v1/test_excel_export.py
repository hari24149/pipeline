from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT_DIR = Path(__file__).parent
sys.path.insert(0, str(PROJECT_DIR))

from Dast.excel_export import export_dast_excel
from Dast.ai_client import format_progress, render_progress


class DastExcelExportTests(unittest.TestCase):
    def test_progress_bar_is_visible_before_completion(self) -> None:
        self.assertEqual(
            format_progress(1, 37),
            "[/---------------------------------------]   2% (1/37) AI decisions",
        )
        self.assertEqual(
            format_progress(37, 37),
            "[////////////////////////////////////////] 100% (37/37) AI decisions",
        )

    def test_colored_progress_can_fall_back_to_plain_text(self) -> None:
        self.assertEqual(render_progress(1, 37, color_enabled=False), format_progress(1, 37))
        self.assertIn("\033[96m", render_progress(1, 37, color_enabled=True))

    def test_export_uses_application_suppression_report_name(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            output_dir = Path(temporary_dir) / "A0005"
            output_dir.mkdir()
            (output_dir / "grouped_issues_with_ai.json").write_text(
                json.dumps([{"sr_no": 1, "issue_name": "Example Finding"}]),
                encoding="utf-8",
            )

            excel_file = export_dast_excel(str(output_dir))

            self.assertEqual(excel_file.name, "A0005_DAST_SuppressionReport.xlsx")
            self.assertTrue(excel_file.exists())


if __name__ == "__main__":
    unittest.main()