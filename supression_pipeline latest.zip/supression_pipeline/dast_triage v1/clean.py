from __future__ import annotations

import re
from pathlib import Path


def read_raw_text(input_file: str = "output/raw_text.txt") -> str:
    """
    Read raw extracted text from Phase 1.
    """
    path = Path(input_file)

    if not path.exists():
        raise FileNotFoundError(f"Raw text file not found: {input_file}")

    return path.read_text(encoding="utf-8", errors="ignore")


def clean_text(raw_text: str) -> str:
    """
    Phase 2:
    Clean raw PDF text.

    Important:
    - Do not remove HTTP request/response evidence.
    - Do not remove URLs.
    - Do not remove vulnerability names.
    """
    if not raw_text:
        return ""

    text = raw_text

    # Normalize line endings
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # Remove PDF page markers added by our extractor
    text = re.sub(r"\n?\s*--- PAGE \d+ ---\s*\n?", "\n", text)

    # Remove common Fortify/OpenText footer lines
    text = re.sub(
        r"(?im)^\s*Jun\s+\d{1,2},\s+\d{4}\s+\d{1,2}:\d{2}\s+(?:AM|PM)\s+\d+\s*$",
        "",
        text,
    )

    text = re.sub(
        r"(?im)^\s*©\s*Copyright\s+2008-2026\s+Open\s+Text\.\s*$",
        "",
        text,
    )

    # Remove markdown/image placeholder style text if present
    text = re.sub(r"!\[\]\[[^\]]+\]", "", text)

    # Normalize tabs/spaces, but keep line structure
    text = re.sub(r"[ \t]+", " ", text)

    # Remove spaces before newlines
    text = re.sub(r" +\n", "\n", text)

    # Reduce too many blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def save_clean_text(cleaned_text: str, output_file: str = "output/clean_text.txt") -> Path:
    """
    Save cleaned text to output/clean_text.txt.
    """
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(cleaned_text, encoding="utf-8")

    return path


def run_cleaning(
    input_file: str = "output/raw_text.txt",
    output_file: str = "output/clean_text.txt",
) -> Path:
    """
    Full Phase 2 runner.
    """
    raw_text = read_raw_text(input_file)
    cleaned = clean_text(raw_text)
    return save_clean_text(cleaned, output_file)