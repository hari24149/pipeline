from __future__ import annotations

from pathlib import Path
from typing import Callable

from extract import extract_pdf_text, save_raw_text
from clean import clean_text, save_clean_text
from Dast.sections import extract_report_sections, save_report_sections
from Dast.parse_summary import run_parse_summary
from Dast.evidence import run_evidence_extraction
from Dast.ai_prompt import run_ai_prompt_generation
from Dast.ai_client import run_ai_decision
from Dast.merge_ai import merge_ai_decisions
from Dast.excel_export import export_dast_excel


# (key, label shown in terminal and UI)
STAGES: list[tuple[str, str]] = [
    ("extract", "Extract PDF text"),
    ("clean", "Clean text"),
    ("sections", "Split report sections"),
    ("group", "Group findings"),
    ("evidence", "Build evidence packets"),
    ("prompts", "Generate AI prompts"),
    ("ai", "AI triage decisions"),
    ("merge", "Merge decisions"),
    ("excel", "Export Excel report"),
]


class BuildAborted(Exception):
    """Raised when a stop was requested while the pipeline was running."""


class Hooks:
    """Callbacks the terminal and the web UI use to observe a pipeline run."""

    def log(self, line: str, level: str = "info") -> None:
        pass

    def stage_start(self, index: int, total: int, key: str, label: str) -> None:
        pass

    def stage_end(self, index: int, total: int, key: str, label: str, status: str) -> None:
        pass

    def ai_progress(self, done: int, total: int) -> None:
        pass

    def should_stop(self) -> bool:
        return False


def _read(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(
            f"Required input missing: {path}. Rebuild from an earlier stage."
        )
    return path.read_text(encoding="utf-8", errors="ignore")


def run_pipeline(
    pdf_path: str,
    output_dir: Path,
    justification_style: str,
    hooks: Hooks,
    start_stage: int = 1,
    end_stage: int | None = None,
    resume_ai: bool = False,
    skip_ai: bool = False,
) -> Path:
    """
    Run stages start_stage..end_stage. Earlier stages are expected to have their
    artifacts already on disk. Returns the exported Excel path.
    """
    out = str(output_dir)
    total = len(STAGES)
    if end_stage is None:
        end_stage = total
    if start_stage < 1 or end_stage > total or start_stage > end_stage:
        raise ValueError(f"Stage range must be between 1 and {total}, and start_stage <= end_stage")
    excel_file: Path | None = None

    def run_stage(index: int) -> None:
        nonlocal excel_file
        key = STAGES[index - 1][0]
        log = hooks.log

        if key == "extract":
            raw_text = extract_pdf_text(pdf_path)
            raw_file = save_raw_text(raw_text, out)
            log("[DONE] Raw text extraction completed", "ok")
            log(f"[OUTPUT] Raw text saved at: {raw_file}")
            log(f"[INFO] Raw extracted characters: {len(raw_text)}")
        elif key == "clean":
            raw_text = _read(output_dir / "raw_text.txt")
            cleaned = clean_text(raw_text)
            clean_file = save_clean_text(cleaned, str(output_dir / "clean_text.txt"))
            log("[DONE] Text cleaning completed", "ok")
            log(f"[OUTPUT] Clean text saved at: {clean_file}")
            log(f"[INFO] Cleaned characters: {len(cleaned)}")
        elif key == "sections":
            cleaned = _read(output_dir / "clean_text.txt")
            sections = extract_report_sections(cleaned)
            saved = save_report_sections(sections, out)
            log("[DONE] Section extraction completed", "ok")
            log(f"[OUTPUT] Security Issues Summary: {saved['security_issues_summary']}")
            log(f"[OUTPUT] Security Issues Details: {saved['security_issues_details']}")
            log(f"[OUTPUT] Category Descriptions: {saved['category_descriptions']}")
            log(f"[INFO] Summary characters: {len(sections['security_issues_summary'])}")
            log(f"[INFO] Details characters: {len(sections['security_issues_details'])}")
            log(f"[INFO] Category characters: {len(sections['category_descriptions'])}")
        elif key == "group":
            grouped_file = run_parse_summary(out)
            log("[DONE] Grouped issue parsing completed", "ok")
            log(f"[OUTPUT] Grouped issues JSON: {grouped_file}")
        elif key == "evidence":
            issues_dir = run_evidence_extraction(out)
            log("[DONE] Issue evidence packet creation completed", "ok")
            log(f"[OUTPUT] Issues folder: {issues_dir}")
        elif key == "prompts":
            prompt_dir = run_ai_prompt_generation(out, justification_style=justification_style)
            log("[DONE] AI prompt generation completed", "ok")
            log(f"[OUTPUT] AI prompts generated under: {prompt_dir}")
        elif key == "ai":
            if skip_ai:
                log("[SKIPPED] AI triage decisions (--skip-ai)", "warn")
            else:
                log("[AI] Sending decision requests to the local Copilot bridge.")
                response_dir = run_ai_decision(
                    out,
                    progress_callback=hooks.ai_progress,
                    should_stop=hooks.should_stop,
                    skip_existing=resume_ai,
                )
                if hooks.should_stop():
                    raise BuildAborted("Build aborted by user")
                log("[DONE] AI decision generation completed", "ok")
                log(f"[OUTPUT] AI decisions saved under: {response_dir}")
        elif key == "merge":
            merged = merge_ai_decisions(out)
            log("[DONE] AI decision merge completed", "ok")
            log(f"[OUTPUT] Grouped issues with AI: {merged}")
        elif key == "excel":
            excel_file = export_dast_excel(out)
            log("[DONE] Excel export completed", "ok")
            log(f"[OUTPUT] Final Excel report: {excel_file}")

    for index in range(start_stage, end_stage + 1):
        key, label = STAGES[index - 1]
        if hooks.should_stop():
            raise BuildAborted("Build aborted by user")
        hooks.stage_start(index, total, key, label)
        try:
            run_stage(index)
        except BuildAborted:
            hooks.stage_end(index, total, key, label, "aborted")
            raise
        except Exception:
            hooks.stage_end(index, total, key, label, "failed")
            raise
        hooks.stage_end(index, total, key, label, "success")

    if excel_file is None:
        excel_file = output_dir / f"{output_dir.name}_DAST_SuppressionReport.xlsx"
    return excel_file
