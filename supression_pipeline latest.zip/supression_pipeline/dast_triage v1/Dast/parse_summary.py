from __future__ import annotations

import json
import re
from pathlib import Path


SEVERITIES = {"Critical", "High", "Medium", "Low", "Info", "Informational"}


def read_security_summary(summary_file: str) -> str:
    """
    Read Security Issues Summary section text.
    """
    path = Path(summary_file)

    if not path.exists():
        raise FileNotFoundError(f"Security summary file not found: {summary_file}")

    return path.read_text(encoding="utf-8", errors="ignore")


def parse_grouped_issues(summary_text: str) -> list[dict]:
    """
    Parse grouped DAST issues from Security Issues Summary.

    Expected lines:
        High
        Often Misused: HTTP Method Override 1 Issue

        Low
        System Information Leak: External 65 Issues
    """
    grouped_issues: list[dict] = []
    current_severity = ""

    issue_pattern = re.compile(
        r"^(?P<issue_name>.+?)\s+(?P<count>\d+)\s+Issues?$",
        flags=re.IGNORECASE,
    )

    lines = [line.strip() for line in summary_text.splitlines() if line.strip()]

    for line in lines:
        normalized_line = line.capitalize()

        if normalized_line in SEVERITIES:
            current_severity = normalized_line
            continue

        match = issue_pattern.match(line)

        if match and current_severity:
            issue_name = match.group("issue_name").strip()
            occurrences = int(match.group("count"))

            grouped_issues.append(
                {
                    "sr_no": len(grouped_issues) + 1,
                    "issue_name": issue_name,
                    "severity": current_severity,
                    "occurrences": occurrences,
                    "status": "",
                    "justification": "",
                }
            )

    return grouped_issues


def save_grouped_issues(grouped_issues: list[dict], output_file: str) -> Path:
    """
    Save grouped issues as JSON.
    """
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(grouped_issues, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    return path


def run_parse_summary(output_dir: str) -> Path:
    """
    Phase 4 runner:
        security_issues_summary.txt -> grouped_issues.json
    """
    output_path = Path(output_dir)

    summary_file = output_path / "security_issues_summary.txt"
    grouped_file = output_path / "grouped_issues.json"

    summary_text = read_security_summary(str(summary_file))
    grouped_issues = parse_grouped_issues(summary_text)

    if not grouped_issues:
        clean_file = output_path / "clean_text.txt"
        clean_text = clean_file.read_text(encoding="utf-8", errors="ignore") if clean_file.exists() else ""
        if re.search(r"(?m)^No Issues\s*$", clean_text):
            raise ValueError(
                "The Fortify WebInspect report states 'No Issues' (0 findings), so there is nothing to triage. "
                "Export the report from a scan that contains findings."
            )
        raise ValueError(
            "No findings were found in the Security Issues Summary "
            f"({len(summary_text)} characters). The PDF looks incomplete or is not a "
            "Fortify WebInspect report with a findings list; export the full DAST report and retry."
        )

    return save_grouped_issues(grouped_issues, str(grouped_file))