from __future__ import annotations

import json
from pathlib import Path


def read_json_file(file_path: Path) -> dict:
    """
    Read JSON object from file.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"JSON file not found: {file_path}")

    return json.loads(file_path.read_text(encoding="utf-8"))


def get_justification_rule(justification_style: str) -> str:
    """
    Return justification instructions based on selected style.

    Supported styles:
        short   -> exactly 2 Excel-ready lines
        default -> 4 to 6 detailed professional lines
    """
    if justification_style == "short":
        return """
- The justification must be exactly 2 concise professional lines separated by \\n.
- The justification must be suitable for Excel/Application Team Remarks.
- Each line should be clear, evidence-based, specific, and not generic.
""".strip()

    if justification_style == "default":
        return """
- The justification should be concise but can include 4 to 6 professional lines separated by \\n.
- The justification must clearly explain the evidence-based reason for the selected status.
- The justification must be suitable for detailed security review notes.
- Each line should be specific to the evidence and should not be generic.
""".strip()

    raise ValueError(
        f"Unsupported justification_style: {justification_style}. "
        "Allowed values are: short, default"
    )


def get_justification_example(justification_style: str) -> str:
    """
    Return JSON example justification text based on selected style.
    """
    if justification_style == "short":
        return (
            "Line 1 concise professional reason.\\n"
            "Line 2 concise evidence-based conclusion."
        )

    if justification_style == "default":
        return (
            "Line 1 concise finding summary.\\n"
            "Line 2 evidence-based observation.\\n"
            "Line 3 impact or non-impact explanation.\\n"
            "Line 4 final remediation or false-positive conclusion."
        )

    raise ValueError(
        f"Unsupported justification_style: {justification_style}. "
        "Allowed values are: short, default"
    )


def build_ai_prompt(
    packet: dict,
    justification_style: str = "short",
) -> str:
    """
    Build AI prompt for one grouped DAST issue.
    """
    issue_name = packet.get("issue_name", "")
    severity = packet.get("severity", "")
    occurrences = packet.get("occurrences", 0)
    evidence_text = packet.get("evidence_text", "")
    category_context = packet.get("category_context", "")

    known_context = packet.get("known_context", {})
    known_status = known_context.get("known_status", "")
    known_remarks = known_context.get("known_remarks", "")
    known_solution = known_context.get("known_solution", "")

    justification_rule = get_justification_rule(justification_style)
    justification_example = get_justification_example(justification_style)

    prompt = f"""
You are a security triage assistant.

Analyze the following Fortify WebInspect DAST finding and classify it.

Return ONLY valid JSON in this exact format:

{{
  "status": "False Positive",
  "justification": "{justification_example}",
  "solution": "Not Applicable"
}}

The "status" value must be exactly one of:
- Fixed
- Open
- False Positive

Decision rules:
- Use "False Positive" if the scanner evidence does not prove an exploitable vulnerability or the behavior is expected/controlled.
- Use "Open" if the evidence supports a real vulnerability that needs remediation.
- Use "Fixed" if the evidence clearly shows the issue has already been remediated.
- Use category_context only as general vulnerability background and remediation guidance.
- Use evidence_text as the primary source for validating whether the final decision is reasonable.
- Do not mark a finding Open only because category_context describes a theoretical risk.

Known context rules:
- If known_context is provided, treat it as trusted application/team assessment.
- If known_status is provided and does not clearly conflict with evidence_text, prefer known_status.
- Use known_context as the primary source for the final status, justification, and solution.
- Preserve the technical meaning and project-specific facts from known_context.
- Only improve grammar, clarity, and professional tone.
- Do not replace known_context with generic AI statements.
- Do not copy known_context blindly; rewrite it into polished human-style Application Team Remarks.
- Do not generate unrelated assumptions.
- Do not contradict known_context unless evidence_text clearly proves otherwise.
- Avoid phrases like "application team has assessed", "controlled behavior", "current application context", or "the application is designed" unless those exact ideas are explicitly supported by known_context or evidence_text.
- Preserve concrete facts such as SHA-256 usage, AEM frontend resources, AEM model exports, static JavaScript resources, Angular generated bundle, POST-only handling, authentication rejection, and absence of stack traces or sensitive backend data.
- If known_solution is provided, use it for the solution field unless it clearly conflicts with evidence_text.
- If known_context is empty, decide only from evidence_text and category_context.

Status-specific writing rules:
- If status is "False Positive", explain why the scanner evidence does not prove exploitable impact.
- If status is "Open", explain why the evidence supports a real vulnerability and requires remediation.
- If status is "Fixed", explain why the evidence indicates the issue is already remediated.
{justification_rule}
- Do not include markdown.
- Do not include code fences.
- Do not include any text outside JSON.

Finding:
Issue Name: {issue_name}
Severity: {severity}
Occurrences: {occurrences}

Known Application/Team Context:
Known Status: {known_status}
Known Remarks:
{known_remarks}

Known Solution:
{known_solution}

Category Context:
{category_context}

Evidence:
{evidence_text}
""".strip()

    return prompt


def save_ai_prompt(issue_dir: Path, prompt: str) -> Path:
    """
    Save AI prompt text inside issue folder.
    """
    prompt_file = issue_dir / "ai_prompt.txt"
    prompt_file.write_text(prompt, encoding="utf-8")
    return prompt_file


def run_ai_prompt_generation(
    output_dir: str,
    justification_style: str = "short",
) -> Path:
    """
    Phase 6 runner.

    Input:
        output/dast/<pdf_name>/issues/*/issue_packet.json

    Output:
        output/dast/<pdf_name>/issues/*/ai_prompt.txt
    """
    output_path = Path(output_dir)
    issues_dir = output_path / "issues"

    if not issues_dir.exists():
        raise FileNotFoundError(f"Issues folder not found: {issues_dir}")

    generated_count = 0

    for issue_dir in sorted(issues_dir.iterdir()):
        if not issue_dir.is_dir():
            continue

        packet_file = issue_dir / "issue_packet.json"

        if not packet_file.exists():
            continue

        packet = read_json_file(packet_file)

        prompt = build_ai_prompt(
            packet=packet,
            justification_style=justification_style,
        )

        save_ai_prompt(issue_dir, prompt)

        generated_count += 1

    if generated_count == 0:
        raise ValueError(f"No issue_packet.json files found under: {issues_dir}")

    return issues_dir