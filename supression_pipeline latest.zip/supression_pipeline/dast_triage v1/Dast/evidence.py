from __future__ import annotations

import json
import re
from pathlib import Path

from Dast.known_notes import load_known_notes, get_known_note_for_issue


MAX_EVIDENCE_CHARS = 6000


def read_json_file(file_path: Path) -> list[dict]:
    """
    Read JSON list from file.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"JSON file not found: {file_path}")

    return json.loads(file_path.read_text(encoding="utf-8"))


def read_text_file(file_path: Path) -> str:
    """
    Read text file.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"Text file not found: {file_path}")

    return file_path.read_text(encoding="utf-8", errors="ignore")


def safe_folder_name(value: str) -> str:
    """
    Convert issue name into safe folder name.
    """
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value)
    return value.strip("_")


def find_issue_evidence(
    details_text: str,
    issue_name: str,
    severity: str,
    max_chars: int = MAX_EVIDENCE_CHARS,
) -> str:
    """
    Extract sample evidence for a grouped issue from Security Issues Details.

    First version:
    - Find first occurrence of issue name.
    - Cut until next issue heading if possible.
    - Limit evidence size.
    """
    start_index = details_text.lower().find(issue_name.lower())

    if start_index == -1:
        return ""

    sliced_text = details_text[start_index:]

    next_heading_pattern = re.compile(
        r"\n(?=[A-Z][A-Za-z0-9 :/()_-]+\s+(Critical|High|Medium|Low|Info|Informational)\s*\n)",
        flags=re.IGNORECASE,
    )

    matches = list(next_heading_pattern.finditer(sliced_text))

    if len(matches) > 1:
        evidence = sliced_text[: matches[1].start()]
    else:
        evidence = sliced_text[:max_chars]

    return evidence[:max_chars].strip()


def find_category_context(
    category_text: str,
    issue_name: str,
    all_issue_names: list[str],
    max_chars: int = 5000,
) -> str:
    """
    Extract Fortify category explanation/recommendation for the given issue.
    """
    if not category_text or not issue_name:
        return ""

    lower_text = category_text.lower()
    lower_issue = issue_name.lower()

    start_index = lower_text.find(lower_issue)

    if start_index == -1:
        return ""

    next_indexes: list[int] = []

    for other_issue in all_issue_names:
        if not other_issue:
            continue

        lower_other = other_issue.lower()

        if lower_other == lower_issue:
            continue

        found_index = lower_text.find(
            lower_other,
            start_index + len(lower_issue),
        )

        if found_index != -1:
            next_indexes.append(found_index)

    if next_indexes:
        end_index = min(next_indexes)
        context = category_text[start_index:end_index]
    else:
        context = category_text[start_index:start_index + max_chars]

    return context[:max_chars].strip()


def build_issue_packet(
    issue: dict,
    evidence_text: str,
    category_context: str,
    known_context: dict,
) -> dict:
    """
    Build AI-ready issue packet.
    """
    return {
        "sr_no": issue.get("sr_no"),
        "issue_name": issue.get("issue_name", ""),
        "severity": issue.get("severity", ""),
        "occurrences": issue.get("occurrences", 0),
        "evidence_text": evidence_text,
        "category_context": category_context,
        "known_context": {
            "known_status": known_context.get("known_status", ""),
            "known_remarks": known_context.get("known_remarks", ""),
            "known_solution": known_context.get("known_solution", ""),
        },
        "expected_ai_output": {
            "status": "Fixed/Open/False Positive",
            "justification": "",
            "solution": "",
        },
    }


def save_issue_packet(issue_dir: Path, packet: dict) -> None:
    """
    Save issue packet, evidence text, category context, and known context.
    """
    issue_dir.mkdir(parents=True, exist_ok=True)

    packet_file = issue_dir / "issue_packet.json"
    evidence_file = issue_dir / "evidence.txt"
    category_file = issue_dir / "category_context.txt"
    known_context_file = issue_dir / "known_context.txt"

    packet_file.write_text(
        json.dumps(packet, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    evidence_file.write_text(
        packet.get("evidence_text", ""),
        encoding="utf-8",
    )

    category_file.write_text(
        packet.get("category_context", ""),
        encoding="utf-8",
    )

    known_context = packet.get("known_context", {})

    known_context_text = (
        f"Known Status: {known_context.get('known_status', '')}\n"
        f"Known Remarks:\n{known_context.get('known_remarks', '')}\n\n"
        f"Known Solution:\n{known_context.get('known_solution', '')}"
    )

    known_context_file.write_text(
        known_context_text.strip(),
        encoding="utf-8",
    )


def run_evidence_extraction(output_dir: str) -> Path:
    """
    Phase 5 runner:
        grouped_issues.json
        security_issues_details.txt
        category_descriptions.txt
        known_notes.txt / knowledge/dast_known_notes.txt
        -> issues/issue_xxxx/issue_packet.json
    """
    output_path = Path(output_dir)

    grouped_file = output_path / "grouped_issues.json"
    details_file = output_path / "security_issues_details.txt"
    category_file = output_path / "category_descriptions.txt"
    issues_dir = output_path / "issues"

    grouped_issues = read_json_file(grouped_file)
    details_text = read_text_file(details_file)

    if category_file.exists():
        category_text = read_text_file(category_file)
    else:
        category_text = ""

    known_notes = load_known_notes(output_dir)

    all_issue_names = [
        issue.get("issue_name", "")
        for issue in grouped_issues
        if issue.get("issue_name")
    ]

    for issue in grouped_issues:
        sr_no = int(issue.get("sr_no", 0))
        issue_name = issue.get("issue_name", "")
        severity = issue.get("severity", "")

        folder_name = safe_folder_name(issue_name)
        issue_dir = issues_dir / f"issue_{sr_no:04d}_{folder_name}"

        evidence_text = find_issue_evidence(
            details_text=details_text,
            issue_name=issue_name,
            severity=severity,
        )

        category_context = find_category_context(
            category_text=category_text,
            issue_name=issue_name,
            all_issue_names=all_issue_names,
        )

        known_context = get_known_note_for_issue(
            issue_name=issue_name,
            known_notes=known_notes,
        )

        packet = build_issue_packet(
            issue=issue,
            evidence_text=evidence_text,
            category_context=category_context,
            known_context=known_context,
        )

        save_issue_packet(issue_dir, packet)

    return issues_dir