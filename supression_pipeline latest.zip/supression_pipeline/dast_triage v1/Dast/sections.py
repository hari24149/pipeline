from __future__ import annotations

from pathlib import Path


def find_nth(text: str, marker: str, occurrence: int = 2) -> int:
    """
    Find nth occurrence of a marker.

    In Fortify reports, section names appear once in Table of Contents
    and again as actual section headings. So usually we need occurrence=2.
    """
    start = -1

    for _ in range(occurrence):
        start = text.find(marker, start + 1)

        if start == -1:
            return -1

    return start


def find_section_start(text: str, marker: str) -> int:
    """
    Find actual section start.

    Prefer second occurrence because first occurrence is usually Table of Contents.
    If second occurrence is not found, fallback to first occurrence.
    """
    second = find_nth(text, marker, 2)

    if second != -1:
        return second

    return text.find(marker)


def extract_between_sections(
    text: str,
    start_marker: str,
    end_marker: str | None = None,
) -> str:
    """
    Extract actual report section text between section headings.
    """
    start_index = find_section_start(text, start_marker)

    if start_index == -1:
        return ""

    start_index = start_index + len(start_marker)

    if end_marker:
        end_index = find_section_start(text, end_marker)

        if end_index == -1 or end_index <= start_index:
            return text[start_index:].strip()

        return text[start_index:end_index].strip()

    return text[start_index:].strip()


def extract_report_sections(clean_text: str) -> dict[str, str]:
    """
    Extract useful DAST report sections from cleaned text.
    """
    security_issues_summary = extract_between_sections(
        clean_text,
        "Security Issues Summary",
        "Security Issues Details",
    )

    security_issues_details = extract_between_sections(
        clean_text,
        "Security Issues Details",
        "Category Descriptions",
    )

    category_descriptions = extract_between_sections(
        clean_text,
        "Category Descriptions",
        None,
    )

    return {
        "security_issues_summary": security_issues_summary,
        "security_issues_details": security_issues_details,
        "category_descriptions": category_descriptions,
    }


def save_text_file(text: str, output_file: Path) -> Path:
    """
    Save text content into a file.
    """
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(text, encoding="utf-8")
    return output_file


def save_report_sections(
    sections: dict[str, str],
    output_dir: str = "output",
) -> dict[str, Path]:
    """
    Save extracted DAST report sections into output folder.
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    saved_files = {
        "security_issues_summary": save_text_file(
            sections.get("security_issues_summary", ""),
            output_path / "security_issues_summary.txt",
        ),
        "security_issues_details": save_text_file(
            sections.get("security_issues_details", ""),
            output_path / "security_issues_details.txt",
        ),
        "category_descriptions": save_text_file(
            sections.get("category_descriptions", ""),
            output_path / "category_descriptions.txt",
        ),
    }

    return saved_files