from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Callable

import requests


BRIDGE_URL = "http://127.0.0.1:3210/ai/chat"
BRIDGE_TOKEN_ENV = "COPILOT_BRIDGE_TOKEN"
BRIDGE_HINTS = {
    401: " (unauthorized: check COPILOT_BRIDGE_TOKEN)",
    403: " (no access: run Authorize Copilot Access in the bridge Control Center)",
    429: " (rate limit of 60/min exceeded: wait and retry)",
    503: " (model unavailable: check Copilot sign-in)",
}
REQUEST_DELAY_SECONDS = 1.1
PROGRESS_BAR_WIDTH = 40
PROGRESS_FILLED = "█"
PROGRESS_EMPTY = " "
SPINNER_FRAMES = ("|", "/", "-", "\\")
ANSI_RESET = "\033[0m"
ANSI_CYAN = "\033[96m"
ANSI_GREEN = "\033[92m"
ANSI_YELLOW = "\033[93m"
ANSI_DIM = "\033[2m"


def format_progress(current: int, total: int) -> str:
    """Format an ASCII-only progress bar for redirected terminal output."""
    safe_total = max(total, 1)
    completed = min(
        PROGRESS_BAR_WIDTH,
        max(1 if current else 0, current * PROGRESS_BAR_WIDTH // safe_total),
    )
    bar = "/" * completed + "-" * (PROGRESS_BAR_WIDTH - completed)
    percentage = min(100, current * 100 // safe_total)
    return f"[{bar}] {percentage:3d}% ({current}/{total}) AI decisions"


def render_progress(
    current: int,
    total: int,
    color_enabled: bool | None = None,
) -> str:
    """Render an ANSI-colored PowerShell progress line when supported."""
    if color_enabled is None:
        color_enabled = sys.stdout.isatty() and not os.getenv("NO_COLOR")
    if not color_enabled:
        return format_progress(current, total)

    safe_total = max(total, 1)
    completed = min(
        PROGRESS_BAR_WIDTH,
        max(1 if current else 0, current * PROGRESS_BAR_WIDTH // safe_total),
    )
    percentage = min(100, current * 100 // safe_total)
    filled = PROGRESS_FILLED * completed
    remaining = PROGRESS_EMPTY * (PROGRESS_BAR_WIDTH - completed)
    spinner = SPINNER_FRAMES[current % len(SPINNER_FRAMES)]
    return (
        f"{ANSI_CYAN}[{ANSI_GREEN}{filled}{ANSI_DIM}{remaining}{ANSI_CYAN}]"
        f" {ANSI_YELLOW}{percentage:3d}%{ANSI_RESET}"
        f" {ANSI_DIM}({current}/{total}){ANSI_RESET}"
        f" {ANSI_CYAN}{spinner} AI decisions{ANSI_RESET}"
    )


def get_bridge_token() -> str:
    """
    Read bridge token from environment variable.

    PowerShell:
        $env:COPILOT_BRIDGE_TOKEN="your-token"
    """
    token = os.getenv(BRIDGE_TOKEN_ENV, "").strip()

    if not token:
        raise ValueError(
            f"Missing bridge token. Set environment variable {BRIDGE_TOKEN_ENV}."
        )

    return token


def read_text_file(file_path: Path) -> str:
    """
    Read text file content.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    return file_path.read_text(encoding="utf-8", errors="ignore")


def write_json_file(file_path: Path, data: Any) -> Path:
    """
    Save JSON file.
    """
    file_path.parent.mkdir(parents=True, exist_ok=True)

    file_path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    return file_path


def call_bridge_ai(prompt: str, token: str) -> dict:
    """
    Call local Copilot bridge AI endpoint.
    """
    headers = {
        "Content-Type": "application/json",
        "x-bridge-token": token,
    }

    payload = {
        "prompt": prompt,
    }

    response = requests.post(
        BRIDGE_URL,
        headers=headers,
        json=payload,
        timeout=180,
    )

    try:
        response_json = response.json()
    except Exception:
        response_json = {
            "ok": False,
            "status": response.status_code,
            "content": response.text,
        }

    if response.status_code != 200:
        hint = BRIDGE_HINTS.get(response.status_code, "")
        raise RuntimeError(
            f"Bridge API failed. HTTP {response.status_code}{hint}: {response_json}"
        )

    return response_json


def extract_json_from_text(text: str) -> dict:
    """
    Extract decision JSON from AI content.

    Expected AI content:
        {
          "status": "False Positive",
          "justification": "..."
        }
    """
    if not text:
        raise ValueError("AI response content is empty.")

    cleaned = text.strip()

    # Remove markdown code fences if AI accidentally returns them.
    cleaned = re.sub(r"^```(?:json)?", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"```$", "", cleaned).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Fallback: extract first JSON object from text.
    match = re.search(r"\{[\s\S]*\}", cleaned)

    if not match:
        raise ValueError(f"No JSON object found in AI response: {text[:500]}")

    return json.loads(match.group(0))


def validate_ai_decision(decision: dict) -> dict:
    """
    Validate and normalize AI decision.
    """
    allowed_statuses = {"Fixed", "Open", "False Positive"}

    raw_status = str(decision.get("status", "")).strip()
    justification = str(decision.get("justification", "")).strip()
    solution = str(decision.get("solution", "")).strip()

    status_lookup = {
        "fixed": "Fixed",
        "open": "Open",
        "false positive": "False Positive",
        "false-positive": "False Positive",
        "fp": "False Positive",
    }

    status = status_lookup.get(raw_status.lower(), raw_status)

    if status not in allowed_statuses:
        raise ValueError(
            f"Invalid AI status: {raw_status}. Allowed: {sorted(allowed_statuses)}"
        )

    if not justification:
        raise ValueError("AI justification is empty.")

    if not solution:
        solution = "Not Applicable"

    return {
        "status": status,
        "justification": justification,
        "solution": solution,
    }


def process_issue_prompt(issue_dir: Path, token: str) -> None:
    """
    Send one issue ai_prompt.txt to bridge and save response files.
    """
    prompt_file = issue_dir / "ai_prompt.txt"

    if not prompt_file.exists():
        return

    raw_response_file = issue_dir / "ai_response_raw.json"
    decision_file = issue_dir / "ai_decision.json"

    prompt = read_text_file(prompt_file)

    raw_response = call_bridge_ai(prompt, token)
    write_json_file(raw_response_file, raw_response)

    content = raw_response.get("content", "")
    decision = extract_json_from_text(content)
    validated_decision = validate_ai_decision(decision)

    write_json_file(decision_file, validated_decision)


def run_ai_decision(
    output_dir: str,
    progress_callback: Callable[[int, int], None] | None = None,
    should_stop: Callable[[], bool] | None = None,
    skip_existing: bool = False,
) -> Path:
    """
    Phase 7 runner:
        issues/*/ai_prompt.txt
        -> issues/*/ai_response_raw.json
        -> issues/*/ai_decision.json

    should_stop aborts between issues; skip_existing resumes a partial run.
    """
    output_path = Path(output_dir)
    issues_dir = output_path / "issues"

    if not issues_dir.exists():
        raise FileNotFoundError(f"Issues folder not found: {issues_dir}")

    token = get_bridge_token()

    issue_dirs = [
        issue_dir
        for issue_dir in sorted(issues_dir.iterdir())
        if issue_dir.is_dir() and (issue_dir / "ai_prompt.txt").exists()
    ]

    if not issue_dirs:
        raise ValueError(f"No ai_prompt.txt files found under: {issues_dir}")

    total = len(issue_dirs)
    if not progress_callback:
        print(f"[AI] Sending {total} decision request(s) to the local Copilot bridge.")
        print(render_progress(0, total), end="\r", flush=True)

    for processed_count, issue_dir in enumerate(issue_dirs, start=1):
        if should_stop and should_stop():
            break

        reused = skip_existing and (issue_dir / "ai_decision.json").exists()
        if not reused:
            process_issue_prompt(issue_dir, token)
        if progress_callback:
            progress_callback(processed_count, total)
        else:
            print(render_progress(processed_count, total), end="\r", flush=True)

        # Bridge rate limit is 60/min, so keep small delay.
        if not reused and processed_count < total:
            time.sleep(REQUEST_DELAY_SECONDS)

    if not progress_callback:
        print()

    return issues_dir