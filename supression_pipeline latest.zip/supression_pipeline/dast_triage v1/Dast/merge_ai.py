from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


def read_json_file(file_path: Path) -> Any:
    """
    Read JSON file.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"JSON file not found: {file_path}")

    return json.loads(file_path.read_text(encoding="utf-8"))


def write_json_file(file_path: Path, data: Any) -> Path:
    """
    Write JSON file.
    """
    file_path.parent.mkdir(parents=True, exist_ok=True)

    file_path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    return file_path


def extract_sr_no_from_issue_folder(issue_dir: Path) -> int | None:
    """
    Extract sr_no from folder name.

    Example:
        issue_0001_often_misused_http_method_override -> 1
    """
    match = re.match(r"issue_(\d+)_", issue_dir.name)

    if not match:
        return None

    return int(match.group(1))


def load_ai_decisions_by_sr_no(issues_dir: Path) -> dict[int, dict]:
    """
    Load AI decisions from each issue folder and map by sr_no.
    """
    decisions: dict[int, dict] = {}

    if not issues_dir.exists():
        raise FileNotFoundError(f"Issues folder not found: {issues_dir}")

    for issue_dir in sorted(issues_dir.iterdir()):
        if not issue_dir.is_dir():
            continue

        sr_no = extract_sr_no_from_issue_folder(issue_dir)

        if sr_no is None:
            continue

        decision_file = issue_dir / "ai_decision.json"

        if not decision_file.exists():
            continue

        decision = read_json_file(decision_file)

        decisions[sr_no] = {
            "status": decision.get("status", ""),
            "justification": decision.get("justification", ""),
            "solution": decision.get("solution", ""),
        }

    return decisions


def merge_ai_decisions(output_dir: str) -> Path:
    """
    Phase 8 runner:
        grouped_issues.json + issues/*/ai_decision.json
        -> grouped_issues_with_ai.json
    """
    output_path = Path(output_dir)

    grouped_file = output_path / "grouped_issues.json"
    issues_dir = output_path / "issues"
    merged_file = output_path / "grouped_issues_with_ai.json"

    grouped_issues = read_json_file(grouped_file)
    decisions = load_ai_decisions_by_sr_no(issues_dir)

    for issue in grouped_issues:
        sr_no = int(issue.get("sr_no", 0))

        decision = decisions.get(sr_no, {})

        issue["status"] = decision.get("status", "")
        issue["justification"] = decision.get("justification", "")
        issue["solution"] = decision.get("solution", "")

    return write_json_file(merged_file, grouped_issues)