from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


def read_json_file(file_path: Path) -> Any:
    """
    Read JSON file.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"JSON file not found: {file_path}")

    return json.loads(file_path.read_text(encoding="utf-8"))


def get_report_name(output_dir: Path) -> str:
    """
    Use output folder name as report/application identifier.

    Example:
        output/dast/A0897 -> A0897
    """
    return output_dir.name


def apply_excel_formatting(ws) -> None:
    """
    Apply basic formatting to Excel sheet.
    """
    header_fill = PatternFill(
        fill_type="solid",
        fgColor="D9EAF7",
    )

    thin_border = Border(
        left=Side(style="thin", color="999999"),
        right=Side(style="thin", color="999999"),
        top=Side(style="thin", color="999999"),
        bottom=Side(style="thin", color="999999"),
    )

    # Header formatting
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )
        cell.border = thin_border

    # Body formatting
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True,
            )
            cell.border = thin_border

    # Column widths
    widths = {
        "A": 10,
        "B": 45,
        "C": 15,
        "D": 28,
        "E": 14,
        "F": 85,
        "G": 55,
    }

    for column, width in widths.items():
        ws.column_dimensions[column].width = width

    # Row heights
    ws.row_dimensions[1].height = 35

    for row_number in range(2, ws.max_row + 1):
        ws.row_dimensions[row_number].height = 75

    # Freeze header
    ws.freeze_panes = "A2"

    # Auto filter
    ws.auto_filter.ref = ws.dimensions


def export_dast_excel(output_dir: str) -> Path:
    """
    Phase 9 runner:
        grouped_issues_with_ai.json -> <application>_DAST_SuppressionReport.xlsx
    """
    output_path = Path(output_dir)

    input_file = output_path / "grouped_issues_with_ai.json"

    if not input_file.exists():
        raise FileNotFoundError(
            f"AI merged grouped issues file not found: {input_file}"
        )

    issues = read_json_file(input_file)
    report_name = get_report_name(output_path)

    excel_file = output_path / f"{report_name}_DAST_SuppressionReport.xlsx"

    wb = Workbook()
    ws = wb.active
    ws.title = "DAST Summary"

    headers = [
        "Sr. No.",
        f"Vulnerability {report_name} DAST",
        "Severity",
        "Status (Fixed/Open/False Positive)",
        "Occurences",
        "Application Team Remarks",
        "Solution Applied to Fix Vulnerability (Source Code/Configuration)",
    ]

    ws.append(headers)

    for issue in issues:
        ws.append(
            [
                issue.get("sr_no", ""),
                issue.get("issue_name", ""),
                issue.get("severity", ""),
                issue.get("status", ""),
                issue.get("occurrences", ""),
                issue.get("justification", ""),
                issue.get("solution", ""),
            ]
        )

    apply_excel_formatting(ws)

    wb.save(excel_file)

    return excel_file