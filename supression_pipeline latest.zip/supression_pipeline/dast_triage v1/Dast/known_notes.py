from __future__ import annotations

import re
from pathlib import Path


def normalize_issue_name(value: str) -> str:
    """
    Normalize issue name for matching.
    """
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def normalize_status(status: str) -> str:
    """
    Normalize known status.

    Supported:
        fp -> False Positive
        false positive -> False Positive
        open -> Open
        fixed -> Fixed
    """
    value = status.strip().lower()

    if value in {"fp", "false positive", "false-positive"}:
        return "False Positive"

    if value == "open":
        return "Open"

    if value == "fixed":
        return "Fixed"

    return status.strip()


def find_known_notes_file(output_dir: str) -> Path | None:
    """
    Locate known notes file.

    Priority:
    1. output/dast/<pdf_name>/known_notes.txt
    2. knowledge/dast_known_notes.txt
    """
    output_path = Path(output_dir)

    report_specific_file = output_path / "known_notes.txt"
    if report_specific_file.exists():
        return report_specific_file

    project_file = Path("knowledge") / "dast_known_notes.txt"
    if project_file.exists():
        return project_file

    return None


def parse_known_notes(notes_text: str) -> dict[str, dict]:
    """
    Parse known notes text.

    Format:

    ### Issue Name
    status: False Positive
    remarks:
    line 1
    line 2
    solution:
    Not Applicable
    """
    notes: dict[str, dict] = {}

    blocks = re.split(r"(?m)^###\s+", notes_text)

    for block in blocks:
        block = block.strip()

        if not block:
            continue

        lines = block.splitlines()
        issue_name = lines[0].strip()

        if not issue_name:
            continue

        body = "\n".join(lines[1:]).strip()

        status = ""
        remarks = ""
        solution = ""

        status_match = re.search(
            r"(?im)^status\s*:\s*(.+)$",
            body,
        )

        if status_match:
            status = status_match.group(1).strip()

        remarks_match = re.search(
            r"(?is)^remarks\s*:\s*(.*?)(?:\nsolution\s*:|\Z)",
            body,
        )

        if remarks_match:
            remarks = remarks_match.group(1).strip()

        solution_match = re.search(
            r"(?is)^solution\s*:\s*(.*)$",
            body,
        )

        if solution_match:
            solution = solution_match.group(1).strip()

        notes[normalize_issue_name(issue_name)] = {
            "issue_name": issue_name,
            "known_status": normalize_status(status),
            "known_remarks": remarks,
            "known_solution": solution,
        }

    return notes


def load_known_notes(output_dir: str) -> dict[str, dict]:
    """
    Load known notes if file exists.
    """
    notes_file = find_known_notes_file(output_dir)

    if not notes_file:
        return {}

    notes_text = notes_file.read_text(encoding="utf-8", errors="ignore")
    return parse_known_notes(notes_text)


def get_known_note_for_issue(
    issue_name: str,
    known_notes: dict[str, dict],
) -> dict:
    """
    Get known note for issue.

    Matching:
    - exact normalized issue name
    - fallback contains match
    """
    normalized = normalize_issue_name(issue_name)

    if normalized in known_notes:
        return known_notes[normalized]

    for known_key, known_value in known_notes.items():
        if normalized in known_key or known_key in normalized:
            return known_value

    return {
        "known_status": "",
        "known_remarks": "",
        "known_solution": "",
    }