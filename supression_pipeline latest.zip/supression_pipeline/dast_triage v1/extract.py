from __future__ import annotations

from pathlib import Path

import pdfplumber


def extract_pdf_text(pdf_path: str) -> str:
    """
    Phase 1:
    Extract raw text from the DAST PDF.

    This module does not clean, parse, group, or analyze data.
    It only reads the PDF and returns raw text.
    """
    path = Path(pdf_path)

    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    raw_pages: list[str] = []

    with pdfplumber.open(str(path)) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            page_text = page.extract_text() or ""

            raw_pages.append(
                f"\n\n--- PAGE {page_number} ---\n\n{page_text}"
            )

    return "\n".join(raw_pages)


def save_raw_text(raw_text: str, output_dir: str = "output") -> Path:
    """
    Save extracted raw text to output/raw_text.txt.
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    raw_file = output_path / "raw_text.txt"
    raw_file.write_text(raw_text, encoding="utf-8")

    return raw_file