from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

from pipeline import Hooks, run_pipeline


DEFAULT_BASE_OUTPUT_DIR = Path("output")
SCAN_TYPE = "dast"
PIPELINE_BAR_WIDTH = 32
SPINNER_FRAMES = ("|", "/", "-", "\\")
ANSI_RESET = "\033[0m"
ANSI_WHITE = "\033[97m"
ANSI_YELLOW = "\033[93m"
ANSI_DIM = "\033[2m"

USAGE_GUIDE = r"""
DAST Triage - PowerShell Usage Guide

Install dependencies:
    python -m pip install -r requirements.txt

Run a DAST report with short Excel-ready remarks:
    python main.py --pdf "C:\reports\application_dast.pdf"

Run with detailed remarks:
    python main.py --pdf "C:\reports\application_dast.pdf" --justification-style default

Configure the local Copilot bridge token in the current PowerShell session:
    $env:COPILOT_BRIDGE_TOKEN="YOUR_TOKEN_HERE"

Verify the local bridge:
    Invoke-WebRequest http://127.0.0.1:3210/health

Outputs:
    output\dast\<report-name>\
    <report-name>_DAST_SuppressionReport.xlsx

Commands:
    python main.py --help          Show argument reference
    python main.py --help-guide    Show this detailed guide

Example:
    python main.py --pdf "C:\Users\2785364\Downloads\A0897.pdf"
""".strip()


def render_pipeline_progress(
    step: int,
    step_total: int,
    progress: float,
    label: str,
    color_enabled: bool | None = None,
    elapsed_seconds: float | None = None,
) -> str:
    """Render a DAST step with an optional elapsed and remaining-time estimate."""
    if color_enabled is None:
        color_enabled = sys.stdout.isatty() and not os.getenv("NO_COLOR")
    bounded_progress = min(max(progress, 0.0), 1.0)
    completed = int(bounded_progress * PIPELINE_BAR_WIDTH)
    percentage = int(bounded_progress * 100)
    spinner = SPINNER_FRAMES[completed % len(SPINNER_FRAMES)]
    timing = ""
    if elapsed_seconds is not None:
        elapsed = int(elapsed_seconds)
        remaining = int(elapsed_seconds * (1 - bounded_progress) / bounded_progress) if bounded_progress else 0
        timing = f" | elapsed {elapsed // 60:02d}:{elapsed % 60:02d} | eta {remaining // 60:02d}:{remaining % 60:02d}"
    if not color_enabled:
        bar = "/" * completed + "-" * (PIPELINE_BAR_WIDTH - completed)
        return f"[{bar}] {percentage:3d}% Step {step}/{step_total} {spinner} {label}{timing}"

    return (
        f"{ANSI_WHITE}[{'█' * completed}{' ' * (PIPELINE_BAR_WIDTH - completed)}] "
        f"{ANSI_YELLOW}{percentage:3d}%{ANSI_RESET} {ANSI_DIM}Step {step}/{step_total}{ANSI_RESET} "
        f"{ANSI_WHITE}{spinner} {label}{ANSI_RESET}{ANSI_DIM}{timing}{ANSI_RESET}"
    )


def print_step(step: int, total: int, progress: float, label: str) -> None:
    print(render_pipeline_progress(step, total, progress, label))


class TerminalHooks(Hooks):
    """Prints pipeline events in the classic PowerShell format."""

    def __init__(self) -> None:
        self._ai_started_at = 0.0
        self._inline = False

    def _break_inline(self) -> None:
        if self._inline:
            print()
            self._inline = False

    def log(self, line: str, level: str = "info") -> None:
        self._break_inline()
        print(line)

    def stage_start(self, index: int, total: int, key: str, label: str) -> None:
        self._ai_started_at = time.monotonic()
        print(f"[STEP {index}] {label}...")

    def stage_end(self, index: int, total: int, key: str, label: str, status: str) -> None:
        self._break_inline()
        if status == "success":
            print_step(index, total, 1, label)

    def ai_progress(self, done: int, total: int) -> None:
        self._inline = True
        print(
            render_pipeline_progress(
                7,
                9,
                done / total,
                f"AI decisions ({done}/{total})",
                elapsed_seconds=time.monotonic() - self._ai_started_at,
            ),
            end="\r",
            flush=True,
        )


def build_output_dir(pdf_path: str) -> Path:
    """
    Build separate output folder for DAST reports.

    Example:
        output/dast/A0897
    """
    pdf_name = Path(pdf_path).stem
    return DEFAULT_BASE_OUTPUT_DIR / SCAN_TYPE / pdf_name


def parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments.

    Current usage:
        python main.py --pdf "A0897.pdf"

    Optional:
        python main.py --pdf "A0897.pdf" --justification-style short
        python main.py --pdf "A0897.pdf" --justification-style default
    """
    parser = argparse.ArgumentParser(
        description="DAST Triage Console - Extract, clean, split, analyze, and merge DAST PDF report"
    )

    parser.add_argument(
        "--pdf",
        default="",
        help="Path to Fortify WebInspect DAST PDF report",
    )

    parser.add_argument(
        "--help-guide",
        "--guide",
        action="store_true",
        help="Show a detailed PowerShell usage guide",
    )

    parser.add_argument(
        "--justification-style",
        choices=["short", "default"],
        default="short",
        help=(
            "AI justification style: "
            "short = 2-line Excel-ready remarks, "
            "default = detailed explanation"
        ),
    )

    parser.add_argument(
        "--start-stage",
        type=int,
        default=1,
        help="Run from this stage number (1-9)",
    )

    parser.add_argument(
        "--end-stage",
        type=int,
        default=9,
        help="Stop after this stage number (1-9)",
    )

    parser.add_argument(
        "--resume-ai",
        action="store_true",
        help="When running the AI stage, skip issues that already have ai_decision.json",
    )

    parser.add_argument(
        "--skip-ai",
        action="store_true",
        help="Skip AI bridge calls and continue with remaining selected stages",
    )

    args = parser.parse_args()
    if not args.pdf and not args.help_guide:
        parser.error("the following arguments are required: --pdf")
    return args


def validate_pdf(pdf_path: str) -> Path:
    """
    Validate input PDF path.
    """
    pdf = Path(pdf_path)

    if not pdf.exists():
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    if not pdf.is_file():
        raise ValueError(f"PDF path is not a file: {pdf_path}")

    if pdf.suffix.lower() != ".pdf":
        raise ValueError(f"Input file must be a PDF: {pdf_path}")

    return pdf


def run(pdf_path: str, justification_style: str, start_stage: int, end_stage: int, resume_ai: bool, skip_ai: bool) -> None:
    """
    Current flow:
        PDF
          -> output/dast/<pdf_name>/raw_text.txt
          -> output/dast/<pdf_name>/clean_text.txt
          -> output/dast/<pdf_name>/security_issues_summary.txt
          -> output/dast/<pdf_name>/security_issues_details.txt
          -> output/dast/<pdf_name>/category_descriptions.txt
          -> output/dast/<pdf_name>/grouped_issues.json
          -> output/dast/<pdf_name>/issues/*/issue_packet.json
          -> output/dast/<pdf_name>/issues/*/ai_prompt.txt
          -> output/dast/<pdf_name>/issues/*/ai_decision.json
          -> output/dast/<pdf_name>/grouped_issues_with_ai.json
    """
    print("[START] DAST PDF processing started")

    validate_pdf(pdf_path)

    output_dir = build_output_dir(pdf_path)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Output directory: {output_dir}")
    print(f"[INFO] Justification style: {justification_style}")

    run_pipeline(
        pdf_path,
        output_dir,
        justification_style,
        TerminalHooks(),
        start_stage=start_stage,
        end_stage=end_stage,
        resume_ai=resume_ai,
        skip_ai=skip_ai,
    )

    print("[COMPLETE] DAST PDF processing completed")


def main() -> None:
    """
    Main console entry point.
    """
    args = parse_args()

    if args.help_guide:
        print(USAGE_GUIDE)
        return

    try:
        if args.start_stage < 1 or args.end_stage > 9 or args.start_stage > args.end_stage:
            raise ValueError("Stage range must be between 1 and 9, and start-stage <= end-stage")
        run(args.pdf, args.justification_style, args.start_stage, args.end_stage, args.resume_ai, args.skip_ai)
    except Exception as exc:
        print("[ERROR] DAST processing failed", file=sys.stderr)
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()