from __future__ import annotations

import json
from pathlib import Path


def merge_ai_decisions(output_dir: Path) -> Path:
    grouped_file = output_dir / "grouped_issues.json"
    issues = json.loads(grouped_file.read_text(encoding="utf-8"))
    for issue in issues:
        prefix = f"issue_{int(issue['sr_no']):04d}_"
        issue_dir = next((path for path in (output_dir / "issues").iterdir() if path.is_dir() and path.name.startswith(prefix)), None)
        if issue_dir and (issue_dir / "ai_decision.json").exists():
            issue.update(json.loads((issue_dir / "ai_decision.json").read_text(encoding="utf-8")))
    merged_file = output_dir / "grouped_issues_with_ai.json"
    merged_file.write_text(json.dumps(issues, indent=2), encoding="utf-8")
    return merged_file