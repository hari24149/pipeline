from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Callable

import requests


BRIDGE_URL = "http://127.0.0.1:3210/ai/chat"
BRIDGE_TOKEN_ENV = "COPILOT_BRIDGE_TOKEN"
BRIDGE_HINTS = {
    401: " (unauthorized: check COPILOT_BRIDGE_TOKEN)",
    403: " (no access: run Authorize Copilot Access in the bridge Control Center)",
    429: " (rate limit of 60/min exceeded: wait and retry)",
    503: " (model unavailable: check Copilot sign-in)",
}
PROGRESS_BAR_WIDTH = 40
PROGRESS_FILLED = "█"
PROGRESS_EMPTY = " "
SPINNER_FRAMES = ("|", "/", "-", "\\")
ANSI_RESET = "\033[0m"
ANSI_CYAN = "\033[96m"
ANSI_GREEN = "\033[92m"
ANSI_YELLOW = "\033[93m"
ANSI_DIM = "\033[2m"


def format_progress(current: int, total: int) -> str:
    """Format an ASCII-only progress bar for redirected terminal output."""
    safe_total = max(total, 1)
    completed = min(
        PROGRESS_BAR_WIDTH,
        max(1 if current else 0, current * PROGRESS_BAR_WIDTH // safe_total),
    )
    bar = "/" * completed + "-" * (PROGRESS_BAR_WIDTH - completed)
    percentage = min(100, current * 100 // safe_total)
    return f"[{bar}] {percentage:3d}% ({current}/{total}) AI decisions"


def render_progress(
    current: int,
    total: int,
    color_enabled: bool | None = None,
) -> str:
    """Render an ANSI-colored PowerShell progress line when supported."""
    if color_enabled is None:
        color_enabled = sys.stdout.isatty() and not os.getenv("NO_COLOR")
    if not color_enabled:
        return format_progress(current, total)

    safe_total = max(total, 1)
    completed = min(
        PROGRESS_BAR_WIDTH,
        max(1 if current else 0, current * PROGRESS_BAR_WIDTH // safe_total),
    )
    percentage = min(100, current * 100 // safe_total)
    filled = PROGRESS_FILLED * completed
    remaining = PROGRESS_EMPTY * (PROGRESS_BAR_WIDTH - completed)
    spinner = SPINNER_FRAMES[current % len(SPINNER_FRAMES)]
    return (
        f"{ANSI_CYAN}[{ANSI_GREEN}{filled}{ANSI_DIM}{remaining}{ANSI_CYAN}]"
        f" {ANSI_YELLOW}{percentage:3d}%{ANSI_RESET}"
        f" {ANSI_DIM}({current}/{total}){ANSI_RESET}"
        f" {ANSI_CYAN}{spinner} AI decisions{ANSI_RESET}"
    )


def _decision_from_content(content: str) -> dict:
    cleaned = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.IGNORECASE).strip()
    match = re.search(r"\{[\s\S]*\}", cleaned)
    decision = json.loads(match.group(0) if match else cleaned)
    status_lookup = {"fixed": "Fixed", "open": "Open", "false positive": "False Positive", "fp": "False Positive"}
    status = status_lookup.get(str(decision.get("status", "")).strip().lower(), decision.get("status", ""))
    if status not in {"Fixed", "Open", "False Positive"}:
        raise ValueError(f"Invalid AI status: {status}")
    justification = str(decision.get("justification", "")).strip()
    if not justification:
        raise ValueError("AI justification is empty")
    return {"status": status, "justification": justification, "solution": str(decision.get("solution", "")).strip() or "Not Applicable"}


def run_ai_decision(
    output_dir: Path,
    progress_callback: Callable[[int, int], None] | None = None,
    skip_existing: bool = False,
) -> Path:
    token = os.getenv(BRIDGE_TOKEN_ENV, "").strip()
    if not token:
        raise ValueError(f"Missing bridge token. Set {BRIDGE_TOKEN_ENV}.")
    issues_dir = output_dir / "issues"
    issue_dirs = [
        issue_dir
        for issue_dir in sorted(path for path in issues_dir.iterdir() if path.is_dir())
        if (issue_dir / "ai_prompt.txt").exists()
    ]
    if skip_existing:
        issue_dirs = [issue_dir for issue_dir in issue_dirs if not (issue_dir / "ai_decision.json").exists()]
    if not issue_dirs:
        if skip_existing:
            raise ValueError(f"No pending AI prompts under: {issues_dir} (all decisions already exist)")
        raise ValueError(f"No ai_prompt.txt files found under: {issues_dir}")

    total = len(issue_dirs)
    if not progress_callback:
        print(f"[AI] Sending {total} decision request(s) to the local Copilot bridge.")
        print(render_progress(0, total), end="\r", flush=True)
    for processed_count, issue_dir in enumerate(issue_dirs, start=1):
        prompt = (issue_dir / "ai_prompt.txt").read_text(encoding="utf-8")
        response = requests.post(BRIDGE_URL, headers={"Content-Type": "application/json", "x-bridge-token": token}, json={"prompt": prompt}, timeout=180)
        payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {"content": response.text}
        if response.status_code != 200:
            hint = BRIDGE_HINTS.get(response.status_code, "")
            raise RuntimeError(f"Bridge API failed for {issue_dir.name}: HTTP {response.status_code}{hint}")
        (issue_dir / "ai_response_raw.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        (issue_dir / "ai_decision.json").write_text(json.dumps(_decision_from_content(payload.get("content", "")), indent=2), encoding="utf-8")
        if progress_callback:
            progress_callback(processed_count, total)
        else:
            print(render_progress(processed_count, total), end="\r", flush=True)
        if processed_count < total:
            time.sleep(1.1)
    if not progress_callback:
        print()
    return issues_dir