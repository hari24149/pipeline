from __future__ import annotations

import json
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


def get_application_name(output_dir: Path) -> str:
    """Use the report folder name, without a trailing scanner-type suffix."""
    application_name = output_dir.name
    if application_name.lower().endswith("_sast"):
        application_name = application_name[:-5]
    return application_name


def export_sast_excel(output_dir: Path) -> Path:
    issues = json.loads((output_dir / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "SAST Summary"
    sheet.append(["Sr. No.", f"Vulnerability {output_dir.name} SAST", "Rule ID", "Severity", "Status (Fixed/Open/False Positive)", "Occurrences", "Application Team Remarks", "Solution Applied to Fix Vulnerability (Source Code/Configuration)"])
    for issue in issues:
        sheet.append([issue.get("sr_no"), issue.get("issue_name"), issue.get("rule_id"), issue.get("severity"), issue.get("status"), issue.get("occurrences"), issue.get("justification"), issue.get("solution")])
    border = Border(*(Side(style="thin", color="999999") for _ in range(4)))
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = border
    for column, width in {"A": 10, "B": 40, "C": 22, "D": 14, "E": 28, "F": 14, "G": 75, "H": 55}.items():
        sheet.column_dimensions[column].width = width
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    output_file = output_dir / f"{get_application_name(output_dir)}_SAST_SuppressionReport.xlsx"
    workbook.save(output_file)
    return output_file