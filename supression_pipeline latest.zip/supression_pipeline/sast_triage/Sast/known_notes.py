from __future__ import annotations

import re
from pathlib import Path


def normalize_key(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value.lower())).strip()


def load_known_notes(output_dir: Path) -> dict[str, dict]:
    notes_file = output_dir / "known_notes.txt"
    if not notes_file.exists():
        notes_file = Path("knowledge") / "sast_known_notes.txt"
    if not notes_file.exists():
        return {}
    notes: dict[str, dict] = {}
    for block in re.split(r"(?m)^###\s+", notes_file.read_text(encoding="utf-8", errors="ignore")):
        lines = block.strip().splitlines()
        if not lines:
            continue
        key = normalize_key(lines[0])
        body = "\n".join(lines[1:])
        status_match = re.search(r"(?im)^status\s*:\s*(.+)$", body)
        remarks_match = re.search(r"(?is)^remarks\s*:\s*(.*?)(?:\nsolution\s*:|\Z)", body)
        solution_match = re.search(r"(?is)^solution\s*:\s*(.*)$", body)
        notes[key] = {
            "known_status": status_match.group(1).strip() if status_match else "",
            "known_remarks": remarks_match.group(1).strip() if remarks_match else "",
            "known_solution": solution_match.group(1).strip() if solution_match else "",
        }
    return notes


def get_known_note(issue_name: str, rule_id: str, notes: dict[str, dict]) -> dict:
    global_context = notes.get(normalize_key("__global__"), {})
    specific_context: dict = {}
    for value in (rule_id, issue_name):
        key = normalize_key(value)
        if key in notes:
            specific_context = notes[key]
            break
    return {
        "known_status": specific_context.get("known_status", "") or global_context.get("known_status", ""),
        "known_remarks": "\n\n".join(
            value
            for value in (
                global_context.get("known_remarks", ""),
                specific_context.get("known_remarks", ""),
            )
            if value
        ),
        "known_solution": specific_context.get("known_solution", "") or global_context.get("known_solution", ""),
    }