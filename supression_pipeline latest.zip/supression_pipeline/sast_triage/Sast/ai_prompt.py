from __future__ import annotations

import json
from pathlib import Path


def build_ai_prompt(packet: dict, justification_style: str) -> str:
    lines = 2 if justification_style == "short" else "4 to 6"
    source_context = json.dumps(packet.get("source_contexts", []), indent=2)
    known_context = json.dumps(packet.get("known_context", {}), indent=2)
    return f'''You are a security triage assistant reviewing a SAST finding against its local source-code context.

Return ONLY valid JSON in this exact shape:
{{
  "status": "Open",
  "justification": "Professional evidence-based remarks",
  "solution": "Specific remediation or Not Applicable"
}}

The status must be exactly one of: Fixed, Open, False Positive.

Decision rules:
- Treat the source excerpts and finding message as the evidence. Do not invent unseen code, configuration, or runtime behavior.
- Choose Open only when the shown code plausibly leaves an exploitable path unmitigated.
- Choose False Positive when the shown source proves the scanner pattern is not exploitable, is safely encoded/validated/parameterized, or cannot reach the reported sink.
- Choose Fixed only when the shown source clearly demonstrates a completed remediation.
- A missing source file or missing source excerpt is insufficient to mark False Positive; choose Open and state that source verification is required.
- When known context does not conflict with the source evidence, preserve its status and technical facts while improving its professional tone.
- The justification must be exactly {lines} concise professional line(s), separated by \\n.
- Do not include markdown, code fences, or text outside JSON.

Finding:
Issue name: {packet.get("issue_name", "")}
Rule ID: {packet.get("rule_id", "")}
Severity: {packet.get("severity", "")}
Occurrences: {packet.get("occurrences", 0)}

Known team context:
{known_context}

Source evidence (line numbers are included):
{source_context}
'''


def run_ai_prompt_generation(output_dir: Path, justification_style: str) -> Path:
    issues_dir = output_dir / "issues"
    generated = 0
    for issue_dir in sorted(issues_dir.iterdir()):
        packet_file = issue_dir / "issue_packet.json"
        if not packet_file.exists():
            continue
        packet = json.loads(packet_file.read_text(encoding="utf-8"))
        (issue_dir / "ai_prompt.txt").write_text(build_ai_prompt(packet, justification_style), encoding="utf-8")
        generated += 1
    if not generated:
        raise ValueError(f"No issue packets found in {issues_dir}")
    return issues_dir