from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path

from Sast.known_notes import get_known_note, load_known_notes


MAX_SOURCE_CHARS = 8000
CONTEXT_LINES = 12


def safe_folder_name(value: str) -> str:
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", value.lower())).strip("_") or "unnamed"


def resolve_source_file(source_root: Path, report_path: str) -> Path | None:
    if not report_path:
        return None
    candidate = Path(report_path.replace("file://", ""))
    candidate = candidate if candidate.is_absolute() else source_root / candidate
    try:
        resolved = candidate.resolve()
        resolved.relative_to(source_root)
    except (OSError, ValueError):
        return None
    return resolved if resolved.is_file() else None


def read_source_context(source_root: Path, report_path: str, start_line: int, end_line: int) -> tuple[str, str]:
    source_file = resolve_source_file(source_root, report_path)
    if not source_file:
        return "", ""
    try:
        lines = source_file.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return "", ""
    if not lines:
        return str(source_file.relative_to(source_root)), ""
    start = max(1, start_line or 1)
    end = max(start, end_line or start)
    first = max(1, start - CONTEXT_LINES)
    last = min(len(lines), end + CONTEXT_LINES)
    context = "\n".join(f"{line_number}: {lines[line_number - 1]}" for line_number in range(first, last + 1))
    return str(source_file.relative_to(source_root)), context[:MAX_SOURCE_CHARS]


def group_findings(findings: list[dict]) -> list[dict]:
    grouped: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
    for finding in findings:
        key = (finding.get("issue_name", ""), finding.get("rule_id", ""), finding.get("severity", ""))
        grouped[key].append(finding)
    issues: list[dict] = []
    for sr_no, ((issue_name, rule_id, severity), occurrences) in enumerate(grouped.items(), start=1):
        issues.append({
            "sr_no": sr_no,
            "issue_name": issue_name,
            "rule_id": rule_id,
            "severity": severity,
            "occurrences": len(occurrences),
            "locations": occurrences,
            "status": "",
            "justification": "",
            "solution": "",
        })
    return issues


def run_evidence_extraction(output_dir: Path, findings: list[dict], source_root: Path) -> Path:
    issues = group_findings(findings)
    (output_dir / "grouped_issues.json").write_text(json.dumps(issues, indent=2), encoding="utf-8")
    issues_dir = output_dir / "issues"
    known_notes = load_known_notes(output_dir)
    for issue in issues:
        issue_dir = issues_dir / f"issue_{issue['sr_no']:04d}_{safe_folder_name(issue['issue_name'])}"
        issue_dir.mkdir(parents=True, exist_ok=True)
        source_contexts = []
        for location in issue["locations"]:
            source_path, source_code = read_source_context(
                source_root,
                location.get("file_path", ""),
                int(location.get("start_line", 0)),
                int(location.get("end_line", 0)),
            )
            source_contexts.append({
                "file_path": source_path or location.get("file_path", ""),
                "start_line": location.get("start_line", 0),
                "end_line": location.get("end_line", 0),
                "message": location.get("message", ""),
                "source_code": source_code,
            })
        packet = {
            **issue,
            "source_contexts": source_contexts,
            "source_root": str(source_root),
            "known_context": get_known_note(issue["issue_name"], issue["rule_id"], known_notes),
        }
        (issue_dir / "issue_packet.json").write_text(json.dumps(packet, indent=2), encoding="utf-8")
        (issue_dir / "source_context.json").write_text(json.dumps(source_contexts, indent=2), encoding="utf-8")
    return issues_dir