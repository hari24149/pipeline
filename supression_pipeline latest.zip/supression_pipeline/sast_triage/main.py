from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

from extract import load_sast_report, save_raw_report
from Sast.ai_client import run_ai_decision
from Sast.ai_prompt import run_ai_prompt_generation
from Sast.evidence import run_evidence_extraction
from Sast.excel_export import export_sast_excel
from Sast.merge_ai import merge_ai_decisions


DEFAULT_BASE_OUTPUT_DIR = Path("output")
SCAN_TYPE = "sast"
PIPELINE_BAR_WIDTH = 32
SPINNER_FRAMES = ("|", "/", "-", "\\")
ANSI_RESET = "\033[0m"
ANSI_WHITE = "\033[97m"
ANSI_YELLOW = "\033[93m"
ANSI_DIM = "\033[2m"

USAGE_GUIDE = r"""
SAST Triage - PowerShell Usage Guide

Install dependencies:
    python -m pip install -r requirements.txt

Run a Fortify SCA Developer Workbook PDF:
    python main.py --pdf "C:\reports\application_sast.pdf" --source-dir "C:\repos\application"

Run a SARIF, JSON, or XML SAST report:
    python main.py --report "C:\reports\scan.sarif" --source-dir "C:\repos\application"

Run interactively (the tool asks for both paths):
    python main.py

Generate source-aware packets without sending requests to the bridge:
    python main.py --pdf "C:\reports\application_sast.pdf" --source-dir "C:\repos\application" --skip-ai

Use detailed rather than two-line Excel-ready remarks:
    python main.py --pdf "C:\reports\application_sast.pdf" --source-dir "C:\repos\application" --justification-style default

Configure the local Copilot bridge token in the current PowerShell session:
    $env:COPILOT_BRIDGE_TOKEN="YOUR_TOKEN_HERE"

Outputs:
    output\sast\<report-name>\
    <application-name>_SAST_SuppressionReport.xlsx

Commands:
    python main.py --help          Show argument reference
    python main.py --help-guide    Show this detailed guide

Example:
    python main.py --pdf "C:\Users\2785364\Downloads\utxapps_tomcat_sast.pdf" --source-dir "C:\Users\2785364\Desktop\Portal\Tomcat\utxportalapp_Tomcat_CODE"
""".strip()


def render_pipeline_progress(
    step: int,
    step_total: int,
    progress: float,
    label: str,
    color_enabled: bool | None = None,
    elapsed_seconds: float | None = None,
) -> str:
    """Render a SAST step with an optional elapsed and remaining-time estimate."""
    if color_enabled is None:
        color_enabled = sys.stdout.isatty() and not os.getenv("NO_COLOR")
    bounded_progress = min(max(progress, 0.0), 1.0)
    completed = int(bounded_progress * PIPELINE_BAR_WIDTH)
    percentage = int(bounded_progress * 100)
    spinner = SPINNER_FRAMES[completed % len(SPINNER_FRAMES)]
    timing = ""
    if elapsed_seconds is not None:
        elapsed = int(elapsed_seconds)
        remaining = int(elapsed_seconds * (1 - bounded_progress) / bounded_progress) if bounded_progress else 0
        timing = f" | elapsed {elapsed // 60:02d}:{elapsed % 60:02d} | eta {remaining // 60:02d}:{remaining % 60:02d}"
    if not color_enabled:
        bar = "/" * completed + "-" * (PIPELINE_BAR_WIDTH - completed)
        return f"[{bar}] {percentage:3d}% Step {step}/{step_total} {spinner} {label}{timing}"

    return (
        f"{ANSI_WHITE}[{'█' * completed}{' ' * (PIPELINE_BAR_WIDTH - completed)}] "
        f"{ANSI_YELLOW}{percentage:3d}%{ANSI_RESET} {ANSI_DIM}Step {step}/{step_total}{ANSI_RESET} "
        f"{ANSI_WHITE}{spinner} {label}{ANSI_RESET}{ANSI_DIM}{timing}{ANSI_RESET}"
    )


def print_step(step: int, total: int, progress: float, label: str) -> None:
    print(render_pipeline_progress(step, total, progress, label))


def build_output_dir(report_path: str) -> Path:
    return DEFAULT_BASE_OUTPUT_DIR / SCAN_TYPE / Path(report_path).stem


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="SAST Triage Console - analyze findings with local source context"
    )
    parser.add_argument(
        "--report",
        "--pdf",
        dest="report",
        default="",
        help="Path to a Fortify SCA PDF, SARIF, JSON, or XML SAST report",
    )
    parser.add_argument(
        "--help-guide",
        "--guide",
        action="store_true",
        help="Show a detailed PowerShell usage guide",
    )
    parser.add_argument(
        "--source-dir",
        default="",
        help="Root directory of the source repository referenced by the report",
    )
    parser.add_argument(
        "--justification-style",
        choices=["short", "default"],
        default="short",
        help="short = 2 Excel-ready lines; default = detailed explanation",
    )
    parser.add_argument(
        "--skip-ai",
        action="store_true",
        help="Create source-aware packets without calling the local Copilot bridge",
    )
    parser.add_argument(
        "--start-stage",
        type=int,
        default=1,
        help="Run from this stage number (1-6)",
    )
    parser.add_argument(
        "--end-stage",
        type=int,
        default=6,
        help="Stop after this stage number (1-6)",
    )
    parser.add_argument(
        "--resume-ai",
        action="store_true",
        help="When running the AI stage, skip issues that already have ai_decision.json",
    )
    return parser.parse_args()


def prompt_for_missing_inputs(args: argparse.Namespace) -> argparse.Namespace:
    """Request required paths when the tool is launched without CLI options."""
    if not args.report:
        args.report = input("SAST report path (.sarif, .json, or .xml): ").strip()
    if not args.source_dir:
        args.source_dir = input("Source repository directory: ").strip()
    return args


def validate_inputs(report_path: str, source_dir: str) -> tuple[Path, Path]:
    report = Path(report_path)
    source_root = Path(source_dir)
    if not report.is_file():
        raise FileNotFoundError(f"SAST report not found: {report}")
    if report.suffix.lower() not in {".pdf", ".json", ".sarif", ".xml"}:
        raise ValueError("SAST report must be a .pdf, .json, .sarif, or .xml file")
    if not source_root.is_dir():
        raise NotADirectoryError(f"Source directory not found: {source_root}")
    return report, source_root.resolve()


def run(
    report_path: str,
    source_dir: str,
    justification_style: str,
    skip_ai: bool,
    start_stage: int,
    end_stage: int,
    resume_ai: bool,
) -> None:
    report, source_root = validate_inputs(report_path, source_dir)
    output_dir = build_output_dir(str(report))
    output_dir.mkdir(parents=True, exist_ok=True)

    print("[START] SAST report processing started")
    print(f"[INFO] Source directory: {source_root}")
    if start_stage <= 1:
        print("[STEP 1] Parsing SAST report...")
        findings, raw_report = load_sast_report(report)
        save_raw_report(raw_report, output_dir)
        print(f"[INFO] Parsed findings: {len(findings)}")
        print_step(1, 6, 1, "Report parsed")
    else:
        findings, _ = load_sast_report(report)
        print(f"[INFO] Using existing artifacts in: {output_dir}")

    if start_stage <= 2 <= end_stage:
        print("[STEP 2] Grouping findings and reading source context...")
        issues_dir = run_evidence_extraction(output_dir, findings, source_root)
        print(f"[OUTPUT] Issues folder: {issues_dir}")
        print_step(2, 6, 1, "Source evidence collected")

    if start_stage <= 3 <= end_stage:
        print("[STEP 3] Generating source-aware AI prompts...")
        run_ai_prompt_generation(output_dir, justification_style)
        print_step(3, 6, 1, "AI prompts generated")

    if start_stage <= 4 <= end_stage:
        if skip_ai:
            print("[SKIPPED] Local Copilot bridge call (--skip-ai)")
        else:
            print("[STEP 4] Sending prompts to the local Copilot bridge...")
            print("[AI] Sending decision requests to the local Copilot bridge.")
            ai_started_at = time.monotonic()
            run_ai_decision(
                output_dir,
                progress_callback=lambda processed, total: print(
                    render_pipeline_progress(
                        4,
                        6,
                        processed / total,
                        f"AI decisions ({processed}/{total})",
                        elapsed_seconds=time.monotonic() - ai_started_at,
                    ),
                    end="\r",
                    flush=True,
                ),
                skip_existing=resume_ai,
            )
            print()

    if start_stage <= 5 <= end_stage:
        print("[STEP 5] Merging AI decisions...")
        merge_ai_decisions(output_dir)
        print_step(5, 6, 1, "Decisions merged")

    excel_file = None
    if start_stage <= 6 <= end_stage:
        print("[STEP 6] Exporting final Excel report...")
        excel_file = export_sast_excel(output_dir)
        print_step(6, 6, 1, "Excel report exported")

    if excel_file:
        print(f"[COMPLETE] SAST processing completed: {excel_file}")
    else:
        print(f"[COMPLETE] SAST stage run completed (stages {start_stage}-{end_stage})")


def main() -> None:
    args = parse_args()
    if args.help_guide:
        print(USAGE_GUIDE)
        return
    args = prompt_for_missing_inputs(args)
    try:
        if args.start_stage < 1 or args.end_stage > 6 or args.start_stage > args.end_stage:
            raise ValueError("Stage range must be between 1 and 6, and start-stage <= end-stage")
        run(
            args.report,
            args.source_dir,
            args.justification_style,
            args.skip_ai,
            args.start_stage,
            args.end_stage,
            args.resume_ai,
        )
    except Exception as exc:
        print("[ERROR] SAST processing failed", file=sys.stderr)
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()