from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch


PROJECT_DIR = Path(__file__).parent
sys.path.insert(0, str(PROJECT_DIR))

from extract import _parse_fortify_pdf_text
from main import prompt_for_missing_inputs
from Sast.ai_client import format_progress, render_progress
from Sast.excel_export import export_sast_excel
from Sast.known_notes import get_known_note


class SastPipelineTests(unittest.TestCase):
    def test_progress_bar_is_visible_before_completion(self) -> None:
        self.assertEqual(
            format_progress(1, 37),
            "[/---------------------------------------]   2% (1/37) AI decisions",
        )
        self.assertEqual(
            format_progress(37, 37),
            "[////////////////////////////////////////] 100% (37/37) AI decisions",
        )

    def test_colored_progress_can_fall_back_to_plain_text(self) -> None:
        self.assertEqual(render_progress(1, 37, color_enabled=False), format_progress(1, 37))
        self.assertIn("\033[96m", render_progress(1, 37, color_enabled=True))

    def test_excel_export_uses_application_suppression_report_name(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            output_dir = Path(temporary_dir) / "application_sast"
            output_dir.mkdir()
            (output_dir / "grouped_issues_with_ai.json").write_text(
                json.dumps([{"sr_no": 1, "issue_name": "Example Finding"}]),
                encoding="utf-8",
            )
            output_file = export_sast_excel(output_dir)
            self.assertEqual(output_file.name, "application_SAST_SuppressionReport.xlsx")
            self.assertTrue(output_file.exists())

    def test_global_and_category_notes_are_combined(self) -> None:
        notes = {
            "global": {
                "known_status": "",
                "known_remarks": "SSO context.",
                "known_solution": "",
            },
            "header manipulation": {
                "known_status": "",
                "known_remarks": "SAGE header context.",
                "known_solution": "",
            },
        }
        context = get_known_note("Header Manipulation", "", notes)
        self.assertEqual(context["known_remarks"], "SSO context.\n\nSAGE header context.")

    def test_fortify_pdf_block_is_parsed(self) -> None:
        findings = _parse_fortify_pdf_text(
            """Cross-Site Scripting: Reflected Critical
Package: com.example.web
src/main/java/com/example/web/Controller.java, line 42 (Cross-Site Scripting: Reflected)
Issue Details
Kingdom: Input Validation and Representation
Source Details
File: src/main/java/com/example/web/Controller.java:30
Sink Details
File: src/main/java/com/example/web/Controller.java:42
"""
        )
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["issue_name"], "Cross-Site Scripting: Reflected")
        self.assertEqual(findings[0]["severity"], "Critical")
        self.assertEqual(findings[0]["file_path"], "src/main/java/com/example/web/Controller.java")
        self.assertEqual(findings[0]["start_line"], 42)

    def test_missing_cli_paths_are_prompted_for(self) -> None:
        args = type("Args", (), {"report": "", "source_dir": ""})()
        with patch("builtins.input", side_effect=["scan.sarif", "C:/repo"]):
            result = prompt_for_missing_inputs(args)
        self.assertEqual(result.report, "scan.sarif")
        self.assertEqual(result.source_dir, "C:/repo")

    def test_sarif_report_creates_source_aware_packet(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_dir:
            temporary_path = Path(temporary_dir)
            report_name = f"sast_test_{uuid.uuid4().hex}"
            source_dir = temporary_path / "source"
            source_dir.mkdir()
            (source_dir / "app.py").write_text(
                "def find_user(user_id):\n    return database.query(user_id)\n",
                encoding="utf-8",
            )
            report = temporary_path / f"{report_name}.sarif"
            report.write_text(
                json.dumps(
                    {
                        "runs": [{
                            "tool": {"driver": {"rules": [{
                                "id": "python.sql-injection",
                                "name": "Potential SQL Injection",
                                "properties": {"tags": ["CWE-89"]},
                            }]}},
                            "results": [{
                                "ruleId": "python.sql-injection",
                                "level": "error",
                                "message": {"text": "Untrusted value reaches a database query."},
                                "locations": [{"physicalLocation": {
                                    "artifactLocation": {"uri": "app.py"},
                                    "region": {"startLine": 2},
                                }}],
                            }],
                        }],
                    }
                ),
                encoding="utf-8",
            )
            output_dir = PROJECT_DIR / "output" / "sast" / report_name
            try:
                result = subprocess.run(
                    [
                        sys.executable,
                        "main.py",
                        "--report",
                        str(report),
                        "--source-dir",
                        str(source_dir),
                        "--skip-ai",
                    ],
                    cwd=PROJECT_DIR,
                    check=False,
                    capture_output=True,
                    text=True,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                packet_file = output_dir / "issues" / "issue_0001_potential_sql_injection" / "issue_packet.json"
                self.assertTrue(packet_file.exists())
                packet = json.loads(packet_file.read_text(encoding="utf-8"))
                self.assertEqual(packet["rule_id"], "python.sql-injection")
                self.assertEqual(packet["source_contexts"][0]["file_path"], "app.py")
                self.assertIn("2:     return database.query(user_id)", packet["source_contexts"][0]["source_code"])
                self.assertTrue((packet_file.parent / "ai_prompt.txt").exists())
            finally:
                if output_dir.exists():
                    import shutil
                    shutil.rmtree(output_dir)


if __name__ == "__main__":
    unittest.main()