from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from pypdf import PdfReader


def _text(value: Any) -> str:
    return str(value or "").strip()


def _location_from_sarif(result: dict) -> tuple[str, int, int]:
    location = (result.get("locations") or [{}])[0].get("physicalLocation", {})
    artifact = location.get("artifactLocation", {})
    region = location.get("region", {})
    return (
        _text(artifact.get("uri") or artifact.get("uriBaseId")),
        int(region.get("startLine") or 0),
        int(region.get("endLine") or region.get("startLine") or 0),
    )


def _parse_sarif(data: dict) -> list[dict]:
    findings: list[dict] = []
    for run in data.get("runs", []):
        rules = {
            rule.get("id", ""): rule
            for rule in run.get("tool", {}).get("driver", {}).get("rules", [])
        }
        for result in run.get("results", []):
            rule_id = _text(result.get("ruleId"))
            rule = rules.get(rule_id, {})
            path, start_line, end_line = _location_from_sarif(result)
            findings.append({
                "issue_name": _text(rule.get("name") or rule_id or result.get("message", {}).get("text")),
                "rule_id": rule_id,
                "severity": _text(result.get("level") or rule.get("defaultConfiguration", {}).get("level") or "Medium").title(),
                "message": _text(result.get("message", {}).get("text")),
                "file_path": path,
                "start_line": start_line,
                "end_line": end_line,
                "cwe": _text(rule.get("properties", {}).get("tags", [""])[0]),
            })
    return findings


def _parse_generic_json(data: Any) -> list[dict]:
    candidates = data if isinstance(data, list) else data.get("findings") or data.get("issues") or data.get("results") or []
    if not isinstance(candidates, list):
        raise ValueError("JSON SAST report must contain a findings, issues, or results array")
    findings: list[dict] = []
    for item in candidates:
        if not isinstance(item, dict):
            continue
        location = item.get("location", {}) if isinstance(item.get("location"), dict) else {}
        findings.append({
            "issue_name": _text(item.get("issue_name") or item.get("rule") or item.get("rule_id") or item.get("name") or item.get("type")),
            "rule_id": _text(item.get("rule_id") or item.get("rule") or item.get("id")),
            "severity": _text(item.get("severity") or item.get("priority") or "Medium").title(),
            "message": _text(item.get("message") or item.get("description") or item.get("details")),
            "file_path": _text(item.get("file_path") or item.get("file") or item.get("path") or location.get("path")),
            "start_line": int(item.get("start_line") or item.get("line") or location.get("start_line") or location.get("line") or 0),
            "end_line": int(item.get("end_line") or location.get("end_line") or 0),
            "cwe": _text(item.get("cwe") or item.get("cwe_id")),
        })
    return findings


def _parse_xml(report: Path) -> list[dict]:
    root = ET.parse(report).getroot()
    findings: list[dict] = []
    for node in root.findall(".//finding") + root.findall(".//issue") + root.findall(".//result"):
        findings.append({
            "issue_name": _text(node.get("rule") or node.get("ruleId") or node.get("type") or node.get("name")),
            "rule_id": _text(node.get("rule") or node.get("ruleId") or node.get("id")),
            "severity": _text(node.get("severity") or node.get("priority") or "Medium").title(),
            "message": _text(node.get("message") or node.findtext("message") or node.findtext("description")),
            "file_path": _text(node.get("file") or node.get("path") or node.get("filename")),
            "start_line": int(node.get("line") or node.get("startLine") or 0),
            "end_line": int(node.get("endLine") or node.get("line") or node.get("startLine") or 0),
            "cwe": _text(node.get("cwe") or node.get("cweId")),
        })
    return findings


def _extract_pdf_text(report: Path) -> str:
    pages: list[str] = []
    reader = PdfReader(str(report))
    for page_number, page in enumerate(reader.pages, start=1):
        pages.append(f"\n--- PAGE {page_number} ---\n{page.extract_text() or ''}")
    return "\n".join(pages)


def _parse_fortify_pdf_text(text: str) -> list[dict]:
    """Parse finding blocks from a Fortify SSC SCA Developer Workbook."""
    heading_pattern = re.compile(
        r"(?m)^(?P<issue_name>.+?)\s+(?P<severity>Critical|High|Medium|Low)\s*$"
    )
    headings = list(heading_pattern.finditer(text))
    findings: list[dict] = []

    for index, heading in enumerate(headings):
        block_end = headings[index + 1].start() if index + 1 < len(headings) else len(text)
        block = text[heading.start():block_end]
        if "Package:" not in block or "Issue Details" not in block:
            continue

        location_match = re.search(
            r"(?m)^(?P<file>(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+\.[A-Za-z0-9_.-]+),\s*line\s*(?P<line>\d+)",
            block,
        )
        if not location_match:
            location_match = re.search(
                r"(?m)^File:\s*(?P<file>.+?):(?P<line>\d+)\s*$",
                block,
            )

        package_match = re.search(r"(?m)^Package:\s*(?P<package>.+)$", block)
        findings.append(
            {
                "issue_name": heading.group("issue_name").strip(),
                "rule_id": heading.group("issue_name").strip(),
                "severity": heading.group("severity").title(),
                "message": "Fortify SCA finding extracted from Developer Workbook.",
                "file_path": location_match.group("file").strip() if location_match else "",
                "start_line": int(location_match.group("line")) if location_match else 0,
                "end_line": int(location_match.group("line")) if location_match else 0,
                "cwe": "",
                "package": package_match.group("package").strip() if package_match else "",
            }
        )
    return findings


def load_sast_report(report: Path) -> tuple[list[dict], str]:
    if report.suffix.lower() == ".pdf":
        raw_report = _extract_pdf_text(report)
        findings = _parse_fortify_pdf_text(raw_report)
    else:
        raw_report = report.read_text(encoding="utf-8", errors="ignore")
        findings = []
    if report.suffix.lower() == ".xml":
        findings = _parse_xml(report)
    elif report.suffix.lower() != ".pdf":
        data = json.loads(raw_report)
        findings = _parse_sarif(data) if isinstance(data, dict) and "runs" in data else _parse_generic_json(data)
    findings = [finding for finding in findings if finding["issue_name"]]
    if not findings:
        if report.suffix.lower() == ".pdf" and re.search(r"(?m)^No Issues\s*$", raw_report):
            raise ValueError(
                "The Fortify report states 'No Issues' (0 findings), so there is nothing to triage. "
                "Export the Developer Workbook from a scan that contains findings."
            )
        raise ValueError("No usable SAST findings were found in the report")
    return findings, raw_report


def save_raw_report(raw_report: str, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "raw_report.txt"
    path.write_text(raw_report, encoding="utf-8")
    return path