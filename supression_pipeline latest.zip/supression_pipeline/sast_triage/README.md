# SAST Triage Automation

## Purpose

SAST Triage Automation processes static-application-security-test findings, reads the affected local source-code context, sends a bounded evidence packet to the local Copilot bridge, and creates an Excel suppression report. It supports Fortify Software Security Center SCA Developer Workbook PDFs as well as structured SARIF, JSON, and XML reports.

## Requirements

- Windows PowerShell and Python 3.
- A running local Copilot bridge at `http://127.0.0.1:3210` for AI decisions.
- A `COPILOT_BRIDGE_TOKEN` set in the PowerShell session.
- The report file and the matching source repository.

Install dependencies from this folder:

```powershell
python -m pip install -r requirements.txt
```

## Quick Start

Set the bridge token without sharing it in chat or source control:

```powershell
$env:COPILOT_BRIDGE_TOKEN="YOUR_TOKEN_HERE"
```

Run a Fortify SCA Developer Workbook PDF. `--source-dir` must be the repository root containing paths such as `src\main\java`.

```powershell
python main.py --pdf "C:\Users\2785364\Downloads\utxapps_tomcat_sast.pdf" --source-dir "C:\Users\2785364\Desktop\Portal\Tomcat\utxportalapp_Tomcat_CODE"
```

Verify that the bridge is available:

```powershell
Invoke-WebRequest http://127.0.0.1:3210/health
```

## Commands

| Command | Use |
| --- | --- |
| `python main.py` | Prompt for the report and source repository paths. |
| `python main.py --pdf <file> --source-dir <directory>` | Run a Fortify SCA PDF. |
| `python main.py --report <file> --source-dir <directory>` | Run SARIF, JSON, or XML. `--pdf` is an alias for `--report`. |
| `python main.py --pdf <file> --source-dir <directory> --justification-style default` | Generate detailed 4-6 line AI remarks. |
| `python main.py --pdf <file> --source-dir <directory> --skip-ai` | Generate finding packets and prompts without bridge requests or Excel export. |
| `python main.py --help` | Show the concise argument reference. |
| `python main.py --help-guide` or `python main.py --guide` | Show the PowerShell usage guide. |

The default `short` justification style requests two concise Excel-ready lines.

## Supported Report Formats

- Fortify SSC SCA Developer Workbook PDF (`.pdf`)
- SARIF (`.sarif` or SARIF-formatted `.json`)
- Generic JSON with `findings`, `issues`, or `results`
- XML with `finding`, `issue`, or `result` elements

Fortify PDF parsing extracts the category, Fortify priority, reported file path, and line number from each issue detail block. SARIF and structured reports should include a rule/name, severity, file path, and line number when available.

## How It Works

1. Parses the input report and saves its raw content.
2. Groups equivalent findings by issue name, rule ID, and severity.
3. Resolves each report path only inside `--source-dir` and collects the reported line plus 12 lines before and after it.
4. Creates one issue packet and AI prompt per grouped finding.
5. Sends each prompt to the local Copilot bridge, validates the JSON response, and stores the decision.
6. Merges decisions and exports the Excel suppression report.

The bridge receives only the selected, line-numbered source snippets. It does not receive unrestricted automatic access to the VS Code workspace or the entire source repository. Paths that resolve outside `--source-dir` are ignored.

## Statuses

The bridge must choose one of these statuses:

- `Open`: source evidence supports a remaining remediation need.
- `False Positive`: source evidence proves the reported pattern is not exploitable.
- `Fixed`: source evidence demonstrates completed remediation.

When the source path or excerpt is unavailable, the prompt instructs the bridge not to mark the finding false positive solely for that reason.

## Known Notes

Use [knowledge/sast_known_notes.txt](knowledge/sast_known_notes.txt) for shared and category-specific trusted application context. Add a report-specific `known_notes.txt` in the output folder when needed.

```text
### __global__
remarks:
Shared SSO and SAGE platform context.

### Header Manipulation
status: False Positive
remarks:
Evidence-based reason specific to this application and the platform configuration.
solution:
Not Applicable
```

`__global__` context is included with every finding. Rule ID or issue-name headings add context only to their matching finding. Notes are guidance, not proof; source evidence remains required for the final decision.

## Outputs

For `utxapps_tomcat_sast.pdf`, output is created under:

```text
output\sast\utxapps_tomcat_sast\
```

| Artifact | Description |
| --- | --- |
| `raw_report.txt` | Original report text, including PDF-extracted text. |
| `grouped_issues.json` | Grouped scanner findings before AI decisions. |
| `issues\issue_*\issue_packet.json` | Full finding, source evidence, and known-notes context. |
| `issues\issue_*\source_context.json` | File paths, lines, messages, and captured source snippets. |
| `issues\issue_*\ai_prompt.txt` | Prompt sent to the bridge. |
| `issues\issue_*\ai_response_raw.json` | Raw bridge response. |
| `issues\issue_*\ai_decision.json` | Validated `status`, `justification`, and `solution`. |
| `grouped_issues_with_ai.json` | Grouped findings after decisions are merged. |
| `<application>_SAST_SuppressionReport.xlsx` | Final Excel report. |

The example report produces `utxapps_tomcat_SAST_SuppressionReport.xlsx`.

## Terminal Progress

Each pipeline step prints a white PowerShell progress bar on completion. During AI processing, the current step shows a spinner, completed decision count, elapsed time, and a remaining-time estimate.

## Troubleshooting

| Message | Resolution |
| --- | --- |
| `SAST report not found` | Use the actual existing report path, quoted if it contains spaces. |
| `Source directory not found` | Pass the repository root, not an individual source file. |
| `Missing bridge token` | Set `$env:COPILOT_BRIDGE_TOKEN` in the same PowerShell session before running. |
| Bridge API error | Check `Invoke-WebRequest http://127.0.0.1:3210/health` and confirm the token is valid. |
| Source excerpt is empty | Ensure report paths are relative to the source root or otherwise resolve inside it. |
| No usable findings | Confirm that the report format and required finding fields are supported. |