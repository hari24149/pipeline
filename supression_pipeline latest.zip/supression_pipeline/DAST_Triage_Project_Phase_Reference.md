# DAST Triage Automation Project — Phase-Based Reference Guide

> Purpose: This document captures the complete agreed flow for the DAST triage automation project so future chats/sessions can directly read this Markdown file and continue the work without losing context.

---

## 1. Project Goal

We are building a **console-based DAST report triage tool first**, then later upgrading it to a web application.

The tool will:

1. Accept a **Fortify SSC WebInspect DAST PDF report** as input.
2. Extract text from the PDF.
3. Clean and normalize the extracted text.
4. Extract vulnerability occurrences from the report.
5. Group the same vulnerability into a single row with an occurrence count.
6. Prepare clean data/prompt packets for an AI API.
7. Receive AI classification/remarks/remediation.
8. Generate an Excel sheet matching the required format.

---

## 2. Important Decision

We will **not follow the old existing code directly**.

The old code is only a reference to understand the general idea of:

- PDF extraction
- Finding parsing
- AI decision flow
- Excel export

But this project will be written fresh for **DAST / Fortify WebInspect PDF** format.

---

## 3. Input Report Type

The uploaded sample DAST reports are Fortify Software Security Center WebInspect reports.

Typical report sections are:

```text
Title
Table of Contents
Executive Summary
Project Description
Vulnerabilities by URL/Location
Security Issues Summary
Security Issues Details
Category Descriptions
```

The useful sections for this tool are mainly:

```text
Security Issues Summary
Security Issues Details
```

`Security Issues Details` contains the full vulnerability evidence such as URL, issue details, CWE, request, and response.

---

## 4. DAST Issue Block Pattern

A detailed vulnerability block usually looks like this:

```text
[Issue Name] [Severity] URL: [Affected URL]
[Affected URL] ([Issue Name]) [Severity]
Issue Details
Kingdom: [Kingdom]
Scan Engine: WEBINSPECT (Dynamic Analysis)
CWE: CWE ID ...
Request
GET /path HTTP/1.1
...
Response
HTTP/1.1 200
...
```

Examples seen in the reports:

```text
Often Misused: HTTP Method Override High URL: https://...
Cross-Frame Scripting Low URL: https://...
Web Server Misconfiguration: Unprotected Directory Low URL: https://...
System Information Leak: External Low URL: https://...
Poor Error Handling: Unhandled Exception Medium URL: https://...
```

---

## 5. Final Excel Output Requirement

The final Excel should **not create one row per URL**.

Instead:

> Same vulnerability + same severity = one Excel row with occurrence count.

Example:

```text
System Information Leak: External Low appears on 65 URLs
```

Excel row should be:

```text
System Information Leak: External | Low | 65
```

Grouping rule:

```python
issue_name + severity
```

If the same issue appears with different severity, keep separate rows:

```text
Poor Error Handling: Unhandled Exception | Medium | 1
Poor Error Handling: Unhandled Exception | Low    | 3
```

---

## 6. Required Excel Columns

Final Excel should match the reference workbook style:

```text
Sr. No.
Vulnerability A0897 DAST
Severity
Status (Fixed/Open/False Positive)
Occurences
Application Team Remarks
Solution Applied to Fix Vulnerability (Source Code/Configuration)
```

Notes:

- Column name `Occurences` may intentionally follow the existing reference spelling.
- `Status`, `Application Team Remarks`, and `Solution Applied...` will eventually come from AI API response.
- Initially these columns can be empty.

---

## 7. Overall Pipeline

```text
PDF
 ↓
Phase 1: Extract raw text
 ↓
Phase 2: Clean text
 ↓
Phase 3: Extract useful sections
 ↓
Phase 4: Parse individual occurrence blocks
 ↓
Phase 5: Group same issues
 ↓
Phase 6: Prepare AI prompt/data packets
 ↓
Phase 7: Call AI API
 ↓
Phase 8: Generate final Excel
```

---

## 8. Phase-Based Development Rule

We will build the project in **very small phases**.

Rule:

> One phase = one small working output.

After each phase:

1. Run it.
2. Check output.
3. Fix if needed.
4. Only then move to the next phase.

No big-bang implementation.

---

## 9. Project Folder Structure

Final modular structure:

```text
dast_triage/
│
├── main.py
├── models.py
│
├── phase_01_extract.py
├── phase_02_clean.py
├── phase_03_sections.py
├── phase_04_parse_occurrences.py
├── phase_05_group_issues.py
├── phase_06_ai_prompt.py
├── phase_07_ai_client.py
├── phase_08_excel_export.py
│
├── config.py
├── requirements.txt
│
└── output/
```

---

## 10. Module Responsibilities

### `main.py`

Console entry point.

Responsibilities:

- Accept PDF path.
- Accept phase number.
- Accept output directory.
- Run selected phase.

Example usage:

```bash
python main.py --phase 1 --pdf "A0897.pdf" --output "output"
```

---

### `models.py`

Contains shared data models.

Expected models:

```python
@dataclass
class DastOccurrence:
    finding_id: str
    issue_name: str
    severity: str
    url: str
    kingdom: str
    scan_engine: str
    cwe: str
    request_method: str
    request_path: str
    response_status: str
    request_raw: str
    response_raw: str
    raw_block: str
```

```python
@dataclass
class DastIssueSummary:
    sr_no: int
    issue_name: str
    severity: str
    occurrences: int
    sample_urls: list[str]
    cwe: str
    evidence_summary: str
    status: str = ""
    application_team_remarks: str = ""
    solution_applied: str = ""
```

---

### `phase_01_extract.py`

Responsibility:

```text
PDF -> raw text
```

Output:

```text
output/raw_text.txt
```

This phase does:

- Open PDF.
- Extract page text.
- Add page markers.
- Save raw output.

This phase does **not**:

- Clean text.
- Parse findings.
- Group issues.
- Call AI.
- Generate Excel.

---

### `phase_02_clean.py`

Responsibility:

```text
raw text -> cleaned text
```

Input:

```text
output/raw_text.txt
```

Output:

```text
output/clean_text.txt
```

Cleaning actions:

- Remove excessive blank lines.
- Normalize line endings.
- Remove image markers.
- Remove repeated page footers where possible.
- Normalize spacing.
- Keep important DAST evidence text.

Important: Do not over-clean request/response data because AI may need evidence.

---

### `phase_03_sections.py`

Responsibility:

```text
clean text -> report sections
```

Input:

```text
output/clean_text.txt
```

Outputs:

```text
output/security_issues_summary.txt
output/security_issues_details.txt
output/category_descriptions.txt
```

Main target:

```text
Security Issues Details
```

Reason:

- Summary has counts.
- Details has evidence.

---

### `phase_04_parse_occurrences.py`

Responsibility:

```text
security_issues_details.txt -> individual occurrence JSON
```

Output:

```text
output/occurrences.json
output/blocks/block_0001.txt
output/blocks/block_0002.txt
```

Each occurrence should include:

```json
{
  "finding_id": "D-00001",
  "issue_name": "System Information Leak: External",
  "severity": "Low",
  "url": "https://example.com/path",
  "kingdom": "Encapsulation",
  "scan_engine": "WEBINSPECT (Dynamic Analysis)",
  "cwe": "CWE ID 215, CWE ID 489, CWE ID 497",
  "request_method": "GET",
  "request_path": "/path",
  "response_status": "200",
  "request_raw": "GET /path HTTP/1.1 ...",
  "response_raw": "HTTP/1.1 200 ...",
  "raw_block": "..."
}
```

---

### `phase_05_group_issues.py`

Responsibility:

```text
occurrences.json -> grouped issues
```

Grouping rule:

```python
(issue_name, severity)
```

Output:

```text
output/grouped_issues.json
```

Example:

```json
{
  "sr_no": 1,
  "issue_name": "System Information Leak: External",
  "severity": "Low",
  "occurrences": 65,
  "sample_urls": [
    "https://example.com/page1.html",
    "https://example.com/page2.html"
  ],
  "cwe": "CWE ID 215, CWE ID 489, CWE ID 497"
}
```

Important:

- Same issue and same severity should be one item.
- Occurrences count should be number of detailed blocks.
- If detailed blocks are missing/truncated, fallback can use `Security Issues Summary` count later.

---

### `phase_06_ai_prompt.py`

Responsibility:

```text
grouped issues + evidence -> AI prompt/data packet
```

Outputs:

```text
output/ai_packets/issue_0001.json
output/ai_packets/issue_0001_prompt.txt
```

AI packet should contain:

```json
{
  "issue_name": "Web Server Misconfiguration: Unprotected Directory",
  "severity": "Low",
  "occurrences": 178,
  "sample_urls": [
    "https://example.com/2006/",
    "https://example.com/2007/"
  ],
  "sample_evidence": [
    {
      "request": "GET /2006/ HTTP/1.1",
      "response": "HTTP/1.1 403 Forbidden"
    }
  ],
  "expected_ai_output": {
    "status": "Fixed/Open/False Positive",
    "application_team_remarks": "",
    "solution_applied": ""
  }
}
```

AI output contract should be strict JSON:

```json
{
  "status": "False Positive",
  "application_team_remarks": "Line 1...\nLine 2...",
  "solution_applied": "Configuration / Source Code / Not Applicable"
}
```

---

### `phase_07_ai_client.py`

Responsibility:

```text
AI packet -> AI API response
```

This phase will be implemented after prompt packets are correct.

Expected behavior:

- Read AI packet JSON.
- Send data to AI API.
- Receive strict JSON response.
- Save response.

Output:

```text
output/ai_responses/issue_0001_response.json
```

For first implementation, this can be mocked or skipped until API details are available.

---

### `phase_08_excel_export.py`

Responsibility:

```text
grouped issues + AI responses -> Excel
```

Output:

```text
output/final_dast_summary.xlsx
```

Excel columns:

```text
Sr. No.
Vulnerability A0897 DAST
Severity
Status (Fixed/Open/False Positive)
Occurences
Application Team Remarks
Solution Applied to Fix Vulnerability (Source Code/Configuration)
```

Initially, before AI integration, Excel can contain:

- Sr. No.
- Vulnerability
- Severity
- Occurrences

And leave these blank:

- Status
- Application Team Remarks
- Solution Applied

---

## 11. Phase 1 Initial Code Plan

For first working batch, create only:

```text
dast_triage/
│
├── main.py
├── phase_01_extract.py
├── requirements.txt
└── output/
```

### `requirements.txt`

```text
pdfplumber
```

### Run command

```bash
python main.py --phase 1 --pdf "A0897.pdf" --output "output"
```

### Expected output

```text
[Phase 1] Starting PDF text extraction...
[Phase 1] Completed successfully
[Phase 1] Raw text saved at: output/raw_text.txt
[Phase 1] Total extracted characters: <number>
```

### Success check

Open:

```text
output/raw_text.txt
```

Search for:

```text
Security Issues Details
```

If present, Phase 1 is successful.

---

## 12. Future Web Upgrade

After console version is stable, upgrade to web.

Possible web flow:

```text
Upload PDF
 ↓
Backend runs phases
 ↓
Show grouped issues in UI
 ↓
Trigger AI review
 ↓
Show AI recommendations
 ↓
Download Excel
```

Potential backend:

```text
FastAPI / Flask
```

Potential frontend:

```text
Angular / React
```

Since the user has experience with Angular and AEM, Angular can be considered later.

---

## 13. Key Rules for Future Continuation

1. Build in tiny phases.
2. Do not jump directly to AI or Excel before extraction/parsing is stable.
3. Keep each module single-responsibility.
4. Always save intermediate files for debugging.
5. Group same vulnerability by `issue_name + severity`.
6. Excel should show one row per grouped issue, not one row per URL.
7. Keep raw evidence for AI prompts.
8. Do not over-clean HTTP request/response evidence.
9. Make console version stable before web version.
10. Reference Excel format must be followed.

---

## 14. Current Status

Current agreed status:

```text
Planning completed.
DAST report format reviewed.
Excel output format reviewed.
Next coding step: Phase 1 extraction module.
```

Next action:

```text
Implement phase_01_extract.py and main.py for PDF -> raw_text.txt
```

---

## 15. Sample Findings Identified From Reports

Representative issue types:

```text
Often Misused: HTTP Method Override
Cross-Frame Scripting
HTML5: Sensitive Information Disclosure via Client-Side Storage
Poor Error Handling: Unhandled Exception
System Information Leak: External
Web Server Misconfiguration: Unprotected Directory
Web Server Misconfiguration: Server Error Message
Web Server Misconfiguration: Insecure Content-Type Setting
Web Server Misconfiguration: Weak Authentication
Weak Cryptographic Hash
Privacy Violation: Autocomplete
Privacy Violation: HTTP GET
Often Misused: File Upload
Insecure Transport: Missing PQC Resilient Key Exchange
HTML5: Deprecated Header
```

---

## 16. Notes on Occurrence Counting

Preferred count:

```text
Number of detailed occurrence blocks parsed from Security Issues Details
```

Fallback count:

```text
Count from Security Issues Summary
```

Reason:

- Detailed section gives better evidence.
- Summary section may be easier to count if details are truncated.

Final implementation can compare both and log mismatch warnings.

---

## 17. Debug Outputs Required

Every phase should save debug outputs:

```text
output/raw_text.txt
output/clean_text.txt
output/security_issues_summary.txt
output/security_issues_details.txt
output/blocks/block_0001.txt
output/occurrences.json
output/grouped_issues.json
output/ai_packets/
output/ai_responses/
output/final_dast_summary.xlsx
```

This makes troubleshooting easier.

---

## 18. Final Expected Product

A console command like:

```bash
python main.py --pdf "A0897.pdf" --output "output"
```

Eventually generates:

```text
output/final_dast_summary.xlsx
```

With grouped vulnerabilities and AI-filled remarks.

---

End of reference document.
