from __future__ import annotations

import ast
import io
import ipaddress
import json
import os
import re
import tokenize
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qsl, urlsplit

from manage_rules import match_highlights, rule_pattern_sources

EXCLUDED = {".git", "node_modules", ".venv", "venv", "dist", "target"}
SECURITY_CHECKS = (
    "dynamic-execution", "os-command", "subprocess-shell", "dynamic-sql", "unsafe-markup",
    "dynamic-template", "unsafe-deserialization", "unsafe-yaml", "weak-hash", "insecure-random",
    "disabled-tls-verification", "unverified-ssl-context", "insecure-tempfile", "archive-extraction",
    "disabled-autoescape", "debug-server", "weak-cipher", "ecb-cipher", "world-writable-permissions",
    "jwt-signature-disabled", "compile-execution", "ssl-cert-none", "ssl-check-hostname-false",
    "lxml-resolve-entities", "lxml-load-dtd",
    "dynamic-import", "importlib-dynamic-import", "runpy-execution", "subprocess-executable-override",
    "sqlalchemy-text-dynamic", "joblib-load", "numpy-allow-pickle", "pandas-pickle", "torch-load",
    "jsonpickle-decode", "jwt-algorithm-none", "network-request-no-timeout",
    "hardcoded-password", "hardcoded-api-key", "hardcoded-database-url", "secret-in-url",
    "secret-logging", "ip-logging", "url-logging",
    "exec-builtins-access", "python-c-api-execution", "os-system-call", "os-popen-call", "os-exec-call",
    "os-spawn-call", "subprocess-dynamic-command", "shell-true", "commands-module", "ssh-command-injection",
    "paramiko-exec-command", "sql-string-concatenation", "sql-percent-formatting", "sql-format-method",
    "sql-fstring", "sqlalchemy-execute-raw", "django-raw-query", "django-extra-query",
    "nosql-operator-injection", "mongodb-query-injection", "redis-command-injection", "ldap-filter-injection",
    "xpath-injection", "requests-user-url", "urllib-user-url", "httpx-user-url", "aiohttp-user-url",
    "ssrf-dangerous-schemes", "cloud-metadata-request", "unvalidated-redirect", "host-header-injection",
    "crlf-header-injection", "email-header-injection", "path-join-user-input", "open-user-path",
    "send-file-user-path", "shutil-copy-user-path", "tarfile-extractall", "zipfile-extractall",
    "archive-symlink-extraction", "unrestricted-file-upload", "upload-original-filename",
    "insecure-named-tempfile", "tempfile-mktemp", "predictable-temp-path", "pickle-load", "cpickle-load",
    "dill-load", "shelve-untrusted-data", "marshal-load", "yaml-full-load", "yaml-unsafe-loader",
    "xml-external-entity", "xmlrpc-untrusted-data", "xml-bomb", "md5-password-hash", "sha1-password-hash",
    "fast-hash-password", "hardcoded-salt", "static-initialization-vector", "zero-initialization-vector",
    "des-cipher", "triple-des-cipher", "rc2-cipher", "rc4-cipher", "blowfish-cipher",
    "aes-cbc-no-authentication", "rsa-small-key", "rsa-insecure-padding", "hardcoded-encryption-key",
    "hardcoded-private-key", "hardcoded-jwt-secret", "sensitive-exception-output", "requests-verify-false",
    "httpx-verify-false", "aiohttp-ssl-false", "old-tls-protocol", "plain-http-sensitive-data",
    "ftp-credentials", "jwt-no-algorithm-allowlist", "jwt-unverified-claims", "jwt-weak-secret",
    "insecure-session-cookie", "cookie-secure-false", "cookie-httponly-false", "cookie-samesite-none",
    "flask-secret-key", "django-insecure-secret-key", "django-debug-enabled", "django-allowed-hosts-wildcard",
    "flask-debug-enabled", "flask-reloader-production", "django-csrf-exempt", "disabled-csrf-protection",
    "cors-wildcard-origin", "cors-wildcard-credentials", "mass-assignment", "mark-safe-user-input",
    "jinja-safe-filter", "render-template-string", "jinja-from-string", "mako-dynamic-template",
    "format-html-user-input", "regex-user-pattern", "catastrophic-regex", "unbounded-request-body",
    "unbounded-decompression", "unbounded-loop-user-input", "world-readable-secret", "chmod-777",
    "chmod-666", "insecure-umask", "bind-all-interfaces", "log-injection", "broad-exception-suppression",
    "assert-security-check", "boto3-public-acl", "boto3-public-bucket-policy",
    "cloud-security-group-open-all", "cloud-iam-wildcard-action",
    "ctypes-memory-operation", "native-library-load", "unsafe-reflection", "hardcoded-ip-address",
)
QUALITY_CHECKS = (
    "quality-bare-except", "quality-swallowed-exception", "quality-mutable-default-argument",
    "quality-none-comparison", "quality-boolean-comparison", "quality-literal-identity-comparison",
    "quality-wildcard-import", "quality-unreachable-code", "quality-self-assignment", "quality-assert-on-tuple",
    "quality-too-many-parameters", "quality-long-function", "quality-high-complexity", "quality-deep-nesting",
    "quality-todo-comment", "quality-redefined-builtin", "quality-duplicate-dict-key", "quality-global-statement",
    "quality-unused-import", "quality-return-in-finally", "quality-fstring-without-placeholders",
)
BUILTIN_RULE_IDS = {f"local-python-{name}" for name in SECURITY_CHECKS + QUALITY_CHECKS}
# A specific rule replaces the generic rule reported on the same line.
SUPERSEDES = {
    "os-system-call": ("os-command",), "os-popen-call": ("os-command",), "shell-true": ("subprocess-shell",),
    "sql-string-concatenation": ("dynamic-sql",), "sql-percent-formatting": ("dynamic-sql",),
    "sql-format-method": ("dynamic-sql",), "sql-fstring": ("dynamic-sql",),
    "sqlalchemy-execute-raw": ("dynamic-sql", "sql-string-concatenation", "sql-percent-formatting", "sql-format-method", "sql-fstring"),
    "django-raw-query": ("dynamic-sql", "sql-string-concatenation", "sql-percent-formatting", "sql-format-method", "sql-fstring"),
    "sqlalchemy-text-dynamic": ("sql-string-concatenation", "sql-percent-formatting", "sql-format-method", "sql-fstring"),
    "pickle-load": ("unsafe-deserialization",), "dill-load": ("unsafe-deserialization",),
    "marshal-load": ("unsafe-deserialization",), "yaml-unsafe-loader": ("unsafe-yaml", "unsafe-deserialization"),
    "yaml-full-load": ("unsafe-yaml",), "tarfile-extractall": ("archive-extraction",),
    "zipfile-extractall": ("archive-extraction",), "tempfile-mktemp": ("insecure-tempfile",),
    "requests-verify-false": ("disabled-tls-verification",), "httpx-verify-false": ("disabled-tls-verification",),
    "aiohttp-ssl-false": ("disabled-tls-verification",), "des-cipher": ("weak-cipher",), "rc4-cipher": ("weak-cipher",),
    "md5-password-hash": ("weak-hash",), "sha1-password-hash": ("weak-hash",), "flask-debug-enabled": ("debug-server",),
    "mark-safe-user-input": ("unsafe-markup",), "render-template-string": ("dynamic-template",),
    "chmod-777": ("world-writable-permissions",), "chmod-666": ("world-writable-permissions",),
    "flask-secret-key": ("hardcoded-api-key",), "django-insecure-secret-key": ("hardcoded-api-key",),
    "hardcoded-database-url": ("secret-in-url",), "hardcoded-private-key": ("hardcoded-encryption-key",),
    "zero-initialization-vector": ("static-initialization-vector",), "cloud-metadata-request": ("hardcoded-ip-address",),
    "cors-wildcard-credentials": ("cors-wildcard-origin",), "nosql-operator-injection": ("mongodb-query-injection",),
}


def _invert(pairs: dict) -> dict:
    inverted = {}
    for specific, generics in pairs.items():
        for generic in generics:
            inverted.setdefault(f"local-python-{generic}", set()).add(f"local-python-{specific}")
    return inverted


SUPERSEDED_BY = _invert(SUPERSEDES)
REQUEST_SOURCE = re.compile(r"(?:^|\.)request\.(?:args|form|values|json|data|files|cookies|headers|GET|POST|COOKIES|META|FILES|query_params|path_params|get_json|get_data|body|query_string|params|stream)(?:\.|$)")
SQL_TEXT = re.compile(r"^\s*(?:SELECT\b[\s\S]*\bFROM\b|INSERT\s+INTO\b|UPDATE\b[\s\S]*\bSET\b|DELETE\s+FROM\b|MERGE\s+INTO\b|(?:DROP|ALTER|CREATE|TRUNCATE)\s+TABLE\b)", re.IGNORECASE)
NESTED_QUANTIFIER = re.compile(r"\(((?:[^()\\]|\\.)*)\)(?:[+*]|\{\d+,\d*\})")
PASSWORD_NAME = re.compile(r"(?:^|_)(?:password|passwd|pwd|passphrase)(?:$|_)")
AUTH_NAME = re.compile(r"(?:^|_)(?:auth|authenticated|authorized|authorised|permission|permissions|has_perm|is_admin|admin|is_staff|is_superuser|role|roles|logged_in|csrf|token)(?:$|_)")
BUILTIN_NAMES = frozenset({
    "all", "any", "bool", "bytes", "compile", "dict", "dir", "eval", "exec", "filter", "float", "format", "hash",
    "help", "id", "input", "int", "iter", "len", "list", "map", "max", "min", "next", "object", "open", "print",
    "range", "set", "str", "sum", "tuple", "type", "vars", "zip",
})
HTTP_METHODS = frozenset({"get", "post", "put", "patch", "delete", "head", "options", "request", "stream"})
SUBPROCESS_CALLS = frozenset({"subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output"})
MONGO_METHODS = frozenset({"find", "find_one", "find_one_and_update", "find_one_and_delete", "find_one_and_replace", "update_one", "update_many", "delete_one", "delete_many", "replace_one", "count_documents", "aggregate"})
REDIRECT_CALLS = frozenset({"flask.redirect", "redirect", "django.shortcuts.redirect", "django.http.HttpResponseRedirect", "HttpResponseRedirect", "fastapi.responses.RedirectResponse", "starlette.responses.RedirectResponse", "RedirectResponse"})
SEND_FILE_CALLS = frozenset({"flask.send_file", "send_file", "django.http.FileResponse", "FileResponse", "fastapi.responses.FileResponse", "starlette.responses.FileResponse"})
RESPONSE_CALLS = frozenset({
    "flask.jsonify", "jsonify", "flask.make_response", "make_response", "flask.Response", "Response", "flask.abort", "abort",
    "django.http.HttpResponse", "HttpResponse", "django.http.JsonResponse", "JsonResponse", "fastapi.responses.JSONResponse",
    "JSONResponse", "fastapi.responses.HTMLResponse", "HTMLResponse", "fastapi.responses.PlainTextResponse", "PlainTextResponse",
})
REGEX_CALLS = frozenset(f"re.{name}" for name in ("compile", "search", "match", "fullmatch", "findall", "finditer", "sub", "subn", "split"))
UNSAFE_MARKUP_CALLS = frozenset({"django.utils.safestring.mark_safe", "markupsafe.Markup", "flask.Markup", "mark_safe", "Markup"})
OLD_TLS = frozenset({
    "ssl.PROTOCOL_SSLv2", "ssl.PROTOCOL_SSLv3", "ssl.PROTOCOL_TLSv1", "ssl.PROTOCOL_TLSv1_1", "ssl.TLSVersion.SSLv3",
    "ssl.TLSVersion.TLSv1", "ssl.TLSVersion.TLSv1_1", "OpenSSL.SSL.SSLv2_METHOD", "OpenSSL.SSL.SSLv3_METHOD",
    "OpenSSL.SSL.TLSv1_METHOD", "OpenSSL.SSL.TLSv1_1_METHOD",
})
VIEW_DECORATORS = re.compile(r"(?:^|\.)(?:route|get|post|put|patch|delete|api_view|websocket)$")
EMAIL_HEADERS = frozenset({"subject", "to", "from", "cc", "bcc", "reply-to"})
COMPOUND = tuple(getattr(ast, name) for name in ("If", "For", "AsyncFor", "While", "With", "AsyncWith", "Try", "TryStar", "Match") if hasattr(ast, name))
MATCH_CASE = getattr(ast, "match_case", None)
MAX_PARAMETERS, MAX_FUNCTION_LINES, MAX_COMPLEXITY, MAX_NESTING = 7, 100, 15, 4
MISSING = object()


def catastrophic_regex(pattern: str) -> bool:
    # A repeated group whose own content ends in an unbounded quantifier can backtrack exponentially.
    return any(re.search(r"(?<!\\)[+*]", body) and re.search(r"(?<!\\)[+*?}]$", body) for body in NESTED_QUANTIFIER.findall(pattern))


def resolve_overlaps(results: list) -> list:
    by_line, redacted = {}, {}
    for result in results:
        line = result["start"]["line"]
        by_line.setdefault(line, set()).add(result["check_id"])
        if result["extra"]["lines"].startswith("[Sensitive source redacted"):
            redacted[line] = result["extra"]["lines"]
    kept, seen = [], set()
    for result in results:
        line = result["start"]["line"]
        key = (result["check_id"], line)
        if key in seen or SUPERSEDED_BY.get(result["check_id"], set()) & by_line[line]:
            continue
        seen.add(key)
        if line in redacted:
            result["extra"]["lines"] = redacted[line]
        kept.append(result)
    return kept


def scan_python(source: Path, rules_path: Path | None = None) -> dict:
    report = {"engine": "local-python-ast", "scanned_files": 0, "results": [], "errors": [], "skipped_directories": [], "skipped_symlinks": 0}
    use_default_rules = rules_path is None
    rules_path = rules_path or Path(__file__).resolve().parent / "rules" / "python-local.json"
    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    if not isinstance(rules, list) or not all(isinstance(rule, dict) for rule in rules):
        raise ValueError("Python rules must be a list of rule objects")
    ids = [rule.get("id") for rule in rules]
    if not all(isinstance(rule_id, str) and rule_id for rule_id in ids) or len(ids) != len(set(ids)):
        raise ValueError("Python rules must have unique non-empty IDs")
    builtin_rules = {}
    patterns = []
    unsupported_rules = []
    defaulted_rules = []
    if use_default_rules:
        defaults = json.loads(rules_path.with_name("python-builtin.json").read_text(encoding="utf-8"))
        for rule in defaults:
            if rule["id"] not in ids:
                builtin_rules[rule["id"]] = rule
                defaulted_rules.append(rule["id"])
    for rule in rules:
        if not isinstance(rule.get("enabled", True), bool):
            raise ValueError(f"Python rule {rule['id']} has an invalid enabled value")
        if rule.get("enabled", True) is False:
            continue
        if rule.get("engine") == "ast":
            if not isinstance(rule.get("message"), str) or not rule["message"].strip() or not isinstance(rule.get("issue_type"), str) or not rule["issue_type"].strip():
                raise ValueError(f"Python AST rule {rule['id']} needs a message and issue type")
            if rule["id"] not in BUILTIN_RULE_IDS:
                unsupported_rules.append(rule["id"])
                continue
            builtin_rules[rule["id"]] = rule
        elif "engine" not in rule and isinstance(rule.get("message"), str) and (isinstance(rule.get("pattern"), str) or isinstance(rule.get("patterns"), list)):
            try:
                compiled = [re.compile(item) for item in rule_pattern_sources(rule)]
            except (re.error, ValueError) as error:
                raise ValueError(f"Python rule {rule['id']} has an invalid pattern: {error}") from error
            patterns.append((rule["id"], compiled, rule["message"], rule.get("issue_type", "Security review"), rule.get("category", "Security"), rule.get("severity", "WARNING"), bool(rule.get("redact"))))
        else:
            raise ValueError(f"Invalid Python rule: {rule['id']}")
    report["builtin_rules"] = len(builtin_rules)
    report["custom_rules"] = len(patterns)
    report["defaulted_builtin_rules"] = sorted(defaulted_rules)
    report["unsupported_ast_rules"] = sorted(unsupported_rules)
    report["disabled_or_missing_builtin_rules"] = sorted(BUILTIN_RULE_IDS - builtin_rules.keys())
    report["coverage_status"] = "incomplete" if unsupported_rules or report["disabled_or_missing_builtin_rules"] else "limited"

    def fail_on_walk_error(error: OSError) -> None:
        raise error

    for directory, directories, filenames in os.walk(source, followlinks=False, onerror=fail_on_walk_error):
        root = Path(directory)
        report["skipped_symlinks"] += sum((root / name).is_symlink() for name in directories)
        report["skipped_directories"].extend((root / name).relative_to(source).as_posix() for name in directories if name in EXCLUDED)
        directories[:] = sorted(name for name in directories if name not in EXCLUDED and not (root / name).is_symlink())
        for name in sorted(filenames):
            path = root / name
            if path.suffix.lower() != ".py":
                continue
            if path.is_symlink():
                report["skipped_symlinks"] += 1
                continue
            relative = path.relative_to(source).as_posix()
            try:
                with tokenize.open(path) as file:
                    text = file.read()
                tree = ast.parse(text, filename=relative)
            except (SyntaxError, UnicodeError, LookupError) as error:
                report["errors"].append({"path": relative, "line": getattr(error, "lineno", None), "message": str(error)})
                continue
            report["scanned_files"] += 1
            file_results = []
            visitor = SecurityVisitor(relative, text, file_results, builtin_rules)
            visitor.visit(tree)
            visitor.check_module(tree)
            comments = {}
            for token in tokenize.generate_tokens(io.StringIO(text).readline):
                if token.type == tokenize.COMMENT:
                    comments[token.start[0]] = token.start[1]
                    visitor.check_comment(token.start[0], token.start[1], token.string)
            report["results"].extend(resolve_overlaps(file_results))
            for line_number, line in enumerate(text.splitlines(), 1):
                for rule_id, compiled, message, issue_type, category, severity, redact in patterns:
                    highlights = [span for span in match_highlights(line, compiled) if span[0] < comments.get(line_number, len(line))]
                    if highlights:
                        report["results"].append({"check_id": rule_id, "path": relative, "start": {"line": line_number, "col": highlights[0][0] + 1}, "extra": {"severity": severity, "category": category, "issue_type": issue_type, "message": message, "lines": line, "highlights": highlights, "redact": redact}})
    return report


class SecurityVisitor(ast.NodeVisitor):
    def __init__(self, path: str, text: str, results: list, builtin_rules: dict):
        self.path = path
        self.lines = text.splitlines()
        self.results = results
        self.aliases = {}
        self.builtin_rules = builtin_rules
        self.archive_kinds = {}
        self.except_names = []
        self.view_functions = []
        self.format_specs = set()
        self.inner_text_nodes = set()
        self.sql_lines = set()

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self.aliases[alias.asname or alias.name.split(".")[0]] = alias.name if alias.asname else alias.name.split(".")[0]

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if any(alias.name == "*" for alias in node.names):
            self.finding(node, "quality-wildcard-import", "Maintainability", "Import names explicitly instead of using a wildcard import.")
        if node.module and node.level == 0:
            for alias in node.names:
                self.aliases[alias.asname or alias.name] = f"{node.module}.{alias.name}"

    def visit_Assign(self, node: ast.Assign) -> None:
        for target in node.targets:
            if isinstance(target, ast.Attribute) and target.attr == "verify_mode" and self.name(node.value) == "ssl.CERT_NONE":
                self.finding(node, "ssl-cert-none", "TLS Verification Disabled", "Do not disable certificate verification.")
            if isinstance(target, ast.Attribute) and target.attr == "check_hostname" and isinstance(node.value, ast.Constant) and node.value.value is False:
                self.finding(node, "ssl-check-hostname-false", "TLS Verification Disabled", "Do not disable hostname verification.")
            self.check_assignment(node, target, node.value)
            if isinstance(target, ast.Name) and isinstance(node.value, ast.Name) and target.id == node.value.id:
                self.finding(node, "quality-self-assignment", "Bug Risk", "Remove this self-assignment.")
            kind = self.archive_kind(node.value)
            if kind and isinstance(target, ast.Name):
                self.archive_kinds[target.id] = kind
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self.check_assignment(node, node.target, node.value)
        self.generic_visit(node)

    def check_assignment(self, node: ast.AST, target: ast.AST, value: ast.AST) -> None:
        if isinstance(target, ast.Name) and target.id in BUILTIN_NAMES:
            self.finding(node, "quality-redefined-builtin", "Maintainability", "Avoid shadowing a built-in name.")
        self.check_hardcoded_assignment(node, target, value)
        self.check_configuration(node, target, value)
        self.check_header_assignment(node, target, value)

    def check_hardcoded_assignment(self, node: ast.AST, target: ast.AST, value: ast.AST) -> None:
        raw_name = self.const_str(target.slice) if isinstance(target, ast.Subscript) else self.name(target).rsplit(".", 1)[-1]
        target_name = self.normalize_name(raw_name)
        if not target_name:
            return
        if re.search(r"(?:^|_)(?:iv|nonce|initialization_vector)$", target_name):
            if self.zero_bytes(value):
                self.finding(node, "zero-initialization-vector", "Weak Cryptography", "Do not use an all-zero initialization vector.")
            elif isinstance(value, ast.Constant) and isinstance(value.value, (str, bytes)) and value.value:
                self.finding(node, "static-initialization-vector", "Weak Cryptography", "Do not reuse a static initialization vector.")
        if not isinstance(value, ast.Constant) or not isinstance(value.value, (str, bytes)) or not value.value:
            return
        literal = value.value.decode("latin-1") if isinstance(value.value, bytes) else value.value
        if " " in literal or re.fullmatch(r"[A-Z][A-Z0-9_]*", literal) or literal.strip().lower() in ("password", "passwd", "pwd", "secret", "token", "api_key", "apikey", "none", "null", "xxx", "***") or self.normalize_name(literal) == target_name:
            return
        if PASSWORD_NAME.search(target_name):
            self.finding(node, "hardcoded-password", "Hardcoded Credentials", "Review hardcoded credentials.", redact_source=True)
        if re.search(r"(?:^|_)(?:api_?key|access_key|secret_key|client_secret|secret|token|auth_token|access_token|refresh_token|bearer_token)$", target_name):
            self.finding(node, "hardcoded-api-key", "Hardcoded Credentials", "Review hardcoded API credentials.", redact_source=True)
        if re.search(r"(?:^|_)salt$", target_name):
            self.finding(node, "hardcoded-salt", "Weak Cryptography", "Do not use a fixed salt.", redact_source=True)
        if re.search(r"(?:^|_)(?:encryption|aes|signing|crypto|cipher|fernet|hmac|private|master)_key$", target_name):
            self.finding(node, "hardcoded-encryption-key", "Hardcoded Secret", "Do not embed encryption keys in source code.", redact_source=True)

    def check_configuration(self, node: ast.AST, target: ast.AST, value: ast.AST) -> None:
        if isinstance(target, ast.Subscript):
            key = self.const_str(target.slice)
        elif isinstance(target, ast.Attribute):
            key = target.attr
        elif isinstance(target, ast.Name):
            key = target.id
        else:
            return
        key = key.upper()
        is_false, is_true = self.is_constant(value, False), self.is_constant(value, True)
        samesite_none = self.const_str(value).lower() == "none"
        if (key in ("SESSION_COOKIE_SECURE", "SESSION_COOKIE_HTTPONLY") and is_false) or (key == "SESSION_COOKIE_SAMESITE" and samesite_none):
            self.finding(node, "insecure-session-cookie", "Session Management", "Review insecure session cookie settings.")
        elif key in ("CSRF_COOKIE_SECURE", "REMEMBER_COOKIE_SECURE") and is_false:
            self.finding(node, "cookie-secure-false", "Session Management", "Review cookies sent without Secure.")
        elif key in ("CSRF_COOKIE_HTTPONLY", "REMEMBER_COOKIE_HTTPONLY") and is_false:
            self.finding(node, "cookie-httponly-false", "Session Management", "Review cookies without HttpOnly.")
        elif key in ("CSRF_COOKIE_SAMESITE", "REMEMBER_COOKIE_SAMESITE") and samesite_none:
            self.finding(node, "cookie-samesite-none", "Session Management", "Review SameSite=None cookies.")
        if key in ("WTF_CSRF_ENABLED", "CSRF_ENABLED", "WTF_CSRF_CHECK_DEFAULT") and is_false:
            self.finding(node, "disabled-csrf-protection", "Cross-Site Request Forgery (CSRF)", "Review disabled CSRF protection.")
        if key in ("CORS_ORIGIN_ALLOW_ALL", "CORS_ALLOW_ALL_ORIGINS") and is_true:
            self.finding(node, "cors-wildcard-origin", "Insecure CORS", "Review wildcard CORS origins.")
        if key == "SECRET_KEY" and isinstance(value, ast.Constant) and isinstance(value.value, (str, bytes)):
            if isinstance(target, ast.Name):
                self.finding(node, "django-insecure-secret-key", "Hardcoded Secret", "Review hardcoded application secret keys.", redact_source=True)
            else:
                self.finding(node, "flask-secret-key", "Hardcoded Secret", "Review hardcoded application secret keys.", redact_source=True)
        if key == "DEBUG" and is_true and isinstance(target, ast.Name):
            self.finding(node, "django-debug-enabled", "Debug Configuration", "Review enabled debug mode.")
        if key == "ALLOWED_HOSTS" and isinstance(value, (ast.List, ast.Tuple)) and any(self.const_str(item) == "*" for item in value.elts):
            self.finding(node, "django-allowed-hosts-wildcard", "Security Misconfiguration", "Review wildcard allowed hosts.")

    def check_header_assignment(self, node: ast.AST, target: ast.AST, value: ast.AST) -> None:
        if not isinstance(target, ast.Subscript):
            return
        key = self.const_str(target.slice).lower()
        if self.name(target.value).rsplit(".", 1)[-1].lower() == "headers":
            if key == "access-control-allow-origin" and self.const_str(value) == "*":
                self.finding(node, "cors-wildcard-origin", "Insecure CORS", "Review wildcard CORS origins.")
            if self.from_request(value):
                self.finding(node, "crlf-header-injection", "HTTP Response Splitting", "Validate header values from requests.")
        elif key in EMAIL_HEADERS and self.from_request(value):
            self.finding(node, "email-header-injection", "Email Header Injection", "Validate email header values from requests.")

    @staticmethod
    def normalize_name(value: str) -> str:
        return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", value).lower()

    @staticmethod
    def is_sensitive_name(value: str) -> bool:
        normalized = SecurityVisitor.normalize_name(value)
        return bool(re.search(r"(?:^|[^a-z0-9])(?:password|passwd|pwd|token|secret|api[_-]?key|credentials?|authorization)(?:$|[^a-z0-9])", normalized))

    @staticmethod
    def has_ip_address(value: str) -> bool:
        for candidate in re.findall(r"(?<![\w:])(?:\d{1,3}\.){3}\d{1,3}(?![\w])|(?<![\w:])(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])", value):
            try:
                ipaddress.ip_address(candidate)
                return True
            except ValueError:
                continue
        return False

    def name(self, node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return self.aliases.get(node.id, node.id)
        if isinstance(node, ast.Attribute):
            return f"{self.name(node.value)}.{node.attr}"
        return ""

    def finding(self, node: ast.AST, rule: str, issue_type: str, message: str, redact_source: bool = False) -> None:
        rule_id = f"local-python-{rule}"
        if rule_id not in self.builtin_rules:
            return
        configured = self.builtin_rules[rule_id]
        issue_type = configured["issue_type"]
        message = configured["message"]
        category = configured.get("category", "Code Quality" if rule.startswith("quality-") else "Security")
        severity = configured.get("severity", "INFO" if category == "Code Quality" else "WARNING")
        line = node.lineno
        source_line = (self.lines[line - 1] if 0 < line <= len(self.lines) else "") or "<empty source line>"
        end = getattr(node, "end_col_offset", None)
        highlights = [[node.col_offset, end]] if isinstance(end, int) and end > node.col_offset else []
        self.results.append({"check_id": rule_id, "path": self.path, "start": {"line": line, "col": node.col_offset + 1}, "extra": {"severity": severity, "category": category, "issue_type": issue_type, "message": f"{issue_type}: {message}", "lines": source_line, "highlights": highlights[:5], "redact": redact_source}})

    def visit_Constant(self, node: ast.Constant) -> None:
        if not isinstance(node.value, str):
            return
        value = node.value
        if "-----BEGIN" in value and "PRIVATE KEY-----" in value:
            self.finding(node, "hardcoded-private-key", "Hardcoded Secret", "Private key material must not be committed.", redact_source=True)
        if any(marker in value for marker in ("169.254.169.254", "metadata.google.internal", "100.100.100.200", "fd00:ec2::254")):
            self.finding(node, "cloud-metadata-request", "Server-Side Request Forgery (SSRF)", "Review cloud metadata endpoints.")
        if value.strip() in ("0.0.0.0/0", "::/0"):
            self.finding(node, "cloud-security-group-open-all", "Cloud Security Misconfiguration", "Review rules open to all addresses.")
        if self.literal_ip(value):
            self.finding(node, "hardcoded-ip-address", "Information Disclosure", "Review hardcoded IP addresses.", redact_source=True)
        if "://" not in value:
            return
        url = self.split_url(value)
        if url is None:
            return
        if url.hostname and self.literal_ip(url.hostname):
            self.finding(node, "hardcoded-ip-address", "Information Disclosure", "Review hardcoded IP addresses.", redact_source=True)
        if url.scheme.lower() in ("postgres", "postgresql", "mysql", "mariadb", "mongodb", "mongodb+srv", "redis", "mssql") and url.password:
            self.finding(node, "hardcoded-database-url", "Hardcoded Credentials", "Review embedded database credentials.", redact_source=True)
        if url.password or any(self.is_sensitive_name(key) and value for key, value in parse_qsl(url.query, keep_blank_values=True)):
            self.finding(node, "secret-in-url", "Sensitive Data Exposure", "Review credentials embedded in URLs.", redact_source=True)

    def visit_Call(self, node: ast.Call) -> None:
        name = self.name(node.func)
        args = node.args
        if isinstance(node.func, ast.Attribute) and node.func.attr in ("debug", "info", "warning", "warn", "error", "exception", "critical", "fatal", "log"):
            owner = self.name(node.func.value)
            if owner == "logging" or owner.rsplit(".", 1)[-1].lower() in ("log", "logger"):
                values = list(ast.walk(node))
                names = [self.name(value).rsplit(".", 1)[-1] for value in values if isinstance(value, (ast.Name, ast.Attribute))]
                strings = [value.value for value in values if isinstance(value, ast.Constant) and isinstance(value.value, str)]
                if any(self.is_sensitive_name(value) for value in names + strings):
                    self.finding(node, "secret-logging", "Sensitive Data in Logs", "Review logging of credentials or secrets.", redact_source=True)
                if any(re.search(r"(?:^|_)(?:ip|ipaddr|ipaddress|remote_addr|client_addr)(?:$|_)", self.normalize_name(value)) for value in names) or any(self.has_ip_address(value) for value in strings):
                    self.finding(node, "ip-logging", "Sensitive Data in Logs", "Review logging of IP addresses.", redact_source=True)
                if any(re.search(r"(?:^|_)(?:url|uri)(?:$|_)", self.normalize_name(value)) for value in names) or any(re.search(r"https?://", value, re.IGNORECASE) for value in strings):
                    self.finding(node, "url-logging", "Sensitive Data in Logs", "Review logging of URLs.", redact_source=True)
                if any(self.from_request(argument) for argument in node.args):
                    self.finding(node, "log-injection", "Log Injection", "Sanitize request values before logging.")
        if name in ("eval", "exec", "builtins.eval", "builtins.exec"):
            self.finding(node, "dynamic-execution", "Code Injection", "Review dynamic execution of code and its input.")
        if name in ("compile", "builtins.compile") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "compile-execution", "Code Injection", "Review compile() usage when source code can contain untrusted input.")
        if name == "lxml.etree.XMLParser":
            for keyword in node.keywords:
                if keyword.arg == "resolve_entities" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                    self.finding(node, "lxml-resolve-entities", "XML External Entity", "Review XML entity resolution.")
                if keyword.arg == "load_dtd" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                    self.finding(node, "lxml-load-dtd", "XML External Entity", "Review loading XML DTDs.")
        if name in ("__import__", "builtins.__import__") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "dynamic-import", "Code Injection", "Review dynamically selected imports.")
        if name == "importlib.import_module" and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "importlib-dynamic-import", "Code Injection", "Review dynamically selected imports.")
        if name in ("runpy.run_module", "runpy.run_path") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "runpy-execution", "Code Injection", "Review dynamically selected code execution.")
        if name in ("subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output") and any(keyword.arg == "executable" and not isinstance(keyword.value, ast.Constant) for keyword in node.keywords):
            self.finding(node, "subprocess-executable-override", "Command Injection", "Review dynamically selected executables.")
        if name in ("sqlalchemy.text", "sqlalchemy.sql.text") and args and self.dynamic_string(args[0]):
            self.finding(node, "sqlalchemy-text-dynamic", "SQL Injection", "Review dynamically constructed SQL.")
        if name == "joblib.load":
            self.finding(node, "joblib-load", "Unsafe Deserialization", "Review Joblib deserialization.")
        if name in ("numpy.load", "numpy.lib.npyio.load") and any(keyword.arg == "allow_pickle" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True for keyword in node.keywords):
            self.finding(node, "numpy-allow-pickle", "Unsafe Deserialization", "Review NumPy pickle loading.")
        if name == "pandas.read_pickle":
            self.finding(node, "pandas-pickle", "Unsafe Deserialization", "Review pandas pickle loading.")
        if name == "torch.load" and any(keyword.arg == "weights_only" and isinstance(keyword.value, ast.Constant) and keyword.value.value is False for keyword in node.keywords):
            self.finding(node, "torch-load", "Unsafe Deserialization", "Review unrestricted model loading.")
        if name == "jsonpickle.decode":
            self.finding(node, "jsonpickle-decode", "Unsafe Deserialization", "Review jsonpickle decoding.")
        if name in ("jwt.decode", "jwt.encode", "jose.jwt.decode", "jose.jwt.encode"):
            for keyword in node.keywords:
                values = keyword.value.elts if isinstance(keyword.value, (ast.List, ast.Tuple, ast.Set)) else [keyword.value]
                if keyword.arg in ("algorithm", "algorithms") and any(isinstance(value, ast.Constant) and isinstance(value.value, str) and value.value.lower() == "none" for value in values):
                    self.finding(node, "jwt-algorithm-none", "Authentication Bypass", "Reject the none JWT algorithm.")
        if name in ("requests.get", "requests.post", "requests.put", "requests.patch", "requests.delete", "requests.head", "requests.options", "requests.request", "httpx.get", "httpx.post", "httpx.put", "httpx.patch", "httpx.delete", "httpx.head", "httpx.options", "httpx.request") and not any(keyword.arg in ("timeout", None) for keyword in node.keywords):
            self.finding(node, "network-request-no-timeout", "Denial of Service", "Review network requests without an explicit timeout.")
        if name in ("os.system", "os.popen", "asyncio.create_subprocess_shell", "subprocess.getoutput", "subprocess.getstatusoutput"):
            self.finding(node, "os-command", "Command Injection", "Review shell command construction and input.")
        if name in ("subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output") and any(keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True for keyword in node.keywords):
            self.finding(node, "subprocess-shell", "Command Injection", "Shell execution can be unsafe when command input is untrusted.")
        if isinstance(node.func, ast.Attribute) and node.func.attr in ("execute", "executemany", "raw") and args and self.dynamic_string(args[0]):
            self.finding(node, "dynamic-sql", "SQL Injection", "Review dynamically constructed query and use parameterized SQL.")
        if name in ("django.utils.safestring.mark_safe", "markupsafe.Markup", "flask.Markup", "mark_safe", "Markup"):
            self.finding(node, "unsafe-markup", "Cross-Site Scripting (XSS)", "Review whether markup marked safe contains untrusted input.")
        if name in ("flask.render_template_string", "render_template_string") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "dynamic-template", "Template Injection / XSS", "Review dynamically constructed template content.")
        if name in ("pickle.load", "pickle.loads", "_pickle.load", "_pickle.loads", "dill.load", "dill.loads", "marshal.load", "marshal.loads", "yaml.unsafe_load"):
            self.finding(node, "unsafe-deserialization", "Unsafe Deserialization", "Do not deserialize untrusted data without appropriate safeguards.")
        if name == "yaml.load" and not any(keyword.arg == "Loader" and self.name(keyword.value) in ("yaml.SafeLoader", "yaml.CSafeLoader") for keyword in node.keywords) and not (len(args) > 1 and self.name(args[1]) in ("yaml.SafeLoader", "yaml.CSafeLoader")):
            self.finding(node, "unsafe-yaml", "Unsafe Deserialization", "Review YAML loader; prefer a safe loader for untrusted data.")
        if name in ("hashlib.md5", "hashlib.sha1") or (name == "hashlib.new" and args and isinstance(args[0], ast.Constant) and str(args[0].value).lower().replace("-", "") in ("md5", "sha1")):
            self.finding(node, "weak-hash", "Weak Cryptography", "Review weak digest use in security-sensitive contexts.")
        if name in ("random.random", "random.randint", "random.randrange", "random.choice", "random.choices", "random.getrandbits"):
            self.finding(node, "insecure-random", "Insecure Randomness", "Use a cryptographically secure generator for secrets and tokens.")
        if (name.startswith("requests.") or name.startswith("httpx.")) and any(keyword.arg == "verify" and isinstance(keyword.value, ast.Constant) and keyword.value.value is False for keyword in node.keywords):
            self.finding(node, "disabled-tls-verification", "TLS Verification Disabled", "Review disabled TLS certificate verification.")
        if name == "aiohttp.TCPConnector" and any(keyword.arg == "ssl" and isinstance(keyword.value, ast.Constant) and keyword.value.value is False for keyword in node.keywords):
            self.finding(node, "disabled-tls-verification", "TLS Verification Disabled", "Review disabled TLS certificate verification.")
        if name == "ssl._create_unverified_context":
            self.finding(node, "unverified-ssl-context", "TLS Verification Disabled", "Review creation of an unverified TLS context.")
        if name == "tempfile.mktemp":
            self.finding(node, "insecure-tempfile", "Insecure Temporary File", "Use an atomic temporary file creation API.")
        if isinstance(node.func, ast.Attribute) and node.func.attr == "extractall" and not any(keyword.arg == "filter" and isinstance(keyword.value, ast.Constant) and keyword.value.value == "data" for keyword in node.keywords):
            self.finding(node, "archive-extraction", "Path Traversal", "Review archive extraction and validate untrusted archive members.")
        if name in ("jinja2.Environment", "jinja2.environment.Environment") and any(keyword.arg == "autoescape" and isinstance(keyword.value, ast.Constant) and keyword.value.value is False for keyword in node.keywords):
            self.finding(node, "disabled-autoescape", "Cross-Site Scripting (XSS)", "Review disabling template autoescaping for untrusted content.")
        if name in ("app.run", "application.run") and any(keyword.arg == "debug" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True for keyword in node.keywords):
            self.finding(node, "debug-server", "Debug Configuration", "Review debug mode before deploying the application.")
        if name in ("Crypto.Cipher.DES.new", "Crypto.Cipher.ARC4.new"):
            self.finding(node, "weak-cipher", "Weak Cryptography", "Review use of a legacy cipher.")
        if name == "Crypto.Cipher.AES.new" and ((len(args) > 1 and self.name(args[1]) == "Crypto.Cipher.AES.MODE_ECB") or any(keyword.arg == "mode" and self.name(keyword.value) == "Crypto.Cipher.AES.MODE_ECB" for keyword in node.keywords)):
            self.finding(node, "ecb-cipher", "Weak Cryptography", "Review use of ECB mode, which exposes patterns in encrypted data.")
        if name == "os.chmod" and len(args) > 1 and isinstance(args[1], ast.Constant) and type(args[1].value) is int and args[1].value & 0o002:
            self.finding(node, "world-writable-permissions", "Insecure Permissions", "Review permissions that make the path writable by everyone.")
        if name in ("jwt.decode", "jose.jwt.decode"):
            for keyword in node.keywords:
                if keyword.arg == "options" and isinstance(keyword.value, ast.Dict):
                    if any(isinstance(key, ast.Constant) and key.value == "verify_signature" and isinstance(value, ast.Constant) and value.value is False for key, value in zip(keyword.value.keys, keyword.value.values)):
                        self.finding(node, "jwt-signature-disabled", "Authentication Bypass", "Review JWT decoding with signature verification disabled.")
        self.check_call(node, name)
        self.generic_visit(node)

    @staticmethod
    def dynamic_string(node: ast.AST) -> bool:
        return isinstance(node, ast.JoinedStr) or (isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod))) or (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format")

    def dynamic_or_request(self, node: ast.AST | None) -> bool:
        return node is not None and (self.dynamic_string(node) or self.from_request(node))

    def check_call(self, node: ast.Call, name: str) -> None:
        args = node.args
        receiver = node.func.value if isinstance(node.func, ast.Attribute) else None
        attr = node.func.attr if isinstance(node.func, ast.Attribute) else ""
        receiver_name = self.name(receiver).lower() if receiver is not None else ""
        root = name.split(".")[0]

        if name in ("getattr", "builtins.getattr") and len(args) > 1:
            if self.name(args[0]) in ("builtins", "__builtins__") and self.const_str(args[1]) in ("eval", "exec", "compile", "__import__"):
                self.finding(node, "exec-builtins-access", "Code Injection", "Review indirect access to code execution built-ins.")
            if self.from_request(args[1]):
                self.finding(node, "unsafe-reflection", "Unsafe Reflection", "Do not select attributes using request values.")
        if name.startswith("ctypes.pythonapi.Py"):
            self.finding(node, "python-c-api-execution", "Code Injection", "Review Python C API execution.")
        if name in ("ctypes.memmove", "ctypes.memset", "ctypes.string_at", "ctypes.wstring_at") or (name in ("ctypes.create_string_buffer", "ctypes.create_unicode_buffer", "ctypes.resize") and any(not isinstance(argument, ast.Constant) for argument in args)):
            self.finding(node, "ctypes-memory-operation", "Memory Safety (Buffer Overflow)", "Review raw memory operations and validate sizes and bounds.")
        if (name in ("ctypes.CDLL", "ctypes.WinDLL", "ctypes.OleDLL", "ctypes.PyDLL", "ctypes.cdll.LoadLibrary", "ctypes.windll.LoadLibrary") or attr == "dlopen") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "native-library-load", "Memory Safety (Native Code)", "Review dynamically selected native libraries.")

        if name == "os.system" and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "os-system-call", "Command Injection", "Avoid dynamic commands in os.system().")
        if name == "os.popen" and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "os-popen-call", "Command Injection", "Avoid dynamic commands in os.popen().")
        if re.fullmatch(r"os\.exec[lv]p?e?", name) and any(not isinstance(argument, ast.Constant) for argument in args):
            self.finding(node, "os-exec-call", "Command Injection", "Review dynamic os.exec arguments.")
        if re.fullmatch(r"os\.(?:spawn[lv]p?e?|posix_spawnp?)", name) and any(not isinstance(argument, ast.Constant) for argument in args[1:]):
            self.finding(node, "os-spawn-call", "Command Injection", "Review dynamic os.spawn arguments.")
        if name in SUBPROCESS_CALLS:
            command = args[0] if args else self.keyword(node, "args")
            elements = command.elts if isinstance(command, (ast.List, ast.Tuple)) else [command]
            if any(self.dynamic_or_request(element) for element in elements):
                self.finding(node, "subprocess-dynamic-command", "Command Injection", "Use a fixed executable and argument list.")
            if self.is_constant(self.keyword(node, "shell"), True):
                self.finding(node, "shell-true", "Command Injection", "Avoid shell=True.")
        if name in ("commands.getoutput", "commands.getstatusoutput", "commands.getstatus"):
            self.finding(node, "commands-module", "Command Injection", "Review legacy commands-module execution.")
        if attr == "exec_command" and args and self.dynamic_or_request(args[0]):
            self.finding(node, "paramiko-exec-command", "Command Injection", "Review dynamic remote commands.")
        if attr in ("run", "sudo") and self.imports("fabric", "invoke", "asyncssh") and args and self.dynamic_or_request(args[0]):
            self.finding(node, "ssh-command-injection", "Command Injection", "Review dynamic remote commands.")

        if attr == "format" and isinstance(receiver, ast.Constant) and isinstance(receiver.value, str) and (args or node.keywords):
            self.check_dynamic_text(node, "format")
        if attr == "execute" and args and self.dynamic_string(args[0]) and self.imports("sqlalchemy") and re.search(r"(?:engine|session|conn|connection|db)$", receiver_name):
            self.finding(node, "sqlalchemy-execute-raw", "SQL Injection", "Avoid executing dynamically constructed SQL.")
        if ((attr == "raw" and receiver_name.endswith("objects")) or name.endswith("RawSQL")) and args and self.dynamic_string(args[0]):
            self.finding(node, "django-raw-query", "SQL Injection", "Review dynamic Django raw SQL.")
        if attr == "extra" and any(keyword.arg in ("where", "select", "tables", "order_by") and any(self.dynamic_string(child) for child in ast.walk(keyword.value)) for keyword in node.keywords):
            self.finding(node, "django-extra-query", "SQL Injection", "Review dynamic Django extra() SQL.")
        if attr in MONGO_METHODS and args and self.imports("pymongo", "motor", "mongoengine", "flask_pymongo", "mongomock"):
            if self.from_request(args[0]) and not isinstance(args[0], ast.Dict):
                self.finding(node, "nosql-operator-injection", "NoSQL Injection", "Do not use request objects directly as queries.")
            elif self.from_request(args[0]):
                self.finding(node, "mongodb-query-injection", "NoSQL Injection", "Validate request values used in queries.")
        if attr == "execute_command" and args and not isinstance(args[0], ast.Constant) and self.imports("redis"):
            self.finding(node, "redis-command-injection", "Command Injection", "Review dynamic Redis commands.")
        if attr in ("search", "search_s", "search_st", "search_ext", "search_ext_s", "paged_search") and self.imports("ldap"):
            candidates = list(args[1:3]) + [keyword.value for keyword in node.keywords if keyword.arg in ("filterstr", "search_filter")]
            if any(self.dynamic_or_request(candidate) for candidate in candidates):
                self.finding(node, "ldap-filter-injection", "LDAP Injection", "Escape values used in LDAP filters.")
        if attr == "xpath" and args and self.dynamic_or_request(args[0]):
            self.finding(node, "xpath-injection", "XPath Injection", "Do not construct XPath expressions dynamically.")

        library = None
        if root in ("requests", "httpx") and attr in HTTP_METHODS:
            library = root
        elif name in ("urllib.request.urlopen", "urllib.request.Request", "urllib.request.urlretrieve", "urllib2.urlopen", "urllib.urlopen"):
            library = "urllib"
        elif attr in HTTP_METHODS and re.search(r"(?:session|client)$", receiver_name):
            library = next((candidate for candidate in ("aiohttp", "httpx", "requests") if self.imports(candidate)), None)
        if library:
            url_args = list(args[:2]) + [keyword.value for keyword in node.keywords if keyword.arg in ("url", "fullurl")]
            if any(self.from_request(argument) for argument in url_args):
                if library == "requests":
                    self.finding(node, "requests-user-url", "Server-Side Request Forgery (SSRF)", "Validate request-controlled URLs.")
                elif library == "httpx":
                    self.finding(node, "httpx-user-url", "Server-Side Request Forgery (SSRF)", "Validate request-controlled URLs.")
                elif library == "aiohttp":
                    self.finding(node, "aiohttp-user-url", "Server-Side Request Forgery (SSRF)", "Validate request-controlled URLs.")
                else:
                    self.finding(node, "urllib-user-url", "Server-Side Request Forgery (SSRF)", "Validate request-controlled URLs.")
            url = self.split_url(next((self.const_str(argument) for argument in url_args if "://" in self.const_str(argument)), ""))
            if url is not None and url.scheme.lower() in ("file", "gopher", "dict", "ftp", "ldap", "jar", "netdoc", "tftp"):
                self.finding(node, "ssrf-dangerous-schemes", "Server-Side Request Forgery (SSRF)", "Reject non-approved URL schemes.")
            if url is not None and url.scheme.lower() == "http" and url.hostname not in ("localhost", "127.0.0.1", "::1") and attr in ("post", "put", "patch") and any(keyword.arg in ("data", "json", "auth", "files") for keyword in node.keywords):
                self.finding(node, "plain-http-sensitive-data", "Cleartext Transmission", "Do not send data over plain HTTP.")
            if library == "requests" and self.is_constant(self.keyword(node, "verify"), False):
                self.finding(node, "requests-verify-false", "TLS Verification Disabled", "Do not disable certificate verification.")
            if library == "httpx" and self.is_constant(self.keyword(node, "verify"), False):
                self.finding(node, "httpx-verify-false", "TLS Verification Disabled", "Do not disable certificate verification.")
            if library == "aiohttp" and self.is_constant(self.keyword(node, "ssl"), False):
                self.finding(node, "aiohttp-ssl-false", "TLS Verification Disabled", "Do not disable certificate verification.")
        if name == "aiohttp.TCPConnector" and self.is_constant(self.keyword(node, "ssl"), False):
            self.finding(node, "aiohttp-ssl-false", "TLS Verification Disabled", "Do not disable certificate verification.")

        if name in REDIRECT_CALLS and args and self.from_request(args[0]):
            self.finding(node, "unvalidated-redirect", "Open Redirect", "Validate redirect targets.")
        if name in ("os.path.join", "posixpath.join", "ntpath.join", "pathlib.Path", "Path", "pathlib.PurePath") and any(self.from_request(argument) for argument in args):
            self.finding(node, "path-join-user-input", "Path Traversal", "Keep request paths inside the intended directory.")
        if name in ("open", "builtins.open", "io.open", "codecs.open") and args:
            if self.from_request(args[0]):
                self.finding(node, "open-user-path", "Path Traversal", "Validate request-controlled paths.")
            if re.match(r"(?:/tmp/|/var/tmp/|[A-Za-z]:\\+(?:Windows\\+)?Temp\\+)", self.literal_text(args[0]), re.IGNORECASE):
                self.finding(node, "predictable-temp-path", "Insecure Temporary File", "Do not use predictable temporary paths.")
        if name in SEND_FILE_CALLS and args and self.from_request(args[0]):
            self.finding(node, "send-file-user-path", "Path Traversal", "Do not send request-controlled paths.")
        if root == "shutil" and attr in ("copy", "copy2", "copyfile", "copytree", "move") and any(self.from_request(argument) for argument in args):
            self.finding(node, "shutil-copy-user-path", "Path Traversal", "Validate request-controlled file paths.")
        if attr == "save" and args:
            if self.from_request(receiver):
                self.finding(node, "unrestricted-file-upload", "Unrestricted File Upload", "Validate uploads before saving.")
            if any(isinstance(child, ast.Attribute) and child.attr == "filename" for child in ast.walk(args[0])) and not any(isinstance(child, ast.Call) and self.name(child.func).endswith("secure_filename") for child in ast.walk(args[0])):
                self.finding(node, "upload-original-filename", "Path Traversal", "Do not store uploads using the original filename.")
        if attr in ("extractall", "extract"):
            kind = self.archive_kind(receiver) or self.archive_kinds.get(self.name(receiver)) or ("tar" if "tar" in receiver_name else "zip" if "zip" in receiver_name else None)
            extract_filter = self.const_str(self.keyword(node, "filter"))
            if attr == "extractall" and kind == "tar" and extract_filter != "data":
                self.finding(node, "tarfile-extractall", "Path Traversal", "Validate tar members before extraction.")
            if attr == "extractall" and kind == "zip":
                self.finding(node, "zipfile-extractall", "Path Traversal", "Validate ZIP members before extraction.")
            if kind == "tar" and ((attr == "extract" and extract_filter != "data") or extract_filter in ("tar", "fully_trusted")):
                self.finding(node, "archive-symlink-extraction", "Arbitrary File Write", "Reject unsafe archive links.")
        if name == "tempfile.mktemp":
            self.finding(node, "tempfile-mktemp", "Insecure Temporary File", "Do not use tempfile.mktemp().")
        if name == "tempfile.NamedTemporaryFile" and self.is_constant(self.keyword(node, "delete"), False) and self.keyword(node, "dir") is None:
            self.finding(node, "insecure-named-tempfile", "Insecure Temporary File", "Review persistent temporary files.")

        loader = self.name(self.keyword(node, "Loader") or (args[1] if len(args) > 1 else None))
        if name in ("pickle.load", "pickle.loads", "_pickle.load", "_pickle.loads", "pickle.Unpickler"):
            self.finding(node, "pickle-load", "Unsafe Deserialization", "Do not unpickle untrusted data.")
        if name in ("cPickle.load", "cPickle.loads"):
            self.finding(node, "cpickle-load", "Unsafe Deserialization", "Do not unpickle untrusted data.")
        if name in ("dill.load", "dill.loads"):
            self.finding(node, "dill-load", "Unsafe Deserialization", "Review dill deserialization.")
        if name in ("marshal.load", "marshal.loads"):
            self.finding(node, "marshal-load", "Unsafe Deserialization", "Review marshal deserialization.")
        if name == "shelve.open":
            self.finding(node, "shelve-untrusted-data", "Unsafe Deserialization", "Review shelve databases.")
        if name in ("yaml.full_load", "yaml.full_load_all") or (name in ("yaml.load", "yaml.load_all") and loader.endswith("FullLoader")):
            self.finding(node, "yaml-full-load", "Unsafe Deserialization", "Use a safe YAML loader.")
        if name in ("yaml.unsafe_load", "yaml.unsafe_load_all") or (name in ("yaml.load", "yaml.load_all") and loader.rsplit(".", 1)[-1] in ("UnsafeLoader", "Loader", "CLoader", "CUnsafeLoader")):
            self.finding(node, "yaml-unsafe-loader", "Unsafe Deserialization", "Do not use an unsafe YAML loader.")
        if name in ("xml.sax.parse", "xml.sax.parseString", "xml.sax.make_parser", "xml.dom.pulldom.parse", "xml.dom.pulldom.parseString") or (name in ("lxml.etree.parse", "lxml.etree.fromstring", "lxml.etree.XML", "lxml.etree.iterparse") and len(args) < 2 and self.keyword(node, "parser") is None):
            self.finding(node, "xml-external-entity", "XML External Entity (XXE)", "Use hardened XML parsing.")
        if re.fullmatch(r"xml\.(?:etree\.c?ElementTree\.(?:parse|fromstring|XML|iterparse|XMLParser)|dom\.minidom\.(?:parse|parseString)|dom\.expatbuilder\.parse|parsers\.expat\.ParserCreate)", name):
            self.finding(node, "xml-bomb", "Denial of Service", "Use a protected XML parser such as defusedxml.")
        if name in ("xmlrpc.server.SimpleXMLRPCServer", "xmlrpc.server.DocXMLRPCServer", "xmlrpc.server.CGIXMLRPCRequestHandler", "SimpleXMLRPCServer.SimpleXMLRPCServer", "xmlrpc.client.loads", "xmlrpclib.loads"):
            self.finding(node, "xmlrpc-untrusted-data", "Unsafe XML Processing", "Use hardened XML-RPC parsing.")

        hash_name = self.const_str(args[0]).lower().replace("-", "") if name == "hashlib.new" and args else (attr.lower() if root == "hashlib" else "")
        hashed = args[1:] if name == "hashlib.new" else args
        if hash_name and any(isinstance(child, (ast.Name, ast.Attribute)) and PASSWORD_NAME.search(self.normalize_name(self.name(child).rsplit(".", 1)[-1])) for argument in hashed for child in ast.walk(argument)):
            if hash_name == "md5":
                self.finding(node, "md5-password-hash", "Weak Password Storage", "Do not hash passwords with MD5.")
            elif hash_name == "sha1":
                self.finding(node, "sha1-password-hash", "Weak Password Storage", "Do not hash passwords with SHA-1.")
            elif hash_name in ("sha224", "sha256", "sha384", "sha512", "sha3_256", "sha3_512", "blake2b", "blake2s"):
                self.finding(node, "fast-hash-password", "Weak Password Storage", "Use a password hashing algorithm.")
        cipher = re.fullmatch(r"(?:Crypto|Cryptodome)\.Cipher\.(DES3|DES|ARC2|ARC4|Blowfish|AES)\.new", name) or re.fullmatch(r"cryptography\.hazmat\.(?:primitives|decrepit)\.ciphers\.algorithms\.(TripleDES|Blowfish|ARC4)", name)
        algorithm = cipher.group(1) if cipher else ""
        if algorithm == "DES":
            self.finding(node, "des-cipher", "Weak Cryptography", "Replace DES.")
        elif algorithm in ("DES3", "TripleDES"):
            self.finding(node, "triple-des-cipher", "Weak Cryptography", "Replace Triple DES.")
        elif algorithm == "ARC2":
            self.finding(node, "rc2-cipher", "Weak Cryptography", "Replace RC2.")
        elif algorithm == "ARC4":
            self.finding(node, "rc4-cipher", "Weak Cryptography", "Replace RC4.")
        elif algorithm == "Blowfish":
            self.finding(node, "blowfish-cipher", "Weak Cryptography", "Replace Blowfish.")
        if (cipher and cipher.group(1) == "AES" and any(self.name(value).endswith("MODE_CBC") for value in args[1:2] + [self.keyword(node, "mode")] if value is not None)) or name == "cryptography.hazmat.primitives.ciphers.modes.CBC":
            self.finding(node, "aes-cbc-no-authentication", "Weak Cryptography", "Prefer authenticated encryption.")
        initialization_vectors = [keyword.value for keyword in node.keywords if keyword.arg in ("iv", "IV", "nonce", "initialization_vector")]
        if name.startswith("cryptography.hazmat.primitives.ciphers.modes.") and args:
            initialization_vectors.append(args[0])
        for value in initialization_vectors:
            if self.zero_bytes(value):
                self.finding(node, "zero-initialization-vector", "Weak Cryptography", "Do not use an all-zero initialization vector.")
            elif isinstance(value, ast.Constant) and isinstance(value.value, (str, bytes)) and value.value:
                self.finding(node, "static-initialization-vector", "Weak Cryptography", "Do not reuse a static initialization vector.")
        if (cipher or name in ("cryptography.fernet.Fernet", "hmac.new")) and args and isinstance(args[0], ast.Constant) and isinstance(args[0].value, (str, bytes)) and args[0].value:
            self.finding(node, "hardcoded-encryption-key", "Hardcoded Secret", "Do not embed encryption keys in source code.", redact_source=True)
        key_size = None
        if name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key":
            key_size = self.keyword(node, "key_size") or (args[1] if len(args) > 1 else None)
        elif re.fullmatch(r"(?:Crypto|Cryptodome)\.PublicKey\.(?:RSA|DSA)\.generate", name) or name == "rsa.newkeys":
            key_size = args[0] if args else self.keyword(node, "bits")
        if isinstance(key_size, ast.Constant) and type(key_size.value) is int and key_size.value < 2048:
            self.finding(node, "rsa-small-key", "Weak Cryptography", "Use RSA keys of at least 2048 bits.")
        if name in ("cryptography.hazmat.primitives.asymmetric.padding.PKCS1v15", "Crypto.Cipher.PKCS1_v1_5.new", "Cryptodome.Cipher.PKCS1_v1_5.new"):
            self.finding(node, "rsa-insecure-padding", "Weak Cryptography", "Review legacy RSA padding.")
        if name in OLD_TLS:
            self.finding(node, "old-tls-protocol", "Insecure Transport", "Do not enable obsolete TLS versions.")
        if name == "ftplib.FTP":
            self.finding(node, "ftp-credentials", "Cleartext Transmission", "Avoid unencrypted FTP.")

        if name in ("jwt.encode", "jwt.decode", "jose.jwt.encode", "jose.jwt.decode"):
            secret = args[1] if len(args) > 1 else self.keyword(node, "key")
            if isinstance(secret, ast.Constant) and isinstance(secret.value, (str, bytes)) and secret.value:
                self.finding(node, "hardcoded-jwt-secret", "Hardcoded Secret", "Do not hardcode JWT secrets.", redact_source=True)
                if len(secret.value) < 32:
                    self.finding(node, "jwt-weak-secret", "Weak Authentication", "Use a strong JWT secret.", redact_source=True)
        if name in ("jwt.decode", "jose.jwt.decode"):
            options = self.keyword(node, "options")
            disabled = {self.const_str(key) for key, value in zip(options.keys, options.values) if self.is_constant(value, False)} if isinstance(options, ast.Dict) else set()
            if self.keyword(node, "algorithms") is None and len(args) < 3 and "verify_signature" not in disabled:
                self.finding(node, "jwt-no-algorithm-allowlist", "Authentication Bypass", "Use an explicit JWT algorithm allowlist.")
            if disabled & {"verify_exp", "verify_aud", "verify_iss", "verify_nbf", "verify_iat"}:
                self.finding(node, "jwt-unverified-claims", "Authentication Bypass", "Validate JWT claims.")
        if name in ("jose.jwt.get_unverified_claims", "jwt.api_jwt.decode_complete"):
            self.finding(node, "jwt-unverified-claims", "Authentication Bypass", "Validate JWT claims.")
        if attr == "set_cookie":
            if self.is_constant(self.keyword(node, "secure"), False):
                self.finding(node, "cookie-secure-false", "Session Management", "Review cookies sent without Secure.")
            if self.is_constant(self.keyword(node, "httponly"), False):
                self.finding(node, "cookie-httponly-false", "Session Management", "Review cookies without HttpOnly.")
            if self.const_str(self.keyword(node, "samesite")).lower() == "none":
                self.finding(node, "cookie-samesite-none", "Session Management", "Review SameSite=None cookies.")
        if (attr == "run" and re.search(r"(?:^|\.)(?:app|application|server)$", receiver_name)) or name in ("werkzeug.serving.run_simple", "run_simple"):
            if self.is_constant(self.keyword(node, "debug"), True):
                self.finding(node, "flask-debug-enabled", "Debug Configuration", "Disable debug mode outside development.")
            if self.is_constant(self.keyword(node, "use_reloader"), True) or self.is_constant(self.keyword(node, "use_debugger"), True):
                self.finding(node, "flask-reloader-production", "Debug Configuration", "Disable the reloader and debugger in production.")
        host = self.keyword(node, "host") or (args[0] if attr == "run" and args else None)
        address = args[0].elts[0] if attr == "bind" and args and isinstance(args[0], ast.Tuple) and args[0].elts else None
        if (isinstance(host, ast.Constant) and host.value in ("0.0.0.0", "::")) or (isinstance(address, ast.Constant) and address.value in ("0.0.0.0", "", "::")):
            self.finding(node, "bind-all-interfaces", "Exposed Service", "Review services bound to all interfaces.")
        is_middleware = attr == "add_middleware" and args and self.name(args[0]).endswith("CORSMiddleware")
        if name in ("flask_cors.CORS", "CORS", "flask_cors.cross_origin", "cross_origin") or is_middleware:
            origins = self.keyword(node, "origins") or self.keyword(node, "allow_origins")
            values = (origins.elts if isinstance(origins, (ast.List, ast.Tuple, ast.Set)) else [origins]) if origins is not None else []
            if any(self.const_str(value) == "*" for value in values) or (origins is None and self.keyword(node, "resources") is None and not is_middleware):
                self.finding(node, "cors-wildcard-origin", "Insecure CORS", "Review wildcard CORS origins.")
                if self.is_constant(self.keyword(node, "supports_credentials"), True) or self.is_constant(self.keyword(node, "allow_credentials"), True):
                    self.finding(node, "cors-wildcard-credentials", "Insecure CORS", "Do not combine wildcard origins with credentials.")
        if any(keyword.arg is None and self.from_request(keyword.value) for keyword in node.keywords) or (attr == "update" and isinstance(receiver, ast.Attribute) and receiver.attr == "__dict__" and args and self.from_request(args[0])) or (name in ("setattr", "builtins.setattr") and len(args) > 1 and self.from_request(args[1])):
            self.finding(node, "mass-assignment", "Mass Assignment", "Do not map request objects directly onto models.")

        if name in UNSAFE_MARKUP_CALLS and args and self.from_request(args[0]):
            self.finding(node, "mark-safe-user-input", "Cross-Site Scripting (XSS)", "Do not mark request values as safe.")
        is_template_source = name in ("flask.render_template_string", "render_template_string", "jinja2.Template", "mako.template.Template") or (attr == "from_string" and self.imports("jinja2"))
        if is_template_source and args and re.search(r"\|\s*safe\b", self.literal_text(args[0])):
            self.finding(node, "jinja-safe-filter", "Cross-Site Scripting (XSS)", "Review the safe filter.")
        if name in ("flask.render_template_string", "render_template_string") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "render-template-string", "Server-Side Template Injection", "Do not build templates from dynamic strings.")
        if attr == "from_string" and self.imports("jinja2") and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "jinja-from-string", "Server-Side Template Injection", "Do not build templates from dynamic strings.")
        if name == "mako.template.Template" and args and not isinstance(args[0], ast.Constant):
            self.finding(node, "mako-dynamic-template", "Server-Side Template Injection", "Do not build templates from dynamic strings.")
        if name in REGEX_CALLS and args:
            if self.from_request(args[0]):
                self.finding(node, "regex-user-pattern", "Regular Expression Denial of Service", "Do not compile request-controlled regular expressions.")
            if catastrophic_regex(self.const_str(args[0])):
                self.finding(node, "catastrophic-regex", "Regular Expression Denial of Service", "Review nested quantifiers.")
        if re.search(r"(?:^|\.)request\.(?:get_data|body)$", name) or (attr in ("read", "readlines") and not args and self.from_request(receiver)):
            self.finding(node, "unbounded-request-body", "Denial of Service", "Limit request body size before reading it into memory.")
        if name in ("zlib.decompress", "gzip.decompress", "bz2.decompress", "lzma.decompress"):
            self.finding(node, "unbounded-decompression", "Denial of Service", "Limit decompressed size.")
        if name in ("range", "builtins.range") and any(self.from_request(argument) for argument in args):
            self.finding(node, "unbounded-loop-user-input", "Denial of Service", "Bound request-controlled loop counts.")
        mode, path = (args[1], args[0]) if name == "os.chmod" and len(args) > 1 else (args[0], receiver) if attr == "chmod" and name != "os.chmod" and args else (None, None)
        if isinstance(mode, ast.Constant) and type(mode.value) is int:
            if mode.value & 0o777 == 0o777:
                self.finding(node, "chmod-777", "Insecure Permissions", "Avoid granting all permissions to everyone.")
            elif mode.value & 0o666 == 0o666:
                self.finding(node, "chmod-666", "Insecure Permissions", "Avoid world-writable files.")
            if mode.value & 0o004 and re.search(r"secret|token|credential|password|passwd|private|\.pem|\.key|id_rsa|\.env", f"{self.literal_text(path)} {self.name(path)}", re.IGNORECASE):
                self.finding(node, "world-readable-secret", "Insecure Permissions", "Restrict permissions on secret files.")
        if name == "os.umask" and args and isinstance(args[0], ast.Constant) and type(args[0].value) is int and not args[0].value & 0o002:
            self.finding(node, "insecure-umask", "Insecure Permissions", "Review permissive process umask.")
        if self.const_str(self.keyword(node, "ACL")) in ("public-read", "public-read-write", "authenticated-read"):
            self.finding(node, "boto3-public-acl", "Cloud Security Misconfiguration", "Review public ACLs.")
        if name in RESPONSE_CALLS and any(self.exposes_exception(value, True) for value in list(args) + [keyword.value for keyword in node.keywords]):
            self.finding(node, "sensitive-exception-output", "Sensitive Information Exposure", "Do not return exception details to clients.")

    def check_dynamic_text(self, node: ast.AST, kind: str) -> None:
        text = self.literal_text(node)
        if SQL_TEXT.search(text):
            if kind == "fstring":
                self.finding(node, "sql-fstring", "SQL Injection", "Use parameterized SQL.")
            elif kind == "percent":
                self.finding(node, "sql-percent-formatting", "SQL Injection", "Use parameterized SQL.")
            elif kind == "format":
                self.finding(node, "sql-format-method", "SQL Injection", "Use parameterized SQL.")
            else:
                self.finding(node, "sql-string-concatenation", "SQL Injection", "Use parameterized SQL.")
        if re.search(r"<[A-Za-z][^>]*>", text) and self.from_request(node):
            self.finding(node, "format-html-user-input", "Cross-Site Scripting (XSS)", "Escape request values in HTML.")
        if any((isinstance(child, ast.Attribute) and re.search(r"(?:^|\.)request\.(?:host|host_url|url_root)$", self.name(child))) or (isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and child.func.attr == "get_host") for child in ast.walk(node)):
            self.finding(node, "host-header-injection", "Host Header Injection", "Do not build URLs from the Host header.")

    def literal_text(self, node: ast.AST | None) -> str:
        if isinstance(node, ast.Constant):
            return node.value if isinstance(node.value, str) else " ? "
        if isinstance(node, ast.JoinedStr):
            return "".join(value.value if isinstance(value, ast.Constant) and isinstance(value.value, str) else " ? " for value in node.values)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return self.literal_text(node.left) + self.literal_text(node.right)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mod):
            return self.literal_text(node.left)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format":
            return self.literal_text(node.func.value)
        return " ? "

    def from_request(self, node: ast.AST | None) -> bool:
        return node is not None and any(isinstance(child, ast.Attribute) and REQUEST_SOURCE.search(self.name(child)) for child in ast.walk(node))

    def imports(self, *prefixes: str) -> bool:
        return any(value.startswith(prefixes) for value in self.aliases.values())

    @staticmethod
    def keyword(node: ast.Call, name: str) -> ast.AST | None:
        return next((keyword.value for keyword in node.keywords if keyword.arg == name), None)

    @staticmethod
    def is_constant(node: ast.AST | None, value: object) -> bool:
        return isinstance(node, ast.Constant) and type(node.value) is type(value) and node.value == value

    @staticmethod
    def const_str(node: ast.AST | None) -> str:
        return node.value if isinstance(node, ast.Constant) and isinstance(node.value, str) else ""

    def archive_kind(self, node: ast.AST | None) -> str | None:
        if isinstance(node, ast.Call):
            called = self.name(node.func)
            if called.startswith("tarfile."):
                return "tar"
            if called.startswith("zipfile."):
                return "zip"
        return None

    @staticmethod
    def split_url(value: str):
        try:
            return urlsplit(value) if value else None
        except ValueError:
            return None

    @staticmethod
    def literal_ip(value: str) -> bool:
        candidate = value.strip()
        match = re.fullmatch(r"(\d{1,3}(?:\.\d{1,3}){3})(?::\d{1,5})?", candidate)
        if match:
            candidate = match.group(1)
        elif not re.fullmatch(r"[0-9A-Fa-f:]{2,39}", candidate) or candidate.count(":") < 2:
            return False
        try:
            address = ipaddress.ip_address(candidate)
        except ValueError:
            return False
        return not (address.is_loopback or address.is_unspecified)

    def zero_bytes(self, value: ast.AST | None) -> bool:
        if isinstance(value, ast.Constant) and isinstance(value.value, bytes):
            return bool(value.value) and not value.value.strip(b"\x00")
        if isinstance(value, ast.BinOp) and isinstance(value.op, ast.Mult):
            return self.zero_bytes(value.left) or self.zero_bytes(value.right)
        return isinstance(value, ast.Call) and self.name(value.func) in ("bytes", "bytearray") and len(value.args) == 1 and isinstance(value.args[0], ast.Constant) and type(value.args[0].value) is int

    def exposes_exception(self, value: ast.AST, include_exception_names: bool) -> bool:
        names = {name for name in self.except_names if name}
        for child in ast.walk(value):
            if isinstance(child, ast.Call) and self.name(child.func) in ("traceback.format_exc", "traceback.format_exception", "traceback.format_tb", "traceback.format_stack"):
                return True
            if include_exception_names and isinstance(child, ast.Name) and child.id in names:
                return True
        return False

    def visit_With(self, node: ast.With) -> None:
        for item in node.items:
            kind = self.archive_kind(item.context_expr)
            if kind and isinstance(item.optional_vars, ast.Name):
                self.archive_kinds[item.optional_vars.id] = kind
        self.generic_visit(node)

    visit_AsyncWith = visit_With

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        decorators = [self.name(decorator.func if isinstance(decorator, ast.Call) else decorator) for decorator in node.decorator_list]
        if any(decorator.endswith("csrf_exempt") for decorator in decorators):
            self.finding(node, "django-csrf-exempt", "Cross-Site Request Forgery (CSRF)", "Review csrf_exempt usage.")
        self.check_function_quality(node)
        self.view_functions.append(any(VIEW_DECORATORS.search(decorator) for decorator in decorators))
        self.generic_visit(node)
        self.view_functions.pop()

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        broad = node.type is None or self.name(node.type).rsplit(".", 1)[-1] in ("Exception", "BaseException")
        silent = all(isinstance(statement, (ast.Pass, ast.Continue)) or (isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant)) for statement in node.body)
        if node.type is None:
            self.finding(node, "quality-bare-except", "Bug Risk", "Catch specific exceptions instead of using a bare except.")
        if silent and broad:
            self.finding(node, "broad-exception-suppression", "Improper Error Handling", "Do not silently ignore exceptions.")
        elif silent:
            self.finding(node, "quality-swallowed-exception", "Bug Risk", "Handle or log ignored exceptions.")
        self.except_names.append(node.name)
        self.generic_visit(node)
        self.except_names.pop()

    def visit_Return(self, node: ast.Return) -> None:
        if node.value is not None and self.exposes_exception(node.value, bool(self.view_functions and self.view_functions[-1])):
            self.finding(node, "sensitive-exception-output", "Sensitive Information Exposure", "Do not return exception details to clients.")
        self.generic_visit(node)

    def visit_Assert(self, node: ast.Assert) -> None:
        if isinstance(node.test, ast.Tuple) and node.test.elts:
            self.finding(node, "quality-assert-on-tuple", "Bug Risk", "An assertion on a non-empty tuple always passes.")
        names = [self.normalize_name(self.name(child).rsplit(".", 1)[-1]) for child in ast.walk(node.test) if isinstance(child, (ast.Name, ast.Attribute))]
        if any(AUTH_NAME.search(name) for name in names):
            self.finding(node, "assert-security-check", "Authentication or Authorization Bypass", "Do not enforce security checks with assert.")
        self.generic_visit(node)

    def visit_Global(self, node: ast.Global) -> None:
        self.finding(node, "quality-global-statement", "Maintainability", "Avoid modifying global state.")

    def visit_Compare(self, node: ast.Compare) -> None:
        operands = [node.left, *node.comparators]
        for index, operator in enumerate(node.ops):
            pair = (operands[index], operands[index + 1])
            if isinstance(operator, (ast.Eq, ast.NotEq)) and any(isinstance(side, ast.Constant) and side.value is None for side in pair):
                self.finding(node, "quality-none-comparison", "Bug Risk", "Compare with None using is or is not.")
            elif isinstance(operator, (ast.Eq, ast.NotEq)) and any(isinstance(side, ast.Constant) and isinstance(side.value, bool) for side in pair):
                self.finding(node, "quality-boolean-comparison", "Maintainability", "Do not compare with True or False.")
            if isinstance(operator, (ast.Is, ast.IsNot)) and any(isinstance(side, ast.Constant) and type(side.value) in (str, bytes, int, float) for side in pair):
                self.finding(node, "quality-literal-identity-comparison", "Bug Risk", "Use == to compare literal values.")
        self.generic_visit(node)

    def visit_Dict(self, node: ast.Dict) -> None:
        seen = set()
        for key in node.keys:
            if isinstance(key, ast.Constant):
                marker = (type(key.value), key.value)
                if marker in seen:
                    self.finding(key, "quality-duplicate-dict-key", "Bug Risk", "Remove the duplicate dictionary key.")
                seen.add(marker)
        pairs = {self.const_str(key): value for key, value in zip(node.keys, node.values) if self.const_str(key)}
        principal = pairs.get("Principal")
        if principal is not None and (self.const_str(principal) == "*" or (isinstance(principal, ast.Dict) and any(self.const_str(value) == "*" for value in principal.values))):
            self.finding(node, "boto3-public-bucket-policy", "Cloud Security Misconfiguration", "Review policies granting access to all principals.")
        action = pairs.get("Action")
        actions = action.elts if isinstance(action, (ast.List, ast.Tuple)) else [action]
        if action is not None and any(self.const_str(value) == "*" or self.const_str(value).endswith(":*") for value in actions):
            self.finding(node, "cloud-iam-wildcard-action", "Excessive Permissions", "Avoid wildcard IAM actions.")
        if "$where" in pairs and self.imports("pymongo", "motor", "mongoengine", "flask_pymongo", "mongomock"):
            self.finding(node, "mongodb-query-injection", "NoSQL Injection", "Avoid JavaScript $where queries.")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if self.name(node) in OLD_TLS:
            self.finding(node, "old-tls-protocol", "Insecure Transport", "Do not enable obsolete TLS versions.")
        self.generic_visit(node)

    def visit_JoinedStr(self, node: ast.JoinedStr) -> None:
        for value in node.values:
            if isinstance(value, ast.FormattedValue) and value.format_spec is not None:
                self.format_specs.add(id(value.format_spec))
        if not any(isinstance(value, ast.FormattedValue) for value in node.values):
            if id(node) not in self.format_specs:
                self.finding(node, "quality-fstring-without-placeholders", "Maintainability", "Remove the unnecessary f-string prefix.")
        else:
            self.check_dynamic_text(node, "fstring")
        self.generic_visit(node)

    def visit_BinOp(self, node: ast.BinOp) -> None:
        if id(node) not in self.inner_text_nodes and isinstance(node.op, (ast.Add, ast.Mod)) and not (isinstance(node.left, ast.Constant) and isinstance(node.right, ast.Constant)):
            for child in ast.walk(node.left):
                if isinstance(child, ast.BinOp):
                    self.inner_text_nodes.add(id(child))
            self.check_dynamic_text(node, "percent" if isinstance(node.op, ast.Mod) else "concatenation")
        if isinstance(node.op, ast.Mult) and (self.from_request(node.left) or self.from_request(node.right)):
            self.finding(node, "unbounded-loop-user-input", "Denial of Service", "Bound request-controlled output sizes.")
        self.generic_visit(node)

    def check_function_quality(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        arguments = node.args
        all_arguments = arguments.posonlyargs + arguments.args + arguments.kwonlyargs + [argument for argument in (arguments.vararg, arguments.kwarg) if argument]
        if len([argument for argument in arguments.posonlyargs + arguments.args + arguments.kwonlyargs if argument.arg not in ("self", "cls")]) > MAX_PARAMETERS:
            self.finding(node, "quality-too-many-parameters", "Maintainability", "Reduce the number of parameters.")
        for default in arguments.defaults + [value for value in arguments.kw_defaults if value is not None]:
            if isinstance(default, (ast.List, ast.Dict, ast.Set)) or (isinstance(default, ast.Call) and self.name(default.func) in ("list", "dict", "set")):
                self.finding(default, "quality-mutable-default-argument", "Bug Risk", "Do not use mutable default arguments.")
        for argument in all_arguments:
            if argument.arg in BUILTIN_NAMES:
                self.finding(argument, "quality-redefined-builtin", "Maintainability", "Avoid shadowing a built-in name.")
        if node.name in BUILTIN_NAMES:
            self.finding(node, "quality-redefined-builtin", "Maintainability", "Avoid shadowing a built-in name.")
        if node.end_lineno and node.end_lineno - node.lineno + 1 > MAX_FUNCTION_LINES:
            self.finding(node, "quality-long-function", "Maintainability", "Split long functions.")
        if self.complexity(node) > MAX_COMPLEXITY:
            self.finding(node, "quality-high-complexity", "Maintainability", "Reduce cyclomatic complexity.")
        self.check_nesting(node.body, 0)

    @staticmethod
    def complexity(function: ast.AST) -> int:
        count = 1
        stack = list(ast.iter_child_nodes(function))
        while stack:
            child = stack.pop()
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                continue
            if isinstance(child, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.IfExp, ast.ExceptHandler)) or (MATCH_CASE and isinstance(child, MATCH_CASE)):
                count += 1
            elif isinstance(child, ast.BoolOp):
                count += len(child.values) - 1
            elif isinstance(child, ast.comprehension):
                count += 1 + len(child.ifs)
            stack.extend(ast.iter_child_nodes(child))
        return count

    def check_nesting(self, statements: list, depth: int) -> bool:
        for statement in statements:
            if not isinstance(statement, COMPOUND):
                continue
            if depth + 1 > MAX_NESTING:
                self.finding(statement, "quality-deep-nesting", "Maintainability", "Reduce nesting depth.")
                return True
            is_elif = isinstance(statement, ast.If) and len(statement.orelse) == 1 and isinstance(statement.orelse[0], ast.If)
            blocks = [getattr(statement, "body", [])] + [handler.body for handler in getattr(statement, "handlers", [])] + [case.body for case in getattr(statement, "cases", [])] + [getattr(statement, "finalbody", [])]
            if not is_elif:
                blocks.append(getattr(statement, "orelse", []))
            if any(self.check_nesting(block, depth + 1) for block in blocks) or (is_elif and self.check_nesting(statement.orelse, depth)):
                return True
        return False

    def check_module(self, tree: ast.Module) -> None:
        for node in ast.walk(tree):
            for field in ("body", "orelse", "finalbody"):
                statements = getattr(node, field, None)
                if not isinstance(statements, list):
                    continue
                for index, statement in enumerate(statements[:-1]):
                    if isinstance(statement, (ast.Return, ast.Raise, ast.Continue, ast.Break)):
                        self.finding(statements[index + 1], "quality-unreachable-code", "Bug Risk", "Remove unreachable code.")
                        break
            if isinstance(node, ast.Try) or type(node).__name__ == "TryStar":
                for statement in node.finalbody:
                    if any(isinstance(child, ast.Return) for child in ast.walk(statement)):
                        self.finding(statement, "quality-return-in-finally", "Bug Risk", "Do not return from a finally block.")
        if self.path.endswith("__init__.py"):
            return
        imported = {}
        for statement in tree.body:
            if isinstance(statement, ast.Import):
                for alias in statement.names:
                    if alias.asname != alias.name:
                        imported[alias.asname or alias.name.split(".")[0]] = statement
            elif isinstance(statement, ast.ImportFrom) and statement.module != "__future__":
                for alias in statement.names:
                    if alias.name != "*" and alias.asname != alias.name:
                        imported[alias.asname or alias.name] = statement
        if not imported:
            return
        used = {child.id for child in ast.walk(tree) if isinstance(child, ast.Name)}
        strings = "\n".join(child.value for child in ast.walk(tree) if isinstance(child, ast.Constant) and isinstance(child.value, str))
        for imported_name, statement in imported.items():
            if imported_name not in used and not re.search(rf"\b{re.escape(imported_name)}\b", strings):
                self.finding(statement, "quality-unused-import", "Maintainability", "Remove unused imports.")

    def check_comment(self, line: int, column: int, text: str) -> None:
        if re.search(r"\b(?:TODO|FIXME|XXX|HACK)\b", text):
            self.finding(SimpleNamespace(lineno=line, col_offset=column), "quality-todo-comment", "Maintainability", "Resolve or track this TODO comment.")