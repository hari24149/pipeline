from __future__ import annotations

import bisect
import json
import os
import re
from pathlib import Path

from manage_rules import rule_pattern_sources

EXCLUDED = {".git", "node_modules", ".venv", "venv", "dist", "target"}
TEMPLATE_EXTENSIONS = frozenset({
    ".html", ".htm", ".xhtml", ".jsp", ".jspx", ".ejs", ".hbs", ".handlebars", ".vue", ".cshtml",
    ".php", ".twig", ".erb", ".ftl", ".svelte", ".njk", ".jinja", ".jinja2", ".j2",
})
CATEGORIES = ("Security", "Code Quality", "Accessibility")
RULES_PATH = Path(__file__).resolve().parent / "rules" / "html-local.json"


def load_rules(rules_path: Path) -> list:
    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    if not isinstance(rules, list) or not all(isinstance(rule, dict) for rule in rules):
        raise ValueError("HTML rules must be a list of rule objects")
    ids = [rule.get("id") for rule in rules]
    if not all(isinstance(rule_id, str) and rule_id for rule_id in ids) or len(ids) != len(set(ids)):
        raise ValueError("HTML rules must have unique non-empty IDs")
    compiled = []
    for rule in rules:
        if not isinstance(rule.get("enabled", True), bool):
            raise ValueError(f"HTML rule {rule['id']} has an invalid enabled value")
        if rule.get("enabled", True) is False:
            continue
        if not isinstance(rule.get("message"), str) or not rule["message"].strip():
            raise ValueError(f"HTML rule {rule['id']} needs a pattern and message")
        if rule.get("category", "Security") not in CATEGORIES:
            raise ValueError(f"HTML rule {rule['id']} has an unknown category")
        extensions = rule.get("extensions")
        if extensions is not None and (not isinstance(extensions, list) or not all(isinstance(item, str) and item.startswith(".") for item in extensions)):
            raise ValueError(f"HTML rule {rule['id']} has invalid extensions")
        flags = re.IGNORECASE if rule.get("ignore_case") else 0
        try:
            patterns = [re.compile(item, flags) for item in rule_pattern_sources(rule)]
        except (re.error, ValueError) as error:
            raise ValueError(f"HTML rule {rule['id']} has an invalid pattern: {error}") from error
        compiled.append((rule, patterns, {item.lower() for item in extensions} if extensions else None))
    return compiled


def scan_html(source: Path, rules_path: Path | None = None) -> dict:
    rules = load_rules(rules_path or RULES_PATH)
    report = {"engine": "local-html-patterns", "rules": len(rules), "results": [], "errors": [], "scanned_files": 0, "skipped_directories": [], "skipped_symlinks": 0, "decoding_replacements": 0}

    def fail_on_walk_error(error: OSError) -> None:
        raise error

    for directory, directories, filenames in os.walk(source, followlinks=False, onerror=fail_on_walk_error):
        root = Path(directory)
        report["skipped_symlinks"] += sum((root / name).is_symlink() for name in directories)
        report["skipped_directories"].extend((root / name).relative_to(source).as_posix() for name in directories if name in EXCLUDED)
        directories[:] = sorted(name for name in directories if name not in EXCLUDED and not (root / name).is_symlink())
        for name in sorted(filenames):
            path = root / name
            extension = path.suffix.lower()
            if extension not in TEMPLATE_EXTENSIONS:
                continue
            if path.is_symlink():
                report["skipped_symlinks"] += 1
                continue
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            report["decoding_replacements"] += text.count("\ufffd")
            report["scanned_files"] += 1
            report["results"].extend(scan_text(text, path.relative_to(source).as_posix(), extension, rules))
    return report


def scan_text(text: str, relative: str, extension: str, rules: list) -> list:
    starts = [0]
    for match in re.finditer(r"\r\n|\r|\n", text):
        starts.append(match.end())
    results, seen = [], set()
    for rule, patterns, extensions in rules:
        if extensions is not None and extension not in extensions:
            continue
        for pattern in patterns:
            for match in pattern.finditer(text):
                index = bisect.bisect_right(starts, match.start()) - 1
                if (rule["id"], index) in seen:
                    continue
                seen.add((rule["id"], index))
                line_start = starts[index]
                line_end = starts[index + 1] if index + 1 < len(starts) else len(text)
                source_line = text[line_start:line_end].splitlines()[0] if text[line_start:line_end] else ""
                highlights = []
                for item in patterns:
                    for found in item.finditer(text):
                        if found.start() < line_start or found.start() >= line_start + len(source_line):
                            continue
                        start = found.start() - line_start
                        end = min(found.end(), line_start + len(source_line)) - line_start
                        if end > start:
                            highlights.append([start, min(end, 4000)])
                        if len(highlights) == 5:
                            break
                    if len(highlights) == 5:
                        break
                category = rule.get("category", "Security")
                results.append({
                    "check_id": rule["id"], "path": relative,
                    "start": {"line": index + 1, "col": match.start() - line_start + 1},
                    "extra": {
                        "severity": rule.get("severity", "INFO" if category == "Code Quality" else "WARNING"),
                        "category": category, "issue_type": rule.get("issue_type", "Security review"),
                        "message": rule["message"], "lines": source_line[:4000] or "<empty source line>",
                        "highlights": highlights,
                    },
                })
    return results
