"use strict";

const fs = require("fs");
const path = require("path");
const { Linter } = require("eslint");
const jsxA11y = require("eslint-plugin-jsx-a11y");
const parser = require("@typescript-eslint/parser");
const { HtmlValidate } = require("html-validate");

const root = path.resolve(process.argv[2] || "");
const skipped = new Set([".git", "node_modules", ".venv", "venv", "dist", "target"]);
const extensions = new Set([".html", ".htm", ".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"]);
const unsupportedExtensions = new Set([".jsp", ".jspx", ".vue", ".svelte", ".erb", ".ejs", ".hbs", ".twig", ".cshtml", ".php"]);
const htmlRules = ["area-alt", "aria-hidden-body", "aria-label-misuse", "empty-heading", "empty-title", "input-missing-label", "meta-refresh", "no-autoplay", "no-redundant-role", "wcag/h30", "wcag/h32", "wcag/h36", "wcag/h37", "wcag/h63", "wcag/h67", "wcag/h71"];

function files(directory, unsupported, skippedDirectories) {
  const found = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory() && skipped.has(entry.name)) skippedDirectories.push(path.relative(root, full).split(path.sep).join("/"));
    else if (entry.isDirectory()) found.push(...files(full, unsupported, skippedDirectories));
    else if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) found.push(full);
    else if (entry.isFile() && unsupportedExtensions.has(path.extname(entry.name).toLowerCase())) unsupported.push(path.relative(root, full).split(path.sep).join("/"));
  }
  return found;
}

function scan() {
  if (!fs.statSync(root).isDirectory()) throw new Error("Repository path is not a directory");
  const linter = new Linter();
  linter.defineParser("typescript", parser);
  for (const [name, rule] of Object.entries(jsxA11y.rules)) linter.defineRule(`jsx-a11y/${name}`, rule);
  const validator = new HtmlValidate({ rules: Object.fromEntries(htmlRules.map((rule) => [rule, "error"])) });
  const report = { results: [], errors: [], scanned_files: 0, unsupported_templates: [], skipped_directories: [] };
  for (const file of files(root, report.unsupported_templates, report.skipped_directories)) {
    const content = fs.readFileSync(file, "utf8");
    const relative = path.relative(root, file).split(path.sep).join("/");
    const isHtml = /\.html?$/i.test(file);
    const messages = isHtml
      ? validator.validateString(content, relative).results.flatMap((result) => result.messages)
      : linter.verify(content, {
          parser: "typescript",
          parserOptions: { ecmaVersion: 2020, sourceType: "module", ecmaFeatures: { jsx: true } },
          rules: jsxA11y.configs.recommended.rules,
        }, { filename: file });
    const lines = content.split(/\r?\n/);
    let htmlTree;
    report.scanned_files += 1;
    for (const message of messages) {
      if (message.fatal || !message.ruleId || message.ruleId === "parser-error") {
        report.errors.push({ path: relative, line: message.line, message: message.message });
        continue;
      }
      let ruleId = message.ruleId;
      let description = message.message;
      let severity = message.severity === 2 ? "ERROR" : "WARNING";
      if (isHtml && message.selector && (ruleId === "wcag/h37" || ruleId === "input-missing-label")) {
        htmlTree = htmlTree || validator.getParserFor(relative).parseHtml(content);
        const element = htmlTree.querySelector(message.selector);
        const dynamicAlt = element && ["[alt]", "[attr.alt]", "bind-alt"].some((name) => element.hasAttribute(name));
        const dynamicLabel = element && ["[attr.aria-label]", "[aria-label]", "[attr.aria-labelledby]", "[aria-labelledby]"].some((name) => element.hasAttribute(name));
        if (ruleId === "wcag/h37" && dynamicAlt) {
          ruleId = "angular.dynamic-alt-review";
          description = "Angular binds the alt attribute dynamically; verify its rendered value is appropriate.";
          severity = "WARNING";
        } else if (ruleId === "input-missing-label" && dynamicLabel) {
          ruleId = "angular.dynamic-label-review";
          description = "Angular binds the accessible label dynamically; verify its rendered value is meaningful.";
          severity = "WARNING";
        }
      }
      report.results.push({
        check_id: `accessibility.${isHtml ? "html" : "jsx"}.${ruleId}`,
        path: relative,
        start: { line: message.line || 1, col: message.column || 1 },
        extra: { category: "Accessibility", severity, message: description, lines: lines[(message.line || 1) - 1] || "<empty source line>" },
      });
    }
  }
  return report;
}

try {
  process.stdout.write(JSON.stringify(scan()));
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}