from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path
from html_security import scan_html
from manage_rules import match_highlights, rule_pattern_sources
from python_security import scan_python

LANGUAGES = ("all", "java", "python", "javascript-typescript", "html")


def redact(line: str) -> str:
    return "[Sensitive source redacted; reference " + hashlib.sha256(line.encode("utf-8")).hexdigest() + "]"


def redact_shared_lines(results: list) -> None:
    redacted = {(result["path"], result["start"]["line"]): result["extra"]["lines"] for result in results if str(result.get("extra", {}).get("lines", "")).startswith("[Sensitive source redacted")}
    for result in results:
        key = (result["path"], result["start"]["line"])
        if key in redacted:
            result["extra"]["lines"] = redacted[key]


ISSUE_TYPES = {
    "local-java-runtime-command-concatenation": "Command Injection",
    "local-java-statement-query-concatenation": "SQL Injection",
    "local-java-weak-digest": "Weak Cryptography",
    "local-java-weak-cipher": "Weak Cryptography",
    "local-java-insecure-random": "Insecure Randomness",
    "local-angular-security-bypass": "Injection / XSS",
    "local-javascript-eval": "Code Injection",
    "local-javascript-innerhtml": "Cross-Site Scripting (XSS)",
}


def finding_rows(report: dict, suppressions: dict) -> tuple[list[dict], list[dict]]:
    if report.get("errors"):
        raise ValueError("Semgrep reported scan errors: " + json.dumps(report["errors"]))
    results = report.get("results")
    if not isinstance(results, list):
        raise ValueError("Semgrep did not return a valid results list")
    identities = []
    for result in results:
        extra = result.get("extra") or {}
        path = str(result.get("path", "")).replace("\\", "/")
        rule = str(result.get("check_id", ""))
        snippet = str(extra.get("lines", "")).strip()
        if not path or not rule or not snippet:
            raise ValueError("Semgrep finding is missing its rule, path, or source snippet")
        identities.append(json.dumps([rule, path, snippet], ensure_ascii=False))
    counts = Counter(identities)
    rows = []
    suppressed = []
    fingerprints = set()
    for result, identity in zip(results, identities):
        extra = result.get("extra") or {}
        path = str(result.get("path", "")).replace("\\", "/")
        rule = str(result.get("check_id", ""))
        location = result.get("start") or {}
        if counts[identity] > 1:
            identity += json.dumps([location.get("line"), location.get("col")])
        fingerprint = hashlib.sha256(identity.encode("utf-8")).hexdigest()
        if fingerprint in fingerprints:
            raise ValueError("Semgrep returned indistinguishable duplicate findings")
        fingerprints.add(fingerprint)
        row = {
            "fingerprint": fingerprint,
            "category": str(extra.get("category", "Security")),
            "issue_type": str(extra.get("issue_type") or ISSUE_TYPES.get(rule) or ("Accessibility" if extra.get("category") == "Accessibility" else "Security review")),
            "issue_name": str(extra.get("message", rule)),
            "rule_id": rule,
            "severity": str(extra.get("severity", "UNKNOWN")),
            "file_path": path,
            "line": location.get("line"),
            "source_code": str(extra.get("lines", ""))[:4000],
            "highlights": [
                [int(item[0]), int(item[1])]
                for item in (extra.get("highlights") or [])[:5]
                if isinstance(item, (list, tuple)) and len(item) == 2
            ],
            "occurrences": 1,
            "detection": "Detected",
            "status": "Open",
            "justification": "Awaiting review.",
            "solution": "Not Applicable",
        }
        if fingerprint in suppressions:
            row.update({key: value for key, value in suppressions[fingerprint].items() if key in ("status", "justification", "solution")})
            suppressed.append(row)
        else:
            rows.append(row)
    for index, row in enumerate(rows, 1):
        row["sr_no"] = index
    return rows, suppressed


def scan_java(source: Path, rules_path: Path | None = None, allow_empty: bool = False, include_java: bool = True) -> dict:
    rules_path = rules_path or Path(__file__).resolve().parent / "rules" / "java-local.json"
    rules = json.loads(rules_path.read_text(encoding="utf-8")) if include_java else []
    patterns = []
    for rule in rules:
        if rule.get("enabled", True) is False:
            continue
        try:
            compiled = [re.compile(item) for item in rule_pattern_sources(rule)]
        except re.error as error:
            raise ValueError(f"Java rule {rule.get('id')} has an invalid pattern: {error}") from error
        patterns.append((rule, compiled))
    report = {"engine": "local-java-patterns", "rules": len(patterns), "results": [], "errors": [], "scanned_files": 0, "script_files": 0, "skipped_symlinks": 0, "decoding_replacements": 0, "skipped_directories": []}

    def fail_on_walk_error(error: OSError) -> None:
        raise error

    for directory, directories, filenames in os.walk(source, followlinks=False, onerror=fail_on_walk_error):
        root = Path(directory)
        report["skipped_symlinks"] += sum((root / name).is_symlink() for name in directories)
        excluded = {".git", "node_modules", ".venv", "venv", "dist", "target"}
        report["skipped_directories"].extend((root / name).relative_to(source).as_posix() for name in directories if name in excluded)
        directories[:] = sorted(name for name in directories if name not in excluded and not (root / name).is_symlink())
        for name in sorted(filenames):
            path = root / name
            if path.suffix.lower() in (".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx") and not path.is_symlink():
                report["script_files"] += 1
            if not include_java:
                continue
            if path.suffix.lower() != ".java":
                continue
            if path.is_symlink():
                report["skipped_symlinks"] += 1
                continue
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            report["decoding_replacements"] += text.count("\ufffd")
            report["scanned_files"] += 1
            for line_number, line in enumerate(text.splitlines(), 1):
                is_comment = line.lstrip().startswith(("//", "*", "/*"))
                for rule, compiled in patterns:
                    if is_comment and not rule.get("include_comments"):
                        continue
                    highlights = match_highlights(line, compiled)
                    if highlights:
                        category = rule.get("category", "Security")
                        report["results"].append({
                            "check_id": rule["id"], "path": path.relative_to(source).as_posix(),
                            "start": {"line": line_number, "col": highlights[0][0] + 1},
                            "extra": {"severity": rule.get("severity", "INFO" if category == "Code Quality" else "WARNING"), "category": category, "message": rule["message"], "lines": line, "highlights": highlights, "issue_type": rule.get("issue_type")},
                        })
    if not report["scanned_files"] and not allow_empty:
        raise ValueError("No Java source files were scanned; the built-in security rules support Java only")
    return report


def scan(source: Path, output: Path, config: str, suppressions: dict, skip_accessibility: bool = False, accessibility_only: bool = False, language: str = "all", skip_quality: bool = False) -> None:
    source = source.resolve()
    if not source.is_dir():
        raise ValueError(f"Repository directory not found: {source}")
    if skip_accessibility and accessibility_only:
        raise ValueError("Accessibility-only and backend-only modes cannot be combined")
    if language not in LANGUAGES:
        raise ValueError(f"Unsupported security language: {language}")
    print(f"[STEP 1] Scanning security language: {language}..." if not accessibility_only else "[STEP 1] Security scan skipped (accessibility-only)", flush=True)
    if config:
        print("[WARN] The previous rules-file setting is ignored; the built-in local rules are used", flush=True)
    report = {"results": [], "errors": [], "scanned_files": 0, "skipped_symlinks": 0, "decoding_replacements": 0, "skipped": "accessibility-only"} if accessibility_only else scan_java(source, allow_empty=True, include_java=language in ("all", "java"))
    if not accessibility_only:
        report["selected_language"] = language
        if language not in ("all", "java"):
            report["java_skipped"] = "language selection"
        if language in ("all", "java"):
            print(f"[INFO] Scanned {report['scanned_files']} Java files with {report['rules']} limited rules", flush=True)
        else:
            print("[SKIPPED] Java security scan (language selection)", flush=True)
        python_report = scan_python(source) if language in ("all", "python") else {"scanned_files": 0, "results": [], "errors": [], "builtin_rules": 0, "custom_rules": 0, "defaulted_builtin_rules": [], "disabled_or_missing_builtin_rules": [], "unsupported_ast_rules": [], "skipped": "language selection"}
        if python_report["errors"]:
            raise ValueError("Python security scan errors: " + json.dumps(python_report["errors"]))
        if python_report["scanned_files"] and not (python_report["builtin_rules"] or python_report["custom_rules"]):
            raise ValueError("No implemented Python security rules are enabled; Python coverage is unavailable")
        report["python"] = {key: value for key, value in python_report.items() if key != "results"}
        report["results"].extend(python_report["results"])
        if language in ("all", "python"):
            print(f"[INFO] Scanned {python_report['scanned_files']} Python files with {python_report['builtin_rules']} built-in and {python_report['custom_rules']} custom rules", flush=True)
        else:
            print("[SKIPPED] Python security scan (language selection)", flush=True)
        if python_report["scanned_files"] and python_report["defaulted_builtin_rules"]:
            print(f"[INFO] Enabled {len(python_report['defaulted_builtin_rules'])} implemented Python defaults absent from the editable catalog; see security_report.json", flush=True)
        if python_report["scanned_files"] and python_report["disabled_or_missing_builtin_rules"]:
            print(f"[WARN] {len(python_report['disabled_or_missing_builtin_rules'])} built-in Python rules are disabled or missing; see security_report.json", flush=True)
        if python_report["scanned_files"] and python_report["unsupported_ast_rules"]:
            print(f"[WARN] Python coverage is INCOMPLETE: {len(python_report['unsupported_ast_rules'])} AST rules have no implemented checks and were NOT scanned; see security_report.json", flush=True)
        if report["script_files"] and language in ("all", "javascript-typescript"):
            try:
                script_scan = subprocess.run(["node", str(Path(__file__).with_name("script_security.js")), str(source)], capture_output=True, text=True, encoding="utf-8", errors="replace")
            except FileNotFoundError as exc:
                raise RuntimeError("Node.js is required for JavaScript/TypeScript security checks") from exc
            if script_scan.returncode:
                raise RuntimeError(f"JavaScript/TypeScript security scan failed ({script_scan.returncode}): {script_scan.stderr[-4000:]}")
            try:
                script_report = json.loads(script_scan.stdout)
            except json.JSONDecodeError as exc:
                raise ValueError("JavaScript/TypeScript security scanner returned invalid JSON") from exc
            if script_report.get("errors"):
                raise ValueError("JavaScript/TypeScript source could not be parsed; fix the listed syntax errors and rerun the scan: " + json.dumps(script_report["errors"]))
            report["scripts"] = {key: value for key, value in script_report.items() if key != "results"}
            report["results"].extend(script_report["results"])
            print(f"[INFO] Scanned {script_report['scanned_files']} JavaScript/TypeScript files with {script_report['builtin_rules']} built-in and {script_report['custom_rules']} custom rules", flush=True)
            if script_report["disabled_or_missing_builtin_rules"]:
                print(f"[WARN] {len(script_report['disabled_or_missing_builtin_rules'])} built-in JavaScript/TypeScript rules are disabled or missing; see security_report.json", flush=True)
        else:
            report["scripts"] = {"scanned_files": 0, "skipped": "language selection" if language not in ("all", "javascript-typescript") else "no supported script files"}
        if language in ("all", "html"):
            html_report = scan_html(source)
            report["html"] = {key: value for key, value in html_report.items() if key != "results"}
            report["results"].extend(html_report["results"])
            report["decoding_replacements"] += html_report["decoding_replacements"]
            print(f"[INFO] Scanned {html_report['scanned_files']} HTML/template files with {html_report['rules']} pattern rules", flush=True)
        else:
            report["html"] = {"scanned_files": 0, "skipped": "language selection"}
            print("[SKIPPED] HTML/template pattern scan (language selection)", flush=True)
        if not report["scanned_files"] and not report["scripts"]["scanned_files"] and not report["python"]["scanned_files"] and not report["html"]["scanned_files"]:
            raise ValueError(f"No supported source files were scanned for selected security language: {language}")
        if report["skipped_directories"]:
            print(f"[WARN] Skipped {len(report['skipped_directories'])} dependency, generated, or metadata directories; see security_report.json", flush=True)
    elif language in ("all", "html"):
        html_report = scan_html(source)
        report["html"] = {key: value for key, value in html_report.items() if key != "results"}
        report["results"].extend(html_report["results"])
        print(f"[INFO] Checked {html_report['scanned_files']} HTML/template files with accessibility pattern rules", flush=True)

    def wanted(result: dict) -> bool:
        category = (result.get("extra") or {}).get("category", "Security")
        if category == "Accessibility":
            return not skip_accessibility
        if category == "Code Quality":
            return not skip_quality and not accessibility_only
        return not accessibility_only

    report["results"] = [result for result in report["results"] if wanted(result)]
    redact_shared_lines(report["results"])
    report["code_quality"] = "skipped" if skip_quality or accessibility_only else "included"
    if skip_quality and not accessibility_only:
        print("[SKIPPED] Code quality checks (skip-quality)", flush=True)
    if report["skipped_symlinks"]:
        print(f"[WARN] Skipped {report['skipped_symlinks']} symbolic links", flush=True)
    if report["decoding_replacements"]:
        print(f"[WARN] {report['decoding_replacements']} characters could not be decoded as UTF-8", flush=True)
    if skip_accessibility:
        print("[SKIPPED] Accessibility scan (backend-only repository)", flush=True)
        accessibility_report = {"results": [], "errors": [], "scanned_files": 0, "skipped": "backend-only"}
    else:
        print("[STEP 2] Scanning accessibility...", flush=True)
        try:
            accessibility = subprocess.run(["node", str(Path(__file__).with_name("accessibility.js")), str(source)], capture_output=True, text=True, encoding="utf-8", errors="replace")
        except FileNotFoundError as exc:
            raise RuntimeError("Node.js is not installed or is not on PATH") from exc
        if accessibility.returncode:
            raise RuntimeError(f"Accessibility scan failed ({accessibility.returncode}): {accessibility.stderr[-4000:]}")
        try:
            accessibility_report = json.loads(accessibility.stdout)
        except json.JSONDecodeError as exc:
            raise ValueError("Accessibility scanner returned invalid JSON") from exc
        if accessibility_report.get("errors"):
            raise ValueError("Accessibility scan errors: " + json.dumps(accessibility_report["errors"]))
        print(f"[INFO] Accessibility checked {accessibility_report.get('scanned_files', 0)} HTML and script files", flush=True)
        unsupported = accessibility_report.get("unsupported_templates", [])
        if unsupported:
            print(f"[WARN] {len(unsupported)} template files were not accessibility-checked; see accessibility.json", flush=True)
        if accessibility_report.get("skipped_directories"):
            print(f"[WARN] Skipped {len(accessibility_report['skipped_directories'])} dependency, generated, or metadata directories; see accessibility.json", flush=True)
        if not accessibility_report.get("scanned_files"):
            print("[WARN] No supported accessibility source files were checked", flush=True)
    print("[STEP 3] Preparing findings...", flush=True)
    rows, suppressed = finding_rows({"results": report.get("results"), "errors": report.get("errors")}, suppressions)
    accessibility_rows, accessibility_suppressed = finding_rows(accessibility_report, suppressions)
    rows.extend(accessibility_rows)
    suppressed.extend(accessibility_suppressed)
    for index, row in enumerate(rows, 1):
        row["sr_no"] = index
    output.mkdir(parents=True, exist_ok=True)
    (output / "security_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "accessibility.json").write_text(json.dumps(accessibility_report, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "grouped_issues_with_ai.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "suppressed_findings.json").write_text(json.dumps(suppressed, indent=2, ensure_ascii=False), encoding="utf-8")
    print("[STEP 4] Exporting Excel report...", flush=True)
    export_excel(output)
    by_category = Counter(row.get("category", "Security") for row in rows)
    print("[INFO] Findings by category: " + ", ".join(f"{name} {by_category.get(name, 0)}" for name in ("Security", "Code Quality", "Accessibility")), flush=True)
    print(f"[INFO] {len(rows)} findings, {len(suppressed)} suppressed")


def export_excel(output: Path) -> Path:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "sast_triage"))
    from Sast.excel_export import export_sast_excel
    from openpyxl import load_workbook
    rows = json.loads((output / "grouped_issues_with_ai.json").read_text(encoding="utf-8"))
    path = export_sast_excel(output)
    workbook = load_workbook(path)
    sheet = workbook.active
    sheet.cell(1, 2, f"Finding {output.name}")
    for column, (heading, key) in enumerate((("File", "file_path"), ("Line", "line"), ("Current scan", "detection"), ("Source", "source_code"), ("Category", "category"), ("Issue type", "issue_type")), 9):
        sheet.cell(1, column, heading)
        for index, row in enumerate(rows, 2):
            sheet.cell(index, column, row.get(key))
        sheet.column_dimensions[sheet.cell(1, column).column_letter].width = 45 if key in ("file_path", "source_code") else 20
    for row in sheet.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith(("=", "+", "-", "@", "\t", "\r")):
                cell.value = "'" + cell.value
    sheet.auto_filter.ref = sheet.dimensions
    workbook.save(path)
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan a local repository with built-in security rules")
    parser.add_argument("--source-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--config", default="", help=argparse.SUPPRESS)
    parser.add_argument("--suppressions")
    parser.add_argument("--skip-accessibility", action="store_true", help="Skip accessibility checks for a backend-only repository")
    parser.add_argument("--accessibility-only", action="store_true", help="Skip security checks and scan accessibility only")
    parser.add_argument("--language", choices=LANGUAGES, default="all", help="Security language to scan (default: all)")
    parser.add_argument("--skip-quality", action="store_true", help="Skip Sonar-style code quality checks")
    args = parser.parse_args()
    try:
        suppressions = json.loads(Path(args.suppressions).read_text(encoding="utf-8")) if args.suppressions and Path(args.suppressions).exists() else {}
        scan(Path(args.source_dir), Path(args.output_dir), args.config, suppressions, skip_accessibility=args.skip_accessibility, accessibility_only=args.accessibility_only, language=args.language, skip_quality=args.skip_quality)
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())