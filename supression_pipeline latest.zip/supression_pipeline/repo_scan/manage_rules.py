from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parent / "rules" / "java-local.json"
PYTHON_RULES_PATH = Path(__file__).resolve().parent / "rules" / "python-local.json"
TYPESCRIPT_RULES_PATH = Path(__file__).resolve().parent / "rules" / "typescript-local.json"
HTML_RULES_PATH = Path(__file__).resolve().parent / "rules" / "html-local.json"
CATEGORIES = ("Security", "Code Quality", "Accessibility")
SEVERITIES = ("CRITICAL", "MAJOR", "MINOR", "WARNING", "INFO")


@contextmanager
def rules_lock(path: Path):
    with path.with_suffix(path.suffix + ".lock").open("a+b") as lock:
        if os.name == "nt":
            import msvcrt
            lock.seek(0)
            if not lock.read(1):
                lock.write(b"0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def rule_pattern_sources(rule: dict) -> list[str]:
    raw = rule.get("patterns")
    if isinstance(raw, list) and raw:
        sources = raw
    elif isinstance(rule.get("pattern"), str) and rule["pattern"]:
        sources = [rule["pattern"]]
    else:
        raise ValueError(f"Rule {rule.get('id', '')} needs a pattern or a list of patterns")
    if not all(isinstance(item, str) and item for item in sources):
        raise ValueError(f"Rule {rule.get('id', '')} has an invalid pattern list")
    return sources


def match_highlights(line: str, expressions, limit: int = 5) -> list[list[int]]:
    """Return up to five match ranges so the UI can color the matched code."""
    spans: list[list[int]] = []
    for expression in expressions:
        for found in expression.finditer(line):
            if found.end() > found.start():
                spans.append([found.start(), found.end()])
            if len(spans) >= limit:
                return spans[:limit]
    return spans


def _pattern_lines(value: str | list[str]) -> list[str]:
    if isinstance(value, str):
        return [line.strip() for line in value.splitlines() if line.strip()]
    return [str(item).strip() for item in value if str(item).strip()]


def _is_specific_ipv4(pattern: str) -> bool:
    candidate = pattern.strip()
    if candidate.startswith(r"\b"):
        candidate = candidate[2:]
    if candidate.endswith(r"\b"):
        candidate = candidate[:-2]
    candidate = candidate.strip("^$").replace(r"\.", ".")
    return re.fullmatch(r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?:\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)){3}", candidate) is not None


def add_rule(rule_id: str, patterns: str | list[str], message: str, match_example: str, nonmatch_example: str, path: Path = RULES_PATH, issue_type: str = "Security review", include_literal: bool = False, category: str = "Security", severity: str = "WARNING", redact: bool = False, include_comments: bool = False) -> dict:
    del include_literal
    rule_id, message = rule_id.strip(), message.strip()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,79}", rule_id):
        raise ValueError("Rule ID must be 1-80 lowercase letters, digits, hyphens or underscores")
    pattern_list = _pattern_lines(patterns)
    if not pattern_list or len(pattern_list) > 30:
        raise ValueError("Enter 1-30 regex patterns, one per line, for this issue type")
    if any(len(item) > 300 for item in pattern_list):
        raise ValueError("Each pattern must be at most 300 characters")
    if len(set(pattern_list)) != len(pattern_list):
        raise ValueError("Duplicate patterns are not allowed in the same rule")
    if not message or len(message) > 1000:
        raise ValueError("Finding message must be 1-1000 characters")
    issue_type = issue_type.strip() or "Security review"
    if len(issue_type) > 100:
        raise ValueError("Issue type must be at most 100 characters")
    if category not in CATEGORIES:
        raise ValueError(f"Category must be one of {', '.join(CATEGORIES)}")
    severity = severity.strip().upper() or "WARNING"
    if severity not in SEVERITIES:
        raise ValueError(f"Severity must be one of {', '.join(SEVERITIES)}")
    match_lines = [line for line in match_example.splitlines() if line.strip()]
    nonmatch_lines = [line for line in nonmatch_example.splitlines() if line.strip()]
    if not match_lines:
        raise ValueError("Provide a matching source example for every pattern")
    if not nonmatch_lines:
        raise ValueError("Provide a non-matching source example")
    compiled = []
    for pattern in pattern_list:
        if _is_specific_ipv4(pattern):
            raise ValueError("Do not add a specific IP address. Add an IP pattern for this issue type")
        if re.fullmatch(r"(?i)(?:password|passwd|pwd|secret|token)\d*", pattern):
            raise ValueError("Do not add a specific password or secret. Add a pattern for this issue type")
        if re.fullmatch(r"\s*(?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER)\b[^\\\[\]|+?{}]*", pattern, re.IGNORECASE):
            raise ValueError("Do not add a specific SQL statement. Add the query patterns for this issue type, one per line")
        try:
            expression = re.compile(pattern)
        except re.error as error:
            raise ValueError(f"Invalid regex pattern: {pattern} ({error})") from error
        if expression.search(""):
            raise ValueError(f"Pattern is too broad: {pattern}")
        if not any(expression.search(example) for example in match_lines):
            raise ValueError(f"Matching example must match pattern: {pattern}")
        if any(expression.search(example) for example in nonmatch_lines):
            raise ValueError(f"Non-matching example must not match pattern: {pattern}")
        compiled.append(expression)
    del compiled
    rule = {
        "id": rule_id,
        "patterns": pattern_list,
        "pattern": pattern_list[0] if len(pattern_list) == 1 else "(?:" + ")|(?:".join(pattern_list) + ")",
        "message": message,
        "issue_type": issue_type,
        "category": category,
        "severity": severity,
    }
    if redact:
        rule["redact"] = True
    if include_comments:
        rule["include_comments"] = True
    with rules_lock(path):
        rules = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(rules, list) or not all(isinstance(item, dict) for item in rules):
            raise ValueError("Existing rule file must contain a list of rules")
        if any(item.get("id") == rule_id for item in rules):
            raise ValueError(f"Rule ID already exists: {rule_id}")
        rules.append(rule)
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as temp:
                temp_path = Path(temp.name)
                json.dump(rules, temp, indent=2, ensure_ascii=False)
                temp.write("\n")
            os.replace(temp_path, path)
        finally:
            if temp_path and temp_path.exists():
                temp_path.unlink()
    return rule


def main() -> int:
    parser = argparse.ArgumentParser(description="Add a tested local Java, Python, TypeScript or HTML rule")
    parser.add_argument("--id", required=True)
    parser.add_argument("--patterns", required=True, help="One regular expression per line for the same issue type")
    parser.add_argument("--message", required=True)
    parser.add_argument("--match-example", required=True)
    parser.add_argument("--nonmatch-example", required=True)
    parser.add_argument("--language", choices=("java", "python", "typescript", "html"), default="java")
    parser.add_argument("--issue-type", default="Security review")
    parser.add_argument("--category", choices=CATEGORIES, default="Security")
    parser.add_argument("--severity", choices=SEVERITIES, default="WARNING")
    parser.add_argument("--redact", action="store_true")
    parser.add_argument("--include-comments", action="store_true")
    args = parser.parse_args()
    try:
        print("[STEP 1] Validating rule examples...", flush=True)
        reserved = ("local-python-", "local-javascript-", "local-angular-", "local-html-", "local-java-")
        if args.id.strip().startswith(reserved):
            raise ValueError("Rule ID uses a prefix reserved for built-in checks")
        paths = {"java": RULES_PATH, "python": PYTHON_RULES_PATH, "typescript": TYPESCRIPT_RULES_PATH, "html": HTML_RULES_PATH}
        rule = add_rule(args.id, args.patterns, args.message, args.match_example, args.nonmatch_example, path=paths[args.language], issue_type=args.issue_type, category=args.category, severity=args.severity, redact=args.redact, include_comments=args.include_comments)
        print("[STEP 2] Local security rules updated", flush=True)
        print(f"[INFO] Added {rule['id']} | {rule['category']} | {rule['issue_type']} | {rule['severity']} | {len(rule['patterns'])} pattern(s)")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())