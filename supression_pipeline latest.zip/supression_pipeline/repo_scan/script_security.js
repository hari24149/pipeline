"use strict";

const fs = require("fs");
const path = require("path");
const net = require("net");
const ts = require("typescript");

const root = path.resolve(process.argv[2] || "");
const skipped = new Set([".git", "node_modules", ".venv", "venv", "dist", "target"]);
const extensions = new Set([".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"]);
const bypassMethods = new Set(["bypassSecurityTrustHtml", "bypassSecurityTrustScript", "bypassSecurityTrustStyle", "bypassSecurityTrustUrl", "bypassSecurityTrustResourceUrl"]);
const report = { engine: "local-typescript-ast", results: [], errors: [], scanned_files: 0, skipped_directories: [] };
const rulesPath = process.argv[3] || path.join(__dirname, "rules", "typescript-local.json");
let customRules;
let builtinRules;
const builtinIds = new Set([
  "local-angular-security-bypass", "local-javascript-eval", "local-javascript-innerhtml", "local-javascript-outerhtml",
  "local-javascript-html-insertion", "local-javascript-dangerous-jsx-html", "local-javascript-shell-exec", "local-javascript-shell-option",
  "local-javascript-dynamic-query", "local-javascript-weak-hash", "local-javascript-deprecated-cipher", "local-javascript-weak-cipher",
  "local-javascript-vm-execution", "local-javascript-string-timer", "local-javascript-function-constructor", "local-javascript-disabled-tls",
  "local-javascript-insecure-tls-option", "local-javascript-wildcard-postmessage",
  "local-javascript-unsafe-buffer", "local-javascript-buffer-user-size", "local-javascript-large-body-limit", "local-javascript-unbounded-upload",
  "local-javascript-cors-wildcard", "local-javascript-weak-csp", "local-javascript-header-injection", "local-javascript-insecure-cookie",
  "local-javascript-hardcoded-jwt-secret", "local-javascript-jwt-none-algorithm", "local-javascript-jwt-no-algorithms", "local-javascript-path-traversal",
  "local-javascript-open-redirect", "local-javascript-ssrf", "local-javascript-cleartext-request", "local-javascript-nosql-injection",
  "local-javascript-command-user-input", "local-javascript-regex-user-input", "local-javascript-catastrophic-regex", "local-javascript-prototype-pollution",
  "local-javascript-insecure-random", "local-javascript-sensitive-storage", "local-javascript-sensitive-logging", "local-javascript-ip-logging",
  "local-javascript-url-logging", "local-javascript-log-injection", "local-javascript-xxe", "local-javascript-unsafe-deserialization",
  "local-javascript-template-injection", "local-javascript-bind-all-interfaces", "local-javascript-stack-trace-exposure", "local-javascript-reflected-xss",
  "local-javascript-weak-tls", "local-javascript-hardcoded-credential", "local-javascript-hardcoded-ip",
  "local-javascript-quality-debugger", "local-javascript-quality-empty-catch", "local-javascript-quality-loose-equality", "local-javascript-quality-var-declaration",
  "local-javascript-quality-alert", "local-javascript-quality-too-many-parameters", "local-javascript-quality-long-function", "local-javascript-quality-high-complexity",
  "local-javascript-quality-deep-nesting", "local-javascript-quality-unreachable-code", "local-javascript-quality-duplicate-key", "local-javascript-quality-nested-ternary",
  "local-javascript-quality-self-assignment", "local-javascript-quality-todo-comment",
]);
const MAX_BODY_BYTES = 1024 * 1024;
const MAX_PARAMETERS = 7;
const MAX_FUNCTION_LINES = 100;
const MAX_COMPLEXITY = 15;
const MAX_NESTING = 4;
const NESTED_QUANTIFIER = /\(((?:[^()\\]|\\.)*)\)(?:[+*]|\{\d+,\d*\})/g;
function catastrophicRegex(pattern) {
  for (const match of String(pattern).matchAll(NESTED_QUANTIFIER)) {
    if (/(?<!\\)[+*]/.test(match[1]) && /(?<!\\)[+*?}]$/.test(match[1])) return true;
  }
  return false;
}
const CREDENTIAL_NAME = /(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret|private[_-]?key)$/i;
const SENSITIVE_NAME = /(?:password|passwd|pwd|secret|token|api[_-]?key|authorization|credential)/i;
const IP_NAME = /^(?:ip|IP)$|^ip[A-Z_]|[a-z0-9]I[pP]$|_ip$|[iI]p_?[aA]ddress$|remoteAddress$|[fF]orwardedFor$/;
const URL_NAME = /(?:url|uri|href)$/i;
const REQUEST_PROPERTY = /(?:^|\.)(?:req|request)\.(?:query|params|body|headers|cookies|files|file)$/;

function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    const relative = path.relative(root, full).split(path.sep).join("/");
    if (entry.isDirectory()) {
      if (skipped.has(entry.name)) report.skipped_directories.push(relative);
      else walk(full);
    } else if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) {
      scanFile(full, relative);
    }
  }
}

function scanFile(file, relative) {
  const content = fs.readFileSync(file, "utf8");
  const extension = path.extname(file).toLowerCase();
  const kind = extension === ".tsx" ? ts.ScriptKind.TSX : extension === ".jsx" ? ts.ScriptKind.JSX : [".js", ".mjs", ".cjs"].includes(extension) ? ts.ScriptKind.JS : ts.ScriptKind.TS;
  const source = ts.createSourceFile(file, content, ts.ScriptTarget.Latest, true, kind);
  report.scanned_files += 1;
  const seenDiagnostics = new Set();
  for (const diagnostic of source.parseDiagnostics) {
    const location = source.getLineAndCharacterOfPosition(diagnostic.start || 0);
    const error = { path: relative, line: location.line + 1, message: ts.flattenDiagnosticMessageText(diagnostic.messageText, " ") };
    const key = JSON.stringify(error);
    if (!seenDiagnostics.has(key)) {
      seenDiagnostics.add(key);
      report.errors.push(error);
    }
  }
  const lines = content.split(/\r?\n/);
  const aliases = new Map();
  for (const statement of source.statements) {
    if (ts.isImportDeclaration(statement) && ts.isStringLiteral(statement.moduleSpecifier)) {
      const moduleName = statement.moduleSpecifier.text.replace(/^node:/, "");
      const clause = statement.importClause;
      if (clause && clause.name) aliases.set(clause.name.text, moduleName);
      if (clause && clause.namedBindings && ts.isNamespaceImport(clause.namedBindings)) aliases.set(clause.namedBindings.name.text, moduleName);
      if (clause && clause.namedBindings && ts.isNamedImports(clause.namedBindings)) {
        for (const item of clause.namedBindings.elements) aliases.set(item.name.text, `${moduleName}.${(item.propertyName || item.name).text}`);
      }
    }
    if (ts.isVariableStatement(statement)) {
      for (const declaration of statement.declarationList.declarations) {
        const init = declaration.initializer;
        if (!init || !ts.isCallExpression(init) || !ts.isIdentifier(init.expression) || init.expression.text !== "require" || !init.arguments[0] || !ts.isStringLiteral(init.arguments[0])) continue;
        const moduleName = init.arguments[0].text.replace(/^node:/, "");
        if (ts.isIdentifier(declaration.name)) aliases.set(declaration.name.text, moduleName);
        if (ts.isObjectBindingPattern(declaration.name)) {
          for (const element of declaration.name.elements) {
            if (ts.isIdentifier(element.name)) aliases.set(element.name.text, `${moduleName}.${element.propertyName ? element.propertyName.getText(source) : element.name.text}`);
          }
        }
      }
    }
  }
  function qualified(node) {
    if (ts.isIdentifier(node)) return aliases.get(node.text) || node.text;
    if (ts.isPropertyAccessExpression(node)) return `${qualified(node.expression)}.${node.name.text}`;
    return "";
  }
  function dynamicString(node) {
    return !!node && (ts.isTemplateExpression(node) || (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.PlusToken));
  }
  const tainted = new Set();
  function fromRequest(node) {
    let found = false;
    (function walk(child) {
      if (found || !child) return;
      if (ts.isPropertyAccessExpression(child) && REQUEST_PROPERTY.test(child.getText(source).replace(/\s+/g, ""))) found = true;
      else if (ts.isIdentifier(child) && tainted.has(child.text) && !(ts.isPropertyAccessExpression(child.parent) && child.parent.name === child) && !(ts.isPropertyAssignment(child.parent) && child.parent.name === child)) found = true;
      else ts.forEachChild(child, walk);
    })(node);
    return found;
  }
  for (let pass = 0; pass < 2; pass += 1) {
    (function collect(node) {
      if (ts.isVariableDeclaration(node) && node.initializer && fromRequest(node.initializer)) {
        if (ts.isIdentifier(node.name)) tainted.add(node.name.text);
        else if (ts.isObjectBindingPattern(node.name) || ts.isArrayBindingPattern(node.name)) {
          for (const element of node.name.elements) if (ts.isBindingElement(element) && ts.isIdentifier(element.name)) tainted.add(element.name.text);
        }
      }
      if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isIdentifier(node.left) && fromRequest(node.right)) tainted.add(node.left.text);
      ts.forEachChild(node, collect);
    })(source);
  }
  function stringValue(node) {
    return node && (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) ? node.text : null;
  }
  function propertyName(property) {
    return property && property.name ? property.name.getText(source).replace(/['"`]/g, "") : "";
  }
  function objectProperty(object, name) {
    if (!object || !ts.isObjectLiteralExpression(object)) return undefined;
    const property = object.properties.find((item) => ts.isPropertyAssignment(item) && propertyName(item) === name);
    return property ? property.initializer : undefined;
  }
  function sizeInBytes(value) {
    const match = /^\s*(\d+(?:\.\d+)?)\s*(b|kb|mb|gb)?\s*$/i.exec(value);
    return match ? Number(match[1]) * { b: 1, kb: 1024, mb: 1024 ** 2, gb: 1024 ** 3 }[(match[2] || "b").toLowerCase()] : null;
  }
  function literalIp(value) {
    const candidate = String(value).trim().replace(/^(\d{1,3}(?:\.\d{1,3}){3}):\d{1,5}$/, "$1");
    return net.isIP(candidate) !== 0 && !/^(?:127\.|0\.0\.0\.0$)/.test(candidate) && !["::1", "::"].includes(candidate);
  }
  function namesAndStrings(nodes) {
    const names = [];
    const strings = [];
    for (const node of nodes) {
      (function walk(child) {
        if (ts.isIdentifier(child)) names.push(child.text);
        else if (ts.isPropertyAccessExpression(child)) names.push(child.getText(source).replace(/\s+/g, ""));
        if ([ts.SyntaxKind.StringLiteral, ts.SyntaxKind.NoSubstitutionTemplateLiteral, ts.SyntaxKind.TemplateHead, ts.SyntaxKind.TemplateMiddle, ts.SyntaxKind.TemplateTail].includes(child.kind)) strings.push(child.text);
        ts.forEachChild(child, walk);
      })(node);
    }
    return { names, strings };
  }
  function insecureCookie(options) {
    if (!options || !ts.isObjectLiteralExpression(options)) return false;
    const httpOnly = objectProperty(options, "httpOnly");
    const secure = objectProperty(options, "secure");
    const sameSite = objectProperty(options, "sameSite");
    return (httpOnly && httpOnly.kind === ts.SyntaxKind.FalseKeyword) || (secure && secure.kind === ts.SyntaxKind.FalseKeyword) || (stringValue(sameSite) || "").toLowerCase() === "none";
  }
  function complexity(fn) {
    let count = 1;
    (function walk(child) {
      if (child !== fn && ts.isFunctionLike(child)) return;
      if ([ts.SyntaxKind.IfStatement, ts.SyntaxKind.ConditionalExpression, ts.SyntaxKind.ForStatement, ts.SyntaxKind.ForInStatement, ts.SyntaxKind.ForOfStatement, ts.SyntaxKind.WhileStatement, ts.SyntaxKind.DoStatement, ts.SyntaxKind.CaseClause, ts.SyntaxKind.CatchClause].includes(child.kind)) count += 1;
      if (ts.isBinaryExpression(child) && [ts.SyntaxKind.AmpersandAmpersandToken, ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken].includes(child.operatorToken.kind)) count += 1;
      ts.forEachChild(child, walk);
    })(fn);
    return count;
  }
  function tooDeep(fn) {
    let found = false;
    const nesting = [ts.SyntaxKind.IfStatement, ts.SyntaxKind.ForStatement, ts.SyntaxKind.ForInStatement, ts.SyntaxKind.ForOfStatement, ts.SyntaxKind.WhileStatement, ts.SyntaxKind.DoStatement, ts.SyntaxKind.SwitchStatement, ts.SyntaxKind.TryStatement];
    (function walk(child, depth) {
      if (found || (child !== fn && ts.isFunctionLike(child))) return;
      let next = depth;
      if (nesting.includes(child.kind) && !(ts.isIfStatement(child) && ts.isIfStatement(child.parent) && child.parent.elseStatement === child)) {
        next = depth + 1;
        if (next > MAX_NESTING) {
          found = true;
          return;
        }
      }
      ts.forEachChild(child, (grandchild) => walk(grandchild, next));
    })(fn, 0);
    return found;
  }
  function finding(node, id, message, issueType, redact) {
    const rule = builtinRules.get(id);
    if (!rule) return;
    const startPos = node.getStart(source);
    const location = source.getLineAndCharacterOfPosition(startPos);
    const category = rule.category || (id.includes("-quality-") ? "Code Quality" : "Security");
    const lineText = lines[location.line] || "<empty source line>";
    const highlights = [];
    if (typeof node.getEnd === "function" && lines[location.line]) {
      const lineStart = source.getPositionOfLineAndCharacter(location.line, 0);
      const end = Math.min(node.getEnd(), lineStart + lines[location.line].length);
      const start = Math.max(startPos, lineStart);
      if (end > start) highlights.push([start - lineStart, end - lineStart]);
    }
    report.results.push({ check_id: id, path: relative, start: { line: location.line + 1, col: location.character + 1 }, extra: { severity: rule.severity || (category === "Code Quality" ? "INFO" : "WARNING"), category, message: rule.message, issue_type: rule.issue_type, lines: lineText, highlights, redact: Boolean(redact) } });
  }
  function checkExtended(node) {
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      const name = qualified(node.expression);
      const method = ts.isPropertyAccessExpression(node.expression) ? node.expression.name.text : ts.isIdentifier(node.expression) ? node.expression.text : "";
      const receiver = ts.isPropertyAccessExpression(node.expression) ? node.expression.expression.getText(source).replace(/\s+/g, "") : "";
      const args = node.arguments ? [...node.arguments] : [];
      const first = args[0];
      const isResponse = /^(?:res|response|reply|ctx)$/.test(receiver);
      if (["Buffer.allocUnsafe", "Buffer.allocUnsafeSlow"].includes(name) || name === "Buffer") finding(node, "local-javascript-unsafe-buffer");
      if (["Buffer.alloc", "Buffer.allocUnsafe", "Buffer.allocUnsafeSlow", "Buffer"].includes(name) && first && fromRequest(first)) finding(node, "local-javascript-buffer-user-size");
      if (/(?:^|\.)(?:express|body-parser|bodyParser)\.(?:json|urlencoded|raw|text)$/.test(name)) {
        const limit = objectProperty(first, "limit");
        const size = !limit ? null : stringValue(limit) !== null ? sizeInBytes(stringValue(limit)) : ts.isNumericLiteral(limit) ? Number(limit.text) : ts.isIdentifier(limit) && limit.text === "Infinity" ? Infinity : null;
        if (size !== null && size > MAX_BODY_BYTES) finding(node, "local-javascript-large-body-limit");
      }
      if (name === "multer" && (!first || (ts.isObjectLiteralExpression(first) && objectProperty(first, "limits") === undefined))) finding(node, "local-javascript-unbounded-upload");
      if (["header", "setHeader", "set", "append", "writeHead"].includes(method) && args.length > 1) {
        const header = (stringValue(first) || "").toLowerCase();
        const value = stringValue(args[1]) || "";
        if (header === "access-control-allow-origin" && value.trim() === "*") finding(node, "local-javascript-cors-wildcard");
        if (header === "content-security-policy" && /'unsafe-(?:inline|eval)'/.test(value)) finding(node, "local-javascript-weak-csp");
        if ((isResponse || ["setHeader", "header"].includes(method)) && fromRequest(args[1])) finding(node, "local-javascript-header-injection");
      }
      if (name === "cors" && (!first || (ts.isObjectLiteralExpression(first) && (() => { const origin = objectProperty(first, "origin"); return !origin || stringValue(origin) === "*" || origin.kind === ts.SyntaxKind.TrueKeyword; })()))) finding(node, "local-javascript-cors-wildcard");
      if ((method === "cookie" && isResponse && insecureCookie(args[2])) || (/(?:express-session|cookie-session)$/.test(name) && (insecureCookie(first) || insecureCookie(objectProperty(first, "cookie"))))) finding(node, "local-javascript-insecure-cookie");
      if (/^jsonwebtoken\.(?:sign|verify)$/.test(name)) {
        if (stringValue(args[1])) finding(node, "local-javascript-hardcoded-jwt-secret", undefined, undefined, true);
        const options = args[2];
        const algorithms = objectProperty(options, "algorithms") || objectProperty(options, "algorithm");
        const values = algorithms && ts.isArrayLiteralExpression(algorithms) ? algorithms.elements : algorithms ? [algorithms] : [];
        if (values.some((value) => (stringValue(value) || "").toLowerCase() === "none")) finding(node, "local-javascript-jwt-none-algorithm");
        if (name.endsWith(".verify") && (!options || (ts.isObjectLiteralExpression(options) && !objectProperty(options, "algorithms")))) finding(node, "local-javascript-jwt-no-algorithms");
      }
      const fileCall = /^(?:fs|fs\/promises|fs-extra|graceful-fs)\.(?:promises\.)?\w+$/.test(name) || ["path.join", "path.resolve"].includes(name) || (["sendFile", "download", "attachment"].includes(method) && isResponse);
      if (fileCall && args.some(fromRequest)) finding(node, "local-javascript-path-traversal");
      if (method === "redirect" && isResponse && args.some(fromRequest)) finding(node, "local-javascript-open-redirect");
      const httpCall = /^(?:axios|node-fetch|got|needle|superagent|request|undici)(?:\.\w+)?$/.test(name) || name === "fetch" || /^https?\.(?:get|request)$/.test(name);
      if (httpCall && args.slice(0, 2).some(fromRequest)) finding(node, "local-javascript-ssrf");
      const url = stringValue(first) || "";
      if ((httpCall || (["get", "post", "put", "patch", "delete", "request"].includes(method) && /(?:^|\.)http(?:Client)?$/.test(receiver))) && /^http:\/\//i.test(url) && !/^http:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?:[:/]|$)/i.test(url)) finding(node, "local-javascript-cleartext-request");
      if (["find", "findOne", "findOneAndUpdate", "findOneAndDelete", "updateOne", "updateMany", "deleteOne", "deleteMany", "countDocuments", "aggregate", "where"].includes(method) && first && !ts.isArrowFunction(first) && !ts.isFunctionExpression(first) && fromRequest(first)) finding(node, "local-javascript-nosql-injection");
      if (/^child_process\.(?:spawn|spawnSync|execFile|execFileSync|fork|exec|execSync)$/.test(name) && args.some(fromRequest)) finding(node, "local-javascript-command-user-input");
      if (name === "RegExp" && first) {
        if (fromRequest(first)) finding(node, "local-javascript-regex-user-input");
        if (catastrophicRegex(stringValue(first) || "")) finding(node, "local-javascript-catastrophic-regex");
      }
      const lodashLike = /^(?:_|lodash|underscore)$/.test(receiver) || /^(?:lodash|underscore)\./.test(name);
      if ((["merge", "mergeWith", "defaultsDeep", "extend"].includes(method) || (lodashLike && ["set", "setWith", "zipObjectDeep"].includes(method)) || ["deepmerge", "deep-extend", "merge", "defaults-deep"].includes(name)) && args.some(fromRequest)) finding(node, "local-javascript-prototype-pollution");
      if (name === "Math.random") finding(node, "local-javascript-insecure-random");
      if (/^(?:window\.)?(?:localStorage|sessionStorage)\.setItem$/.test(name) && /password|passwd|secret|token|jwt|api[_-]?key|auth|credential/i.test(stringValue(first) || "")) finding(node, "local-javascript-sensitive-storage", undefined, undefined, true);
      const isLogging = /^console\.(?:log|info|warn|error|debug|trace)$/.test(name) || (/(?:^|\.)(?:logger|log|LOGGER|LOG)$/.test(receiver) && ["log", "info", "warn", "error", "debug", "trace", "fatal"].includes(method));
      if (isLogging && args.length) {
        const { names, strings } = namesAndStrings(args);
        const shortNames = names.map((value) => value.split(".").pop());
        if (shortNames.some((value) => SENSITIVE_NAME.test(value) && !/^(?:tokens?Count|tokenize\w*)$/i.test(value))) finding(node, "local-javascript-sensitive-logging", undefined, undefined, true);
        if (shortNames.some((value) => IP_NAME.test(value)) || strings.some((value) => value.split(/[\s,;'"`()]+/).some(literalIp))) finding(node, "local-javascript-ip-logging", undefined, undefined, true);
        if (shortNames.some((value) => URL_NAME.test(value)) || strings.some((value) => /https?:\/\//i.test(value))) finding(node, "local-javascript-url-logging", undefined, undefined, true);
        if (args.some(fromRequest)) finding(node, "local-javascript-log-injection");
      }
      if (/^libxmljs2?\.parseXml(?:String)?$/.test(name) && objectProperty(args[1], "noent") && objectProperty(args[1], "noent").kind === ts.SyntaxKind.TrueKeyword) finding(node, "local-javascript-xxe");
      if (method === "unserialize" || name === "node-serialize.unserialize") finding(node, "local-javascript-unsafe-deserialization");
      if (/^(?:ejs|pug|jade|handlebars|nunjucks|lodash|underscore|mustache|dot)\.(?:render|compile|template|renderString|compileTemplate)$/i.test(name) && first && fromRequest(first)) finding(node, "local-javascript-template-injection");
      if (method === "listen" && args.some((argument) => ["0.0.0.0", "::"].includes(stringValue(argument)))) finding(node, "local-javascript-bind-all-interfaces");
      if (["send", "json", "write", "end", "render"].includes(method) && /^(?:res|response|reply|ctx)(?:\.status\(.*\))?$/.test(receiver) && namesAndStrings(args).names.some((value) => /\.stack$/.test(value))) finding(node, "local-javascript-stack-trace-exposure");
      if (["send", "write", "end"].includes(method) && /^(?:res|response)(?:\.status\(.*\))?$/.test(receiver) && args.some(fromRequest)) finding(node, "local-javascript-reflected-xss");
      if (["alert", "confirm", "prompt", "window.alert", "window.confirm", "window.prompt"].includes(name) && ts.isCallExpression(node)) finding(node, "local-javascript-quality-alert");
    }
    if (node.kind === ts.SyntaxKind.RegularExpressionLiteral && catastrophicRegex(node.text.slice(1, node.text.lastIndexOf("/")))) finding(node, "local-javascript-catastrophic-regex");
    if (ts.isPropertyAssignment(node)) {
      const key = propertyName(node);
      const value = stringValue(node.initializer);
      if ((key === "secureProtocol" && /^(?:SSLv2|SSLv3|TLSv1|TLSv1_1)_(?:client_|server_)?method$/.test(value || "")) || (key === "minVersion" && ["TLSv1", "TLSv1.1"].includes(value))) finding(node, "local-javascript-weak-tls");
      if (key === "$where") finding(node, "local-javascript-nosql-injection");
      if (CREDENTIAL_NAME.test(key) && value && !/\s/.test(value) && !/^[A-Z][A-Z0-9_]*$/.test(value) && !["password", "secret", "token", "apikey", "api_key"].includes(value.toLowerCase())) finding(node, "local-javascript-hardcoded-credential", undefined, undefined, true);
    }
    if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name) && CREDENTIAL_NAME.test(node.name.text)) {
      const value = stringValue(node.initializer);
      if (value && !/\s/.test(value) && !/^[A-Z][A-Z0-9_]*$/.test(value) && !["password", "secret", "token", "apikey", "api_key"].includes(value.toLowerCase())) finding(node, "local-javascript-hardcoded-credential", undefined, undefined, true);
    }
    if ((ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) && literalIp(node.text)) finding(node, "local-javascript-hardcoded-ip", undefined, undefined, true);
    if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isElementAccessExpression(node.left) && fromRequest(node.left.argumentExpression)) finding(node, "local-javascript-prototype-pollution");
    if (isDeclaration) return;
    if (node.kind === ts.SyntaxKind.DebuggerStatement) finding(node, "local-javascript-quality-debugger");
    if (ts.isCatchClause(node) && node.block.statements.length === 0 && !/\/[/*]/.test(node.block.getText(source))) finding(node, "local-javascript-quality-empty-catch");
    if (ts.isBinaryExpression(node) && [ts.SyntaxKind.EqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsToken].includes(node.operatorToken.kind) && node.left.kind !== ts.SyntaxKind.NullKeyword && node.right.kind !== ts.SyntaxKind.NullKeyword) finding(node, "local-javascript-quality-loose-equality");
    if (ts.isVariableDeclarationList(node) && !(node.flags & ts.NodeFlags.BlockScoped)) finding(node, "local-javascript-quality-var-declaration");
    if (ts.isConditionalExpression(node) && (ts.isConditionalExpression(node.whenTrue) || ts.isConditionalExpression(node.whenFalse))) finding(node, "local-javascript-quality-nested-ternary");
    if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.EqualsToken && (ts.isIdentifier(node.left) || ts.isPropertyAccessExpression(node.left)) && node.left.getText(source) === node.right.getText(source)) finding(node, "local-javascript-quality-self-assignment");
    if (ts.isObjectLiteralExpression(node)) {
      const seen = new Set();
      for (const property of node.properties) {
        if (!property.name || ts.isComputedPropertyName(property.name) || ts.isSpreadAssignment(property) || ts.isGetAccessor(property) || ts.isSetAccessor(property)) continue;
        const key = propertyName(property);
        if (seen.has(key)) finding(property, "local-javascript-quality-duplicate-key");
        seen.add(key);
      }
    }
    if (ts.isBlock(node) || ts.isSourceFile(node) || ts.isCaseClause(node) || ts.isDefaultClause(node) || ts.isModuleBlock(node)) {
      const statements = node.statements;
      for (let index = 0; index < statements.length - 1; index += 1) {
        if ([ts.SyntaxKind.ReturnStatement, ts.SyntaxKind.ThrowStatement, ts.SyntaxKind.BreakStatement, ts.SyntaxKind.ContinueStatement].includes(statements[index].kind)) {
          const next = statements[index + 1];
          if (!ts.isFunctionDeclaration(next)) finding(next, "local-javascript-quality-unreachable-code");
          break;
        }
      }
    }
    if ((ts.isFunctionDeclaration(node) || ts.isFunctionExpression(node) || ts.isArrowFunction(node) || ts.isMethodDeclaration(node) || ts.isGetAccessor(node) || ts.isSetAccessor(node)) && node.body) {
      if (node.parameters.length > MAX_PARAMETERS) finding(node, "local-javascript-quality-too-many-parameters");
      const start = source.getLineAndCharacterOfPosition(node.getStart(source)).line;
      const end = source.getLineAndCharacterOfPosition(node.getEnd()).line;
      if (end - start + 1 > MAX_FUNCTION_LINES) finding(node, "local-javascript-quality-long-function");
      if (complexity(node) > MAX_COMPLEXITY) finding(node, "local-javascript-quality-high-complexity");
      if (tooDeep(node)) finding(node, "local-javascript-quality-deep-nesting");
    }
  }
  const isDeclaration = /\.d\.ts$/i.test(file);
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const name = qualified(node.expression);
      if (ts.isPropertyAccessExpression(node.expression) && bypassMethods.has(node.expression.name.text)) {
        finding(node, "local-angular-security-bypass", "Review Angular sanitizer bypass and verify the value is trusted.");
      } else if (ts.isIdentifier(node.expression) && node.expression.text === "eval") {
        finding(node, "local-javascript-eval", "Review dynamic code execution with eval.");
      }
      if (["document.write", "document.writeln"].includes(name) || (ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === "insertAdjacentHTML")) finding(node, "local-javascript-html-insertion", "Review HTML insertion for untrusted input.", "Cross-Site Scripting (XSS)");
      if (["child_process.exec", "child_process.execSync"].includes(name)) finding(node, "local-javascript-shell-exec", "Review shell command execution and input handling.", "Command Injection");
      if (["child_process.spawn", "child_process.spawnSync", "child_process.execFile", "child_process.execFileSync"].includes(name) && node.arguments.some((argument) => ts.isObjectLiteralExpression(argument) && argument.properties.some((property) => ts.isPropertyAssignment(property) && property.name.getText(source).replace(/['\"]/g, "") === "shell" && property.initializer.kind === ts.SyntaxKind.TrueKeyword))) finding(node, "local-javascript-shell-option", "Review process execution with a shell and untrusted input.", "Command Injection");
      if (["crypto.createHash", "crypto.createHmac"].includes(name) && node.arguments[0] && ts.isStringLiteral(node.arguments[0]) && ["md5", "sha1", "sha-1"].includes(node.arguments[0].text.toLowerCase())) finding(node, "local-javascript-weak-hash", "Review weak digest use in security-sensitive contexts.", "Weak Cryptography");
      if (["crypto.createCipher", "crypto.createDecipher"].includes(name)) finding(node, "local-javascript-deprecated-cipher", "Review deprecated cipher creation and use an authenticated encryption scheme.", "Weak Cryptography");
      if (["crypto.createCipheriv", "crypto.createDecipheriv"].includes(name) && node.arguments[0] && ts.isStringLiteral(node.arguments[0]) && /(?:^des(?:-|$)|^rc4(?:-|$)|-ecb$)/i.test(node.arguments[0].text)) finding(node, "local-javascript-weak-cipher", "Review use of a legacy cipher or ECB mode.", "Weak Cryptography");
      if (["vm.runInNewContext", "vm.runInThisContext", "vm.runInContext"].includes(name)) finding(node, "local-javascript-vm-execution", "Review dynamic code executed in a VM context.", "Code Injection");
      if (["setTimeout", "setInterval", "window.setTimeout", "window.setInterval"].includes(name) && node.arguments[0] && (ts.isStringLiteral(node.arguments[0]) || ts.isTemplateExpression(node.arguments[0]) || ts.isNoSubstitutionTemplateLiteral(node.arguments[0]))) finding(node, "local-javascript-string-timer", "Review code executed from a string timer.", "Code Injection");
      if (ts.isPropertyAccessExpression(node.expression) && ["query", "execute"].includes(node.expression.name.text) && dynamicString(node.arguments[0])) finding(node, "local-javascript-dynamic-query", "Review dynamically constructed query and use parameterized SQL when applicable.", "SQL Injection");
      if (ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === "postMessage" && node.arguments[1] && ts.isStringLiteral(node.arguments[1]) && node.arguments[1].text === "*") finding(node, "local-javascript-wildcard-postmessage", "Review whether messages containing sensitive data need a restricted target origin.", "Information Disclosure");
    } else if (ts.isNewExpression(node) && ["Function", "globalThis.Function"].includes(qualified(node.expression))) {
      finding(node, "local-javascript-function-constructor", "Review dynamically constructed executable code.", "Code Injection");
    } else if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isPropertyAccessExpression(node.left)) {
      if (node.left.name.text === "innerHTML") finding(node, "local-javascript-innerhtml", "Review direct innerHTML assignment for cross-site scripting.");
      if (node.left.name.text === "outerHTML") finding(node, "local-javascript-outerhtml", "Review direct outerHTML assignment for cross-site scripting.", "Cross-Site Scripting (XSS)");
      if (qualified(node.left) === "process.env.NODE_TLS_REJECT_UNAUTHORIZED" && ts.isStringLiteral(node.right) && node.right.text === "0") finding(node, "local-javascript-disabled-tls", "TLS certificate verification is disabled for this process.", "TLS Verification Disabled");
    } else if (ts.isPropertyAssignment(node) && node.name.getText(source).replace(/['\"]/g, "") === "rejectUnauthorized" && node.initializer.kind === ts.SyntaxKind.FalseKeyword) {
      finding(node, "local-javascript-insecure-tls-option", "Review TLS settings that disable certificate verification.", "TLS Verification Disabled");
    } else if (ts.isJsxAttribute(node) && node.name.text === "dangerouslySetInnerHTML") {
      finding(node, "local-javascript-dangerous-jsx-html", "Review raw HTML rendering for untrusted input.", "Cross-Site Scripting (XSS)");
    }
    checkExtended(node);
    ts.forEachChild(node, visit);
  }
  visit(source);
  if (!isDeclaration) {
    lines.forEach((line, index) => {
      const match = /(?:\/\/|\/\*|^\s*\*).*?\b(?:TODO|FIXME|XXX|HACK)\b/.exec(line);
      if (!match) return;
      const node = { getStart: () => source.getPositionOfLineAndCharacter(index, match.index) };
      finding(node, "local-javascript-quality-todo-comment");
    });
  }
  if ([".ts", ".tsx"].includes(extension)) {
    lines.forEach((line, index) => {
      const comment = /^\s*(?:\/\/|\/\*|\*)/.test(line);
      for (const rule of customRules) {
        if (comment && !rule.include_comments) continue;
        const spans = [];
        for (const pattern of rule._patterns) {
          const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
          const global = new RegExp(pattern.source, flags);
          let found;
          while ((found = global.exec(line)) && spans.length < 5) {
            if (!found[0].length) { global.lastIndex += 1; continue; }
            spans.push([found.index, found.index + found[0].length]);
          }
          if (spans.length === 5) break;
        }
        if (!spans.length) continue;
        report.results.push({ check_id: rule.id, path: relative, start: { line: index + 1, col: spans[0][0] + 1 }, extra: { severity: rule.severity || "WARNING", category: rule.category || "Security", issue_type: rule.issue_type || "Security review", message: rule.message, lines: line, highlights: spans } });
      }
    });
  }
}

try {
  if (!fs.statSync(root).isDirectory()) throw new Error("Repository path is not a directory");
  const rules = JSON.parse(fs.readFileSync(rulesPath, "utf8"));
  if (!Array.isArray(rules)) throw new Error("TypeScript rules must be a list");
  builtinRules = new Map();
  customRules = [];
  const ids = new Set();
  for (const rule of rules) {
    if (!rule || typeof rule.id !== "string" || !rule.id || ids.has(rule.id) || (rule.enabled !== undefined && typeof rule.enabled !== "boolean")) throw new Error("Invalid or duplicate TypeScript rule ID or enabled value");
    ids.add(rule.id);
    if (rule.engine === "ast" && !builtinIds.has(rule.id)) throw new Error(`Unknown TypeScript AST rule: ${rule.id}`);
    if (rule.enabled === false) continue;
    if (rule.engine === "ast" && typeof rule.message === "string" && rule.message.trim() && typeof rule.issue_type === "string" && rule.issue_type.trim()) builtinRules.set(rule.id, rule);
    else if (rule.engine === undefined && typeof rule.message === "string") {
      const sources = Array.isArray(rule.patterns) && rule.patterns.length ? rule.patterns : (typeof rule.pattern === "string" && rule.pattern ? [rule.pattern] : (typeof rule.literal === "string" && rule.literal ? [rule.literal.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")] : []));
      if (!sources.length || sources.some((item) => typeof item !== "string" || !item)) throw new Error(`Invalid TypeScript rule: ${rule.id}`);
      try {
        rule._patterns = sources.map((source) => new RegExp(source));
      } catch (error) {
        throw new Error(`Invalid TypeScript rule pattern: ${rule.id}`);
      }
      customRules.push(rule);
    }
    else throw new Error(`Invalid TypeScript rule: ${rule.id}`);
  }
  report.builtin_rules = builtinRules.size;
  report.custom_rules = customRules.length;
  report.disabled_or_missing_builtin_rules = [...builtinIds].filter((id) => !builtinRules.has(id)).sort();
  walk(root);
  process.stdout.write(JSON.stringify(report));
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}